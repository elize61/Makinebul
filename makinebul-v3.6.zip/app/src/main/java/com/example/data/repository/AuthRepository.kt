package com.example.data.repository

import android.util.Log
import com.example.data.firebase.FirebaseManager
import com.example.data.model.User
import com.example.data.model.UserType
import com.google.android.gms.tasks.Tasks
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

class AuthRepository {

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private var authStateListener: FirebaseAuth.AuthStateListener? = null

    init {
        loadCachedUser()
        setupAuthStateListener()
    }

    private fun getPrefs(): android.content.SharedPreferences? {
        return FirebaseManager.appContext?.getSharedPreferences("makinebul_user_prefs", android.content.Context.MODE_PRIVATE)
    }

    private fun loadCachedUser() {
        try {
            val prefs = getPrefs() ?: return
            val uid = prefs.getString("user_id", null) ?: return
            val fullName = prefs.getString("user_name", "Kullanıcı") ?: "Kullanıcı"
            val phone = prefs.getString("user_phone", "") ?: ""
            val email = prefs.getString("user_email", "") ?: ""
            val roleStr = prefs.getString("user_role", "CUSTOMER")
            val userType = parseUserTypeFromRoleString(roleStr)
            val city = prefs.getString("user_city", "") ?: ""
            val district = prefs.getString("user_district", "") ?: ""

            val cachedUser = User(
                id = uid,
                fullName = fullName,
                phone = phone,
                email = email,
                userType = userType,
                city = city,
                district = district,
                address = prefs.getString("user_address", "") ?: "",
                latitude = prefs.getFloat("user_lat", 0f).toDouble(),
                longitude = prefs.getFloat("user_lng", 0f).toDouble(),
                rating = 0.0
            )
            _currentUser.value = cachedUser
            _isLoggedIn.value = true
        } catch (e: Exception) {
            // Fallback gracefully
        }
    }

    private fun saveCachedUser(user: User) {
        try {
            val prefs = getPrefs() ?: return
            prefs.edit()
                .putString("user_id", user.id)
                .putString("user_name", user.fullName)
                .putString("user_phone", user.phone)
                .putString("user_email", user.email)
                .putString("user_role", user.userType.name)
                .putString("user_city", user.city)
                .putString("user_district", user.district)
                .putString("user_address", user.address)
                .putFloat("user_lat", user.latitude.toFloat())
                .putFloat("user_lng", user.longitude.toFloat())
                .apply()
        } catch (e: Exception) {
            // Fallback gracefully
        }
    }

    private fun clearCachedUser() {
        try {
            val prefs = getPrefs() ?: return
            prefs.edit().clear().apply()
        } catch (e: Exception) {
            // Fallback gracefully
        }
    }

    /** Yönetici tarafından askıya alınmış mı? (isSuspended=true veya status=SUSPENDED) */
    private fun isSuspendedDoc(d: com.google.firebase.firestore.DocumentSnapshot?): Boolean {
        if (d == null || !d.exists()) return false
        return d.getBoolean("isSuspended") == true || d.getString("status").equals("SUSPENDED", ignoreCase = true)
    }

    private val _suspendedNotice = MutableStateFlow(false)
    /** Askıya alınmış hesap oturumu kapatıldığında true olur; arayüz uyarıyı gösterip sıfırlar. */
    val suspendedNotice: StateFlow<Boolean> = _suspendedNotice.asStateFlow()
    fun consumeSuspendedNotice() { _suspendedNotice.value = false }

    private var suspensionRegs: List<com.google.firebase.firestore.ListenerRegistration> = emptyList()

    /** Oturum açıkken yönetici hesabı askıya alırsa kullanıcı anında çıkarılır. */
    private fun watchSuspension(uid: String) {
        try {
            suspensionRegs.forEach { it.remove() }
            val db = FirebaseManager.getFirestore() ?: return
            suspensionRegs = listOf("kullanıcılar", "users").map { col ->
                db.collection(col).document(uid).addSnapshotListener { snap, e ->
                    if (e == null && isSuspendedDoc(snap)) forceLogoutSuspended()
                }
            }
        } catch (e: Exception) {
            Log.w("AuthRepo", "watchSuspension: ${e.localizedMessage}")
        }
    }

    private fun forceLogoutSuspended() {
        suspensionRegs.forEach { it.remove() }
        suspensionRegs = emptyList()
        _suspendedNotice.value = true
        clearCachedUser()
        _currentUser.value = null
        _isLoggedIn.value = false
        try { FirebaseManager.getAuth()?.signOut() } catch (_: Exception) {}
    }

    private fun setupAuthStateListener() {
        try {
            val auth = FirebaseManager.getAuth()
            if (auth != null) {
                authStateListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
                    val firebaseUser = firebaseAuth.currentUser
                    if (firebaseUser != null && !firebaseUser.isAnonymous) {
                        val uid = firebaseUser.uid

                        // If currentUser is already loaded for this UID, don't overwrite with a temp default
                        val current = _currentUser.value
                        if (current != null && current.id == uid && current.userType != null) {
                            fetchUserProfileFromFirestore(uid)
                            watchSuspension(uid)
                            return@AuthStateListener
                        }

                        // Otherwise check local cached user first
                        val prefs = getPrefs()
                        val cachedUid = prefs?.getString("user_id", null)
                        if (cachedUid == uid) {
                            val prefsRole = prefs.getString("user_role", null)
                            val cachedRole = if (prefsRole != null) parseUserTypeFromRoleString(prefsRole) else null
                            if (cachedRole != null) {
                                val cachedUser = User(
                                    id = uid,
                                    fullName = prefs.getString("user_name", "Kullanıcı") ?: "Kullanıcı",
                                    phone = prefs.getString("user_phone", "") ?: "",
                                    email = prefs.getString("user_email", firebaseUser.email ?: "") ?: "",
                                    userType = cachedRole,
                                    city = prefs.getString("user_city", "") ?: "",
                                    district = prefs.getString("user_district", "") ?: "",
                                    address = prefs.getString("user_address", "") ?: "",
                                    latitude = prefs.getFloat("user_lat", 0f).toDouble(),
                                    longitude = prefs.getFloat("user_lng", 0f).toDouble(),
                                    rating = 0.0
                                )
                                _currentUser.value = cachedUser
                                _isLoggedIn.value = true
                            }
                        }

                        // Asynchronously sync latest user profile from Firestore
                        fetchUserProfileFromFirestore(uid)
                        watchSuspension(uid)
                    } else {
                        clearCachedUser()
                        _currentUser.value = null
                        _isLoggedIn.value = false
                    }
                }
                auth.addAuthStateListener(authStateListener!!)
            } else {
                _currentUser.value = null
                _isLoggedIn.value = false
            }
        } catch (e: Exception) {
            Log.e("AuthRepo", "Error setting up auth state listener: ${e.localizedMessage}", e)
        }
    }

    fun checkCurrentUserSession() {
        val auth = FirebaseManager.getAuth()
        if (auth?.currentUser == null) {
            _currentUser.value = null
            _isLoggedIn.value = false
        }
    }

    private fun parseUserTypeFromRoleString(roleStr: String?): UserType {
        if (roleStr.isNullOrBlank()) return UserType.CUSTOMER
        val upper = roleStr.uppercase().trim()
        return when {
            upper == "OWNER" || upper.contains("MAL SAHİBİ") || upper.contains("MAL SAHIBI") || upper.contains("SAHIBI") || upper.contains("MAKINECI") || upper == "MAKINE_SAHIBI" || upper.contains("MAKİNE") || upper.contains("MAKINE") -> UserType.OWNER
            upper == "DUTY_TOW" || upper.contains("TOW") || upper.contains("ÇEKİCİ") || upper.contains("CEKICI") -> UserType.DUTY_TOW
            upper == "DUTY_TIRE" || upper.contains("TIRE") || upper.contains("LASTİK") || upper.contains("LASTIK") -> UserType.DUTY_TIRE
            upper == "ADMIN" || upper.contains("YÖNETİCİ") || upper.contains("YONETICI") -> UserType.ADMIN
            upper == "CUSTOMER" || upper.contains("MÜŞTERİ") || upper.contains("MUSTERI") -> UserType.CUSTOMER
            else -> try {
                UserType.valueOf(upper)
            } catch (ex: Exception) {
                UserType.CUSTOMER
            }
        }
    }

    private fun fetchUserProfileFromFirestore(uid: String) {
        try {
            val db = FirebaseManager.getFirestore() ?: return
            db.collection("kullanıcılar").document(uid).get().addOnSuccessListener { doc ->
                if (isSuspendedDoc(doc)) {
                    forceLogoutSuspended()
                    return@addOnSuccessListener
                }
                if (doc != null && doc.exists()) {
                    val fullName = doc.getString("isim") ?: doc.getString("adSoyad") ?: doc.getString("fullName") ?: _currentUser.value?.fullName ?: "Kullanıcı"
                    val phone = doc.getString("telefon") ?: doc.getString("phone") ?: _currentUser.value?.phone ?: ""
                    val email = doc.getString("email") ?: _currentUser.value?.email ?: ""
                    val roleStr = doc.getString("rol") ?: doc.getString("userType")
                    val userType = parseUserTypeFromRoleString(roleStr)

                    val city = doc.getString("il") ?: doc.getString("city") ?: ""
                    val district = doc.getString("ilce") ?: doc.getString("district") ?: ""
                    val rating = doc.getDouble("rating") ?: 0.0

                    val fetchedUser = User(
                        id = uid,
                        fullName = fullName,
                        phone = phone,
                        email = email,
                        userType = userType,
                        city = city,
                        district = district,
                        address = doc.getString("shopAddress") ?: doc.getString("address") ?: "",
                        latitude = doc.getDouble("latitude") ?: 0.0,
                        longitude = doc.getDouble("longitude") ?: 0.0,
                        rating = rating
                    )
                    _currentUser.value = fetchedUser
                    saveCachedUser(fetchedUser)
                    if (userType != UserType.ADMIN) fetchFromLegacyUsersCollection(db, uid, onlyUpgradeToAdmin = true)
                } else {
                    fetchFromLegacyUsersCollection(db, uid)
                }
            }.addOnFailureListener { e ->
                Log.w("AuthRepo", "FIRESTORE USER READ WARNING ('kullanıcılar'): ${e.localizedMessage}")
                fetchFromLegacyUsersCollection(db, uid)
            }
        } catch (e: Exception) {
            Log.e("AuthRepo", "Exception fetching user profile from Firestore: ${e.localizedMessage}", e)
        }
    }

    private fun fetchFromLegacyUsersCollection(db: com.google.firebase.firestore.FirebaseFirestore, uid: String, onlyUpgradeToAdmin: Boolean = false) {
        try {
            db.collection("users").document(uid).get().addOnSuccessListener { oldDoc ->
                if (isSuspendedDoc(oldDoc)) {
                    forceLogoutSuspended()
                    return@addOnSuccessListener
                }
                if (oldDoc != null && oldDoc.exists()) {
                    val fullName = oldDoc.getString("isim") ?: oldDoc.getString("adSoyad") ?: oldDoc.getString("fullName") ?: _currentUser.value?.fullName ?: "Kullanıcı"
                    val phone = oldDoc.getString("telefon") ?: oldDoc.getString("phone") ?: _currentUser.value?.phone ?: ""
                    val email = oldDoc.getString("email") ?: _currentUser.value?.email ?: ""
                    val roleStr = oldDoc.getString("rol") ?: oldDoc.getString("userType")
                    val userType = parseUserTypeFromRoleString(roleStr)
                    if (onlyUpgradeToAdmin) {
                        val cur = _currentUser.value
                        if (userType == UserType.ADMIN && cur != null && cur.id == uid) {
                            val upgraded = cur.copy(userType = UserType.ADMIN)
                            _currentUser.value = upgraded
                            saveCachedUser(upgraded)
                        }
                        return@addOnSuccessListener
                    }

                    val city = oldDoc.getString("il") ?: oldDoc.getString("city") ?: ""
                    val district = oldDoc.getString("ilce") ?: oldDoc.getString("district") ?: ""
                    val rating = oldDoc.getDouble("rating") ?: 0.0

                    val fetchedUser = User(
                        id = uid,
                        fullName = fullName,
                        phone = phone,
                        email = email,
                        userType = userType,
                        city = city,
                        district = district,
                        address = oldDoc.getString("shopAddress") ?: oldDoc.getString("address") ?: "",
                        latitude = oldDoc.getDouble("latitude") ?: 0.0,
                        longitude = oldDoc.getDouble("longitude") ?: 0.0,
                        rating = rating
                    )
                    _currentUser.value = fetchedUser
                    saveCachedUser(fetchedUser)
                }
            }.addOnFailureListener { e ->
                Log.w("AuthRepo", "FIRESTORE USER READ WARNING ('users'): ${e.localizedMessage}")
            }
        } catch (e: Exception) {
            Log.w("AuthRepo", "Exception reading legacy users collection: ${e.localizedMessage}")
        }
    }

    suspend fun login(email: String, pass: String): Result<User> = withContext(Dispatchers.IO) {
        val trimmedEmail = email.trim()
        val trimmedPass = pass.trim()

        if (trimmedEmail.isBlank() || trimmedPass.isBlank()) {
            return@withContext Result.failure(Exception("Lütfen tüm alanları doldurun."))
        }
        if (!trimmedEmail.contains("@")) {
            return@withContext Result.failure(Exception("Geçerli bir e-posta adresi giriniz."))
        }
        if (trimmedPass.length < 6) {
            return@withContext Result.failure(Exception("Şifre en az 6 karakter olmalıdır."))
        }

        val auth = FirebaseManager.getAuth()

        if (auth != null) {
            try {
                val task = auth.signInWithEmailAndPassword(trimmedEmail, trimmedPass)
                val authResult = Tasks.await(task)
                val fUser = authResult.user
                if (fUser != null) {
                    val uid = fUser.uid
                    // First load cached preferences for this user if available
                    val prefs = getPrefs()
                    val cachedUid = prefs?.getString("user_id", null)
                    val cachedEmail = prefs?.getString("user_email", null)
                    val isSameUserCached = (cachedUid == uid || cachedEmail.equals(trimmedEmail, ignoreCase = true))

                    var fullName = if (isSameUserCached) (prefs?.getString("user_name", null) ?: fUser.displayName ?: trimmedEmail.substringBefore("@")) else (fUser.displayName ?: trimmedEmail.substringBefore("@"))
                    var phone = if (isSameUserCached) (prefs?.getString("user_phone", null) ?: fUser.phoneNumber ?: "") else (fUser.phoneNumber ?: "")
                    var city = if (isSameUserCached) (prefs?.getString("user_city", null) ?: "") else ""
                    var profileExists = false
                    var shopAddress = if (isSameUserCached) (prefs?.getString("user_address", null) ?: "") else ""
                    var shopLat = if (isSameUserCached) (prefs?.getFloat("user_lat", 0f)?.toDouble() ?: 0.0) else 0.0
                    var shopLng = if (isSameUserCached) (prefs?.getFloat("user_lng", 0f)?.toDouble() ?: 0.0) else 0.0
                    var rating = 0.0
                    var district = if (isSameUserCached) (prefs?.getString("user_district", null) ?: "") else ""
                    
                    val cachedRoleStr = if (isSameUserCached) prefs?.getString("user_role", null) else null
                    var userType = if (!cachedRoleStr.isNullOrBlank()) {
                        parseUserTypeFromRoleString(cachedRoleStr)
                    } else if (trimmedEmail.contains("owner") || trimmedEmail.contains("makine")) {
                        UserType.OWNER
                    } else if (trimmedEmail.contains("cekici") || trimmedEmail.contains("tow")) {
                        UserType.DUTY_TOW
                    } else {
                        UserType.CUSTOMER
                    }

                    try {
                        val db = FirebaseManager.getFirestore()
                        if (db != null) {
                            var primaryDoc: com.google.firebase.firestore.DocumentSnapshot? = null
                            var legacyDoc: com.google.firebase.firestore.DocumentSnapshot? = null
                            try {
                                primaryDoc = Tasks.await(db.collection("kullanıcılar").document(uid).get())
                            } catch (e: Exception) {
                                Log.w("AuthRepo", "Read 'kullanıcılar' warning on login: ${e.localizedMessage}")
                            }
                            try {
                                legacyDoc = Tasks.await(db.collection("users").document(uid).get())
                            } catch (e: Exception) {
                                Log.w("AuthRepo", "Read 'users' warning on login: ${e.localizedMessage}")
                            }
                            if (isSuspendedDoc(primaryDoc) || isSuspendedDoc(legacyDoc)) {
                                try { auth.signOut() } catch (_: Exception) {}
                                return@withContext Result.failure(Exception("Hesabınız yönetici tarafından askıya alınmıştır"))
                            }
                            val doc = if (primaryDoc != null && primaryDoc.exists()) primaryDoc else legacyDoc
                            if (doc != null && doc.exists()) {
                                profileExists = true
                                fullName = doc.getString("isim") ?: doc.getString("adSoyad") ?: doc.getString("fullName") ?: fullName
                                phone = doc.getString("telefon") ?: doc.getString("phone") ?: phone
                                val roleStr = doc.getString("rol") ?: doc.getString("userType")
                                if (!roleStr.isNullOrBlank()) {
                                    userType = parseUserTypeFromRoleString(roleStr)
                                }
                                city = doc.getString("il") ?: doc.getString("city") ?: city
                                district = doc.getString("ilce") ?: doc.getString("district") ?: district
                                rating = doc.getDouble("rating") ?: rating
                                shopAddress = doc.getString("shopAddress") ?: doc.getString("address") ?: shopAddress
                                shopLat = doc.getDouble("latitude") ?: shopLat
                                shopLng = doc.getDouble("longitude") ?: shopLng
                            }
                            // İki kayıttan biri bile yönetici ise yönetici kalır
                            val adminInEither = listOf(primaryDoc, legacyDoc).any { d ->
                                d != null && d.exists() &&
                                    parseUserTypeFromRoleString(d.getString("rol") ?: d.getString("userType")) == UserType.ADMIN
                            }
                            if (adminInEither) userType = UserType.ADMIN
                        }
                    } catch (e: Exception) {
                        Log.w("AuthRepo", "FIRESTORE USER READ WARNING during login: ${e.localizedMessage}")
                    }

                    val user = User(
                        id = uid,
                        fullName = fullName,
                        phone = phone,
                        email = fUser.email ?: trimmedEmail,
                        userType = userType,
                        city = city,
                        district = district,
                        address = shopAddress,
                        latitude = shopLat,
                        longitude = shopLng,
                        rating = rating
                    )
                    _currentUser.value = user
                    _isLoggedIn.value = true
                    saveCachedUser(user)
                    // Mevcut profil (özellikle rol) girişte asla yeniden yazılmaz
                    if (!profileExists) saveUserToFirestoreAsync(user)
                    Result.success(user)
                } else {
                    Result.failure(Exception("Giriş yapılamadı. Lütfen tekrar deneyin."))
                }
            } catch (e: Exception) {
                val cause = e.cause ?: e
                val msg = cause.message ?: ""
                Log.w("AuthRepo", "Firebase Auth login error: $msg", cause)
                val errorMsg = when {
                    e is com.google.firebase.auth.FirebaseAuthInvalidUserException ||
                    msg.contains("user-not-found", ignoreCase = true) ||
                    msg.contains("no user record", ignoreCase = true) -> "Bu e-posta adresine ait bir hesap bulunamadı. Lütfen önce kayıt olun."
                    e is com.google.firebase.auth.FirebaseAuthInvalidCredentialsException ||
                    msg.contains("password", ignoreCase = true) ||
                    msg.contains("INVALID_LOGIN_CREDENTIALS", ignoreCase = true) ||
                    msg.contains("invalid-credential", ignoreCase = true) ||
                    msg.contains("supplied auth credential", ignoreCase = true) ||
                    msg.contains("incorrect", ignoreCase = true) ||
                    msg.contains("malformed", ignoreCase = true) -> "E-posta adresi veya şifreniz hatalı. Lütfen bilgilerinizi kontrol edin veya yeni hesap oluşturun."
                    msg.contains("user-disabled", ignoreCase = true) -> "Bu hesap devre dışı bırakılmıştır. Lütfen destek ile iletişime geçin."
                    msg.contains("too-many-requests", ignoreCase = true) -> "Çok fazla başarısız giriş denemesi yapıldı. Lütfen biraz bekleyip tekrar deneyin."
                    msg.contains("network", ignoreCase = true) || msg.contains("timeout", ignoreCase = true) -> "Ağ bağlantısı hatası. Lütfen internet bağlantınızı kontrol edin."
                    else -> "Giriş yapılamadı: Bilgilerinizi kontrol edip tekrar deneyin."
                }
                Result.failure(Exception(errorMsg))
            }
        } else {
            Result.failure(Exception("Sunucu bağlantısı kurulamadı. Lütfen internet bağlantınızı kontrol edin."))
        }
    }

    suspend fun register(
        fullName: String,
        phone: String,
        email: String,
        pass: String,
        userType: UserType,
        city: String,
        district: String
    ): Result<User> = withContext(Dispatchers.IO) {
        if (fullName.isBlank() || phone.isBlank() || email.isBlank() || pass.isBlank() || city.isBlank() || district.isBlank()) {
            return@withContext Result.failure(Exception("Lütfen tüm alanları eksiksiz doldurun."))
        }
        if (!email.contains("@")) {
            return@withContext Result.failure(Exception("Lütfen geçerli bir e-posta adresi giriniz."))
        }
        if (pass.length < 6) {
            return@withContext Result.failure(Exception("Şifreniz en az 6 karakterden oluşmalıdır."))
        }

        val auth = FirebaseManager.getAuth()

        if (auth != null) {
            try {
                val task = auth.createUserWithEmailAndPassword(email.trim(), pass)
                val authResult = Tasks.await(task)
                val fUser = authResult.user
                if (fUser != null) {
                    val uid = fUser.uid
                    val newUser = User(
                        id = uid,
                        fullName = fullName,
                        phone = phone,
                        email = email,
                        userType = userType,
                        city = city,
                        district = district,
                        rating = 0.0
                    )
                    
                    val writeResult = saveUserToFirestore(newUser)
                    if (writeResult.isFailure) {
                        val ex = writeResult.exceptionOrNull()
                        val msg = ex?.localizedMessage ?: "Veritabanı erişim uyarısı"
                        Log.w("AuthRepo", "FIRESTORE USER WRITE WARNING during register: $msg")
                    }

                    _currentUser.value = newUser
                    _isLoggedIn.value = true
                    saveCachedUser(newUser)
                    Result.success(newUser)
                } else {
                    Result.failure(Exception("Kayıt oluşturulamadı. Lütfen tekrar deneyin."))
                }
            } catch (e: Exception) {
                val cause = e.cause ?: e
                val errorMsg = when {
                    cause.message?.contains("already in use", ignoreCase = true) == true ||
                    cause.message?.contains("email-already-in-use", ignoreCase = true) == true -> "Bu e-posta adresi ile zaten kayıtlı bir kullanıcı var."
                    cause.message?.contains("network", ignoreCase = true) == true -> "Ağ bağlantısı hatası. Lütfen bağlantınızı kontrol edin."
                    else -> cause.localizedMessage ?: "Kayıt olurken bir hata oluştu."
                }
                Result.failure(Exception(errorMsg))
            }
        } else {
            val newUid = "user_${System.currentTimeMillis()}"
            val newUser = User(
                id = newUid,
                fullName = fullName,
                phone = phone,
                email = email,
                userType = userType,
                city = city,
                district = district,
                rating = 0.0
            )
            _currentUser.value = newUser
            _isLoggedIn.value = true
            saveCachedUser(newUser)
            saveUserToFirestore(newUser)
            Result.success(newUser)
        }
    }

    /**
     * Dükkan/işletme adresini kaydeder. Adres önce haritadan koordinata çevrilir;
     * bulunamazsa kaydedilmez. Koordinat, çekici eşleştirmesinde sağlayıcının konumu olarak kullanılır.
     */
    suspend fun updateShopAddress(address: String): Result<User> = withContext(Dispatchers.IO) {
        val current = _currentUser.value
            ?: return@withContext Result.failure(Exception("Oturum bulunamadı."))
        val text = address.trim()
        if (text.length < 10) {
            return@withContext Result.failure(Exception("Lütfen mahalle, cadde/sokak, ilçe ve il ile tam adres yazın."))
        }
        val geo = com.example.util.GeocodeUtils.geocode(text)
            ?: return@withContext Result.failure(
                Exception("Adres haritada bulunamadı. Mahalle, ilçe ve il bilgisini ekleyip tekrar deneyin.")
            )

        val updated = current.copy(
            address = text,
            latitude = geo.latitude,
            longitude = geo.longitude,
            city = geo.city.ifBlank { current.city },
            district = geo.district.ifBlank { current.district }
        )

        val db = FirebaseManager.getFirestore()
        if (db != null) {
            val fields = mapOf<String, Any>(
                "shopAddress" to text,
                "latitude" to geo.latitude,
                "longitude" to geo.longitude,
                "city" to updated.city,
                "il" to updated.city,
                "district" to updated.district,
                "ilce" to updated.district,
                "lastLocationUpdate" to System.currentTimeMillis()
            )
            var saved = false
            for (col in listOf("kullanıcılar", "users")) {
                try {
                    Tasks.await(db.collection(col).document(current.id).update(fields))
                    saved = true
                } catch (e: Exception) {
                    Log.w("AuthRepo", "Adres '$col' içine yazılamadı: ${e.localizedMessage}")
                }
            }
            if (!saved) {
                return@withContext Result.failure(Exception("Adres kaydedilemedi. İnternet bağlantınızı kontrol edin."))
            }
        }

        _currentUser.value = updated
        saveCachedUser(updated)
        Result.success(updated)
    }

    fun switchUserType(newType: UserType) {
        val current = _currentUser.value ?: return
        if (current.userType == UserType.ADMIN) return
        val updated = current.copy(userType = newType)
        _currentUser.value = updated
        saveCachedUser(updated)
        saveUserToFirestoreAsync(updated)
    }

    fun logout() {
        try {
            FirebaseManager.getAuth()?.signOut()
        } catch (e: Exception) {
            // Ignore
        }
        clearCachedUser()
        _currentUser.value = null
        _isLoggedIn.value = false
    }

    suspend fun resetPassword(email: String): Result<Unit> = withContext(Dispatchers.IO) {
        if (email.isBlank() || !email.contains("@")) {
            return@withContext Result.failure(Exception("Geçerli bir e-posta adresi giriniz."))
        }
        val auth = FirebaseManager.getAuth()
        if (auth != null) {
            try {
                val task = auth.sendPasswordResetEmail(email.trim())
                Tasks.await(task)
                Result.success(Unit)
            } catch (e: Exception) {
                val cause = e.cause ?: e
                Result.failure(Exception(cause.localizedMessage ?: "Şifre sıfırlama e-postası gönderilemedi."))
            }
        } else {
            Result.success(Unit)
        }
    }

    /**
     * Hesabı ve kullanıcıya ait ilanları siler. Güvenlik için Firebase, yakın zamanda giriş yapılmasını ister;
     * bu durumda kullanıcıdan çıkış yapıp tekrar girmesi istenir.
     */
    suspend fun deleteAccount(): Result<Unit> = withContext(Dispatchers.IO) {
        val auth = FirebaseManager.getAuth()
            ?: return@withContext Result.failure(Exception("Sunucu bağlantısı kurulamadı."))
        val user = auth.currentUser
            ?: return@withContext Result.failure(Exception("Oturum bulunamadı."))
        val uid = user.uid
        try {
            val db = FirebaseManager.getFirestore()
            if (db != null) {
                for (col in listOf("makineler", "machines")) {
                    val docs = Tasks.await(db.collection(col).whereEqualTo("ownerId", uid).get())
                    docs.documents.forEach { d ->
                        runCatching { Tasks.await(db.collection("machineContacts").document(d.id).delete()) }
                        runCatching { Tasks.await(d.reference.delete()) }
                    }
                }
                for (col in listOf("kullanıcılar", "users")) {
                    runCatching { Tasks.await(db.collection(col).document(uid).delete()) }
                }
            }
            Tasks.await(user.delete())
            clearCachedUser()
            _currentUser.value = null
            _isLoggedIn.value = false
            Result.success(Unit)
        } catch (e: Exception) {
            val cause = e.cause ?: e
            val msg = if (cause.message?.contains("recent", ignoreCase = true) == true)
                "Güvenlik için çıkış yapıp tekrar giriş yaptıktan sonra hesabınızı silin."
            else "Hesap silinemedi: ${cause.localizedMessage ?: "bilinmeyen hata"}"
            Result.failure(Exception(msg))
        }
    }

    private suspend fun saveUserToFirestore(user: User): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val db = FirebaseManager.getFirestore()
                ?: return@withContext Result.failure(Exception("Firestore veritabanına ulaşılamadı."))
            
            val userMap = hashMapOf<String, Any?>(
                "uid" to user.id,
                "id" to user.id,
                "email" to user.email,
                "isim" to user.fullName,
                "adSoyad" to user.fullName,
                "fullName" to user.fullName,
                "telefon" to user.phone,
                "phone" to user.phone,
                "rol" to user.userType.name,
                "userType" to user.userType.name,
                "il" to user.city,
                "city" to user.city,
                "ilce" to user.district,
                "district" to user.district,
                "rating" to user.rating,
                "createdAt" to System.currentTimeMillis()
            )
            if (user.address.isNotBlank()) {
                userMap["shopAddress"] = user.address
                userMap["latitude"] = user.latitude
                userMap["longitude"] = user.longitude
            }

            var ok1 = false
            var ok2 = false
            // Try 'kullanıcılar' collection
            try {
                val setTask = db.collection("kullanıcılar").document(user.id).set(userMap)
                Tasks.await(setTask)
                Log.d("AuthRepo", "FIRESTORE USER WRITE SUCCESS 'kullanıcılar' UID: ${user.id}")
                ok1 = true
            } catch (e: Exception) {
                Log.w("AuthRepo", "FIRESTORE USER WRITE WARNING 'kullanıcılar': ${e.localizedMessage}")
            }

            // Also try 'users' collection (ASCII fallback)
            try {
                val setTaskOld = db.collection("users").document(user.id).set(userMap)
                Tasks.await(setTaskOld)
                Log.d("AuthRepo", "FIRESTORE USER WRITE SUCCESS 'users' UID: ${user.id}")
                ok2 = true
            } catch (e: Exception) {
                Log.w("AuthRepo", "FIRESTORE USER WRITE WARNING 'users': ${e.localizedMessage}")
            }

            if (ok1 || ok2) Result.success(Unit) else Result.failure(Exception("Profil kaydedilemedi"))
        } catch (e: Exception) {
            val errMsg = e.localizedMessage ?: "Bilinmeyen veritabanı hatası"
            Log.w("AuthRepo", "FIRESTORE USER WRITE WARNING: $errMsg", e)
            Result.failure(Exception(errMsg, e))
        }
    }

    private fun saveUserToFirestoreAsync(user: User) {
        try {
            val db = FirebaseManager.getFirestore() ?: return
            val userMap = hashMapOf<String, Any?>(
                "uid" to user.id,
                "id" to user.id,
                "email" to user.email,
                "isim" to user.fullName,
                "adSoyad" to user.fullName,
                "fullName" to user.fullName,
                "telefon" to user.phone,
                "phone" to user.phone,
                "rol" to user.userType.name,
                "userType" to user.userType.name,
                "il" to user.city,
                "city" to user.city,
                "ilce" to user.district,
                "district" to user.district,
                "rating" to user.rating,
                "createdAt" to System.currentTimeMillis()
            )
            if (user.address.isNotBlank()) {
                userMap["shopAddress"] = user.address
                userMap["latitude"] = user.latitude
                userMap["longitude"] = user.longitude
            }
            db.collection("kullanıcılar").document(user.id).set(userMap)
                .addOnSuccessListener {
                    Log.d("AuthRepo", "FIRESTORE USER WRITE SUCCESS UID: ${user.id}")
                }
                .addOnFailureListener { e ->
                    Log.w("AuthRepo", "FIRESTORE USER WRITE WARNING 'kullanıcılar': ${e.localizedMessage}")
                }
            db.collection("users").document(user.id).set(userMap)
                .addOnSuccessListener {
                    Log.d("AuthRepo", "FIRESTORE USER WRITE SUCCESS UID: ${user.id}")
                }
                .addOnFailureListener { e ->
                    Log.w("AuthRepo", "FIRESTORE USER WRITE WARNING 'users': ${e.localizedMessage}")
                }
        } catch (e: Exception) {
            Log.w("AuthRepo", "FIRESTORE USER WRITE WARNING: ${e.localizedMessage}")
        }
    }

    /**
     * Firebase Anonymous Authentication for guest users requesting emergency assistance.
     * Allows stranded users to create requests without email/password registration.
     */
    suspend fun signInAnonymously(): Result<String> = withContext(Dispatchers.IO) {
        try {
            val auth = FirebaseManager.getAuth()
            if (auth != null) {
                val current = auth.currentUser
                if (current != null) {
                    val uid = current.uid
                    Log.d("AuthRepo", "Existing user/anonymous session found: $uid")
                    return@withContext Result.success(uid)
                }

                val task = auth.signInAnonymously()
                val result = Tasks.await(task)
                val uid = result.user?.uid ?: "anon_${System.currentTimeMillis()}"
                Log.d("AuthRepo", "Firebase Anonymous Authentication successful: $uid")
                return@withContext Result.success(uid)
            } else {
                val fallbackUid = "anon_guest_${System.currentTimeMillis()}"
                Log.d("AuthRepo", "Firebase Auth unavailable, generated fallback guest UID: $fallbackUid")
                return@withContext Result.success(fallbackUid)
            }
        } catch (e: Exception) {
            Log.w("AuthRepo", "Anonymous sign in failed, falling back: ${e.localizedMessage}")
            val fallbackUid = "anon_guest_${System.currentTimeMillis()}"
            return@withContext Result.success(fallbackUid)
        }
    }

    // ---------------------------------------------------------------------------------
    // Google ile tek tıkla giriş (Credential Manager) ve hızlı esnaf kaydı
    // ---------------------------------------------------------------------------------

    /** Firestore'da (iki koleksiyondan biri) kayıtlı kullanıcıyı okur; yoksa null döner. */
    private fun readExistingUser(uid: String): User? {
        val db = FirebaseManager.getFirestore() ?: return null
        for (col in listOf("kullanıcılar", "users")) {
            try {
                val doc = Tasks.await(db.collection(col).document(uid).get())
                if (doc != null && doc.exists()) {
                    if (isSuspendedDoc(doc)) return User(id = uid, isActive = false)
                    return User(
                        id = uid,
                        fullName = doc.getString("isim") ?: doc.getString("adSoyad") ?: doc.getString("fullName") ?: "Kullanıcı",
                        phone = doc.getString("telefon") ?: doc.getString("phone") ?: "",
                        email = doc.getString("email") ?: "",
                        userType = parseUserTypeFromRoleString(doc.getString("rol") ?: doc.getString("userType")),
                        city = doc.getString("il") ?: doc.getString("city") ?: "",
                        district = doc.getString("ilce") ?: doc.getString("district") ?: "",
                        address = doc.getString("shopAddress") ?: doc.getString("address") ?: "",
                        latitude = doc.getDouble("latitude") ?: 0.0,
                        longitude = doc.getDouble("longitude") ?: 0.0,
                        rating = doc.getDouble("rating") ?: 0.0
                    )
                }
            } catch (e: Exception) {
                Log.w("AuthRepo", "readExistingUser($col): ${e.localizedMessage}")
            }
        }
        return null
    }

    /**
     * Google ile giriş. Firebase Authentication'a Credential Manager üzerinden giriş yapar,
     * Firestore'da kullanıcı kaydı yoksa otomatik oluşturur. Kayıtlı bir müşteri "ilan ver" yolundan
     * geldiyse ([wantOwner]) rolü esnaf/sahip olarak yükseltilir. Yönetici ve sürücü rolleri asla değiştirilmez.
     * [uiContext] mutlaka Activity bağlamı olmalıdır.
     */
    suspend fun signInWithGoogle(uiContext: android.content.Context, wantOwner: Boolean): Result<User> {
        val resId = uiContext.resources.getIdentifier("default_web_client_id", "string", uiContext.packageName)
        if (resId == 0) {
            return Result.failure(Exception("Google girişi henüz yapılandırılmamış. Firebase'de Google sağlayıcısını açıp güncel google-services.json dosyasını projeye ekleyin."))
        }
        val webClientId = uiContext.getString(resId)
        val idToken: String
        try {
            val option = com.google.android.libraries.identity.googleid.GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(webClientId)
                .setAutoSelectEnabled(false)
                .build()
            val request = androidx.credentials.GetCredentialRequest.Builder().addCredentialOption(option).build()
            val result = androidx.credentials.CredentialManager.create(uiContext).getCredential(uiContext, request)
            val cred = result.credential
            if (cred is androidx.credentials.CustomCredential &&
                cred.type == com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                idToken = com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.createFrom(cred.data).idToken
            } else {
                return Result.failure(Exception("Google hesabı alınamadı. Lütfen tekrar deneyin."))
            }
        } catch (e: androidx.credentials.exceptions.GetCredentialCancellationException) {
            return Result.failure(Exception("Google girişi iptal edildi."))
        } catch (e: androidx.credentials.exceptions.NoCredentialException) {
            return Result.failure(Exception("Cihazda Google hesabı bulunamadı. Telefon ayarlarından bir Google hesabı ekleyin."))
        } catch (e: Exception) {
            Log.w("AuthRepo", "Google credential error: ${e.localizedMessage}", e)
            return Result.failure(Exception("Google girişi başlatılamadı: ${e.localizedMessage ?: "bilinmeyen hata"}"))
        }

        return withContext(Dispatchers.IO) {
            try {
                val auth = FirebaseManager.getAuth()
                    ?: return@withContext Result.failure(Exception("Sunucu bağlantısı kurulamadı."))
                val authResult = Tasks.await(auth.signInWithCredential(GoogleAuthProvider.getCredential(idToken, null)))
                val fUser = authResult.user
                    ?: return@withContext Result.failure(Exception("Google ile giriş tamamlanamadı."))
                val uid = fUser.uid
                val existing = readExistingUser(uid)

                if (existing != null && !existing.isActive) {
                    forceLogoutSuspended()
                    return@withContext Result.failure(Exception("Hesabınız yönetici tarafından askıya alınmıştır"))
                }

                val finalUser: User
                if (existing == null) {
                    finalUser = User(
                        id = uid,
                        fullName = fUser.displayName?.takeIf { it.isNotBlank() } ?: "Kullanıcı",
                        phone = fUser.phoneNumber ?: "",
                        email = fUser.email ?: "",
                        userType = if (wantOwner) UserType.OWNER else UserType.CUSTOMER
                    )
                    val saved = saveUserToFirestore(finalUser)
                    if (saved.isFailure) {
                        runCatching { Tasks.await(fUser.delete()) }
                        return@withContext Result.failure(Exception("Profil kaydedilemedi, lütfen tekrar deneyin."))
                    }
                } else if (wantOwner && existing.userType == UserType.CUSTOMER) {
                    finalUser = existing.copy(userType = UserType.OWNER)
                    saveUserToFirestore(finalUser)
                } else {
                    finalUser = existing
                }
                _currentUser.value = finalUser
                _isLoggedIn.value = true
                saveCachedUser(finalUser)
                watchSuspension(uid)
                Result.success(finalUser)
            } catch (e: Exception) {
                val cause = e.cause ?: e
                Log.w("AuthRepo", "Google sign-in Firebase error: ${cause.localizedMessage}", cause)
                val code = (cause as? com.google.firebase.auth.FirebaseAuthException)?.errorCode
                if (code == "ERROR_ACCOUNT_EXISTS_WITH_DIFFERENT_CREDENTIAL") {
                    return@withContext Result.failure(Exception("Bu e-posta ile zaten bir hesap var. E-posta ve şifrenizle giriş yapıp devam edin."))
                }
                Result.failure(Exception(
                    if (cause.message?.contains("network", ignoreCase = true) == true) "Ağ bağlantısı hatası. Lütfen bağlantınızı kontrol edin."
                    else "Google ile giriş yapılamadı: ${cause.localizedMessage ?: "bilinmeyen hata"}"
                ))
            }
        }
    }

    /** Hızlı kayıt: Ad-Soyad + Telefon + E-posta + Şifre. Giriş e-posta ve şifreyle yapılır. */
    suspend fun quickRegisterOwner(fullName: String, phone: String, email: String, pass: String, asOwner: Boolean): Result<User> = withContext(Dispatchers.IO) {
        val name = fullName.trim()
        val mail = email.trim()
        if (!mail.contains("@") || !mail.substringAfter("@").contains(".")) {
            return@withContext Result.failure(Exception("Lütfen geçerli bir e-posta adresi girin."))
        }
        if (name.length < 2 || name.any { it.isDigit() }) {
            return@withContext Result.failure(Exception("Lütfen adınızı yazın."))
        }
        val digits = normalizeTrPhone(phone)
            ?: return@withContext Result.failure(Exception("Geçerli bir cep telefonu girin (05xx xxx xx xx)."))
        if (pass.trim().length < 6) {
            return@withContext Result.failure(Exception("Şifre en az 6 karakter olmalıdır."))
        }
        val auth = FirebaseManager.getAuth()
            ?: return@withContext Result.failure(Exception("Sunucu bağlantısı kurulamadı. Lütfen internet bağlantınızı kontrol edin."))
        try {
            val fUser = Tasks.await(auth.createUserWithEmailAndPassword(mail, pass.trim())).user
                ?: return@withContext Result.failure(Exception("Kayıt oluşturulamadı. Lütfen tekrar deneyin."))
            val newUser = User(
                id = fUser.uid,
                fullName = name,
                phone = "0$digits",
                email = mail,
                userType = if (asOwner) UserType.OWNER else UserType.CUSTOMER
            )
            val saved = saveUserToFirestore(newUser)
            if (saved.isFailure) {
                // Profil yazılamadıysa yarım kalan hesabı sil; kullanıcı tekrar denesin
                runCatching { Tasks.await(fUser.delete()) }
                return@withContext Result.failure(Exception("Profil kaydedilemedi, lütfen tekrar deneyin."))
            }
            runCatching { Tasks.await(fUser.sendEmailVerification()) }
            _currentUser.value = newUser
            _isLoggedIn.value = true
            saveCachedUser(newUser)
            Result.success(newUser)
        } catch (e: Exception) {
            val cause = e.cause ?: e
            Result.failure(Exception(when {
                cause.message?.contains("already in use", ignoreCase = true) == true ->
                    "Bu e-posta ile zaten kayıtlı bir hesap var. Giriş Yap ekranından girin."
                cause.message?.contains("network", ignoreCase = true) == true -> "Ağ bağlantısı hatası. Lütfen bağlantınızı kontrol edin."
                else -> cause.localizedMessage ?: "Kayıt olurken bir hata oluştu."
            }))
        }
    }

}

/** Türkiye cep numarasını 10 haneye (5xxxxxxxxx) çevirir; geçerli değilse null. */
fun normalizeTrPhone(input: String): String? {
    var d = input.filter { it.isDigit() }
    if (d.length == 12 && d.startsWith("90")) d = d.substring(2)
    if (d.length == 11 && d.startsWith("0")) d = d.substring(1)
    return if (d.length == 10 && d.startsWith("5")) d else null
}
