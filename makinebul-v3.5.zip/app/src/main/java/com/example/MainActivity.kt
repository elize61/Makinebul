package com.example

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.ui.Alignment
import androidx.compose.material3.Button
import androidx.compose.ui.text.style.TextAlign
import com.example.ui.theme.TextSecondary
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.activity.enableEdgeToEdge
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RequestQuote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.firebase.FirebaseManager
import com.example.data.model.Machine
import com.example.data.model.OfferStatus
import com.example.data.model.Review
import com.example.data.model.UserType
import com.example.data.repository.AdminRepository
import com.example.data.repository.AuthRepository
import com.example.data.repository.EmergencyRepository
import com.example.data.repository.MachineRepository
import com.example.data.repository.MessageRepository
import com.example.data.repository.OfferRepository
import com.example.data.repository.ReviewRepository
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.admin.AdminDashboardScreen
import com.example.ui.screens.auth.ForgotPasswordScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.auth.RegisterScreen
import com.example.ui.screens.chat.ChatScreen
import com.example.ui.screens.chat.MessagesListScreen
import com.example.ui.screens.emergency.EmergencyCallingScreen
import com.example.ui.screens.emergency.EmergencyHubScreen
import com.example.ui.screens.emergency.EmergencyTrackingScreen
import com.example.ui.screens.emergency.FastEmergencyCallScreen
import com.example.ui.screens.emergency.FastEmergencyOffersScreen
import com.example.ui.screens.emergency.TowTruckDutyScreen
import com.example.data.model.EmergencyStatus
import com.example.ui.screens.favorites.FavoritesScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.home.OwnerHomeScreen
import com.example.ui.screens.machine.AddEditMachineScreen
import com.example.ui.screens.machine.MachineDetailScreen
import com.example.ui.screens.machine.MyListingsScreen
import com.example.ui.screens.map.MapScreen
import com.example.ui.screens.offer.OfferDialog
import com.example.ui.screens.offer.OffersScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.profile.ProviderApplicationScreen
import com.example.ui.screens.search.SearchFilterScreen
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.MakineBulTheme
import com.example.ui.theme.NavyDark
import com.example.ui.theme.StatusWarning

class MainActivity : ComponentActivity() {

    private val authRepository by lazy { AuthRepository() }
    private val machineRepository by lazy { MachineRepository() }
    private val offerRepository by lazy { OfferRepository() }
    private val messageRepository by lazy { MessageRepository() }
    private val emergencyRepository by lazy { EmergencyRepository() }
    private val adminRepository by lazy { AdminRepository() }
    private val reviewRepository by lazy { ReviewRepository() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = androidx.activity.SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        // Safely initialize Firebase
        FirebaseManager.initialize(applicationContext)

        // Request POST_NOTIFICATIONS permission on Android 13+ (API 33+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }

        setContent {
            MakineBulTheme {
                // Android 15+ uçtan uca ekran: sistem çubuklarının altında kalmaması için boşluk bırakılır
                androidx.compose.foundation.layout.Box(
                    modifier = androidx.compose.ui.Modifier
                        .fillMaxSize()
                        .background(androidx.compose.material3.MaterialTheme.colorScheme.background)
                        .windowInsetsPadding(WindowInsets.systemBars)
                ) {
                MakineBulApp(
                    authRepository = authRepository,
                    machineRepository = machineRepository,
                    offerRepository = offerRepository,
                    messageRepository = messageRepository,
                    emergencyRepository = emergencyRepository,
                    adminRepository = adminRepository,
                    reviewRepository = reviewRepository
                )
                }
            }
        }
    }
}

sealed class BottomNavItem(val route: String, val titleTr: String, val icon: ImageVector) {
    object Home : BottomNavItem("bottom_home", "Ana Sayfa", Icons.Filled.Home)
    object Search : BottomNavItem("bottom_search", "Ara", Icons.Filled.Search)
    object MyListings : BottomNavItem("bottom_my_listings", "İlanlarım", Icons.Filled.ListAlt)
    object Offers : BottomNavItem("bottom_offers", "Teklifler", Icons.Filled.RequestQuote)
    object Messages : BottomNavItem("bottom_messages", "Mesajlar", Icons.Filled.Chat)
    object Profile : BottomNavItem("bottom_profile", "Profil", Icons.Filled.Person)
}

@Composable
fun MakineBulApp(
    authRepository: AuthRepository,
    machineRepository: MachineRepository,
    offerRepository: OfferRepository,
    messageRepository: MessageRepository,
    emergencyRepository: EmergencyRepository,
    adminRepository: AdminRepository,
    reviewRepository: ReviewRepository
) {
    val navController = rememberNavController()
    val scope = rememberCoroutineScope()

    val currentUser by authRepository.currentUser.collectAsState()
    val isLoggedIn by authRepository.isLoggedIn.collectAsState()

    val machines by machineRepository.machines.collectAsState()
    val favorites by machineRepository.favorites.collectAsState()
    val offers by offerRepository.offers.collectAsState()
    val messages by messageRepository.messages.collectAsState()
    val emergencyRequests by emergencyRepository.emergencyRequests.collectAsState()
    val providerJobs by emergencyRepository.providerJobs.collectAsState()
    val activeTowDrivers by emergencyRepository.activeTowDrivers.collectAsState()

    val allUsers by adminRepository.allUsers.collectAsState()
    val applications by adminRepository.applications.collectAsState()
    val reports by adminRepository.reports.collectAsState()

    val allReviews by reviewRepository.reviews.collectAsState()

    val context = LocalContext.current

    // Sürücü yola çıkınca gerçek GPS konumu arka plan servisiyle müşteriye canlı gönderilir
    val myDriverId = currentUser?.id
    val activeMissionId = if (myDriverId == null) null else emergencyRequests.firstOrNull {
        it.assignedDriverId == myDriverId && it.status == com.example.data.model.EmergencyStatus.ARRIVING
    }?.id
    val locationPermLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (granted.values.any { it } && activeMissionId != null) {
            com.example.service.DriverLocationService.start(context, activeMissionId)
        } else if (activeMissionId != null) {
            Toast.makeText(context, "Konum izni verilmezse müşteri sizi canlı takip edemez.", Toast.LENGTH_LONG).show()
        }
    }
    LaunchedEffect(activeMissionId) {
        if (activeMissionId != null) {
            if (com.example.util.LocationUtils.hasLocationPermission(context)) {
                com.example.service.DriverLocationService.start(context, activeMissionId)
            } else {
                locationPermLauncher.launch(
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                )
            }
        } else {
            com.example.service.DriverLocationService.stop(context)
        }
    }
    // Misafir (girişsiz) kullanıcı üyelik gerektiren bir eyleme dokunursa giriş penceresi açılır
    var loginPromptReason by remember { mutableStateOf<String?>(null) }
    val guardMember: (String, () -> Unit) -> Unit = { reason, action ->
        if (currentUser == null) loginPromptReason = reason else action()
    }
    val saveShopAddress: suspend (String) -> String = { addr ->
        authRepository.updateShopAddress(addr).fold(
            onSuccess = { "✅ Adres kaydedildi, konumunuz haritada güncellendi." },
            onFailure = { it.message ?: "Adres kaydedilemedi." }
        )
    }
    // Askıya alınmış hesap uyarısı
    val suspendedNotice by authRepository.suspendedNotice.collectAsState()
    LaunchedEffect(suspendedNotice) {
        if (suspendedNotice) {
            Toast.makeText(context, "Hesabınız yönetici tarafından askıya alınmıştır", Toast.LENGTH_LONG).show()
            authRepository.consumeSuspendedNotice()
        }
    }
    // Müşteri ekranlarında yalnızca onaylı ve aktif ilanlar görünür
    val publicMachines = machines.filter { it.status == "approved" && it.isAvailable }
    val sendAdminMessage: (String, String, String) -> Unit = { userId, _, text ->
        messageRepository.sendMessage(
            senderId = currentUser?.id ?: "",
            senderName = "Yönetim",
            receiverId = userId,
            machineId = "",
            machineTitle = "Yönetici Mesajı",
            text = text
        )
    }
    var selectedCategory by remember { mutableStateOf("Tümü") }
    var machineForOfferDialog by remember { mutableStateOf<Machine?>(null) }
    var offerDialogInitialStartDate by remember { mutableStateOf<String?>(null) }
    var offerDialogInitialEndDate by remember { mutableStateOf<String?>(null) }
    var offerDialogInitialPrice by remember { mutableStateOf<Double?>(null) }
    var editingMachine by remember { mutableStateOf<Machine?>(null) }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // Alt menüden istenen sekme (ana kapsayıcı dışındaki sayfalardan geçiş için)
    var requestedTab by remember { mutableStateOf<String?>(null) }
    val showOuterBottomBar = currentRoute != null && (
        (isLoggedIn && currentUser != null && currentRoute != "main" && !isGuestRoute(currentRoute) && currentRoute != "add_edit_machine" && currentRoute != "welcome") ||
        (currentUser == null && (currentRoute == "map_screen" || currentRoute == "favorites_screen" || currentRoute.startsWith("machine_detail/")))
    )

    LaunchedEffect(currentUser?.id) {
        if (currentUser != null) messageRepository.restartListeners()
        machineRepository.restartContacts()
    }

    // Sync current logged in user to FirebaseManager for targeted push notifications
    LaunchedEffect(currentUser) {
        FirebaseManager.setActiveUser(currentUser?.id, currentUser?.userType)
    }

    // Oturum durumu: giriş yapınca giriş/karşılama ekranlarından ana sayfaya; çıkınca karşılama ekranına.
    // Misafir gezinebilen sayfalar (ana sayfa, harita, ilan detayı, acil çağrı) girişe zorlanmaz.
    LaunchedEffect(isLoggedIn) {
        val route = navController.currentBackStackEntry?.destination?.route ?: return@LaunchedEffect
        if (route == "splash") return@LaunchedEffect
        if (isLoggedIn) {
            if (route == "login" || route == "register" || route == "welcome") {
                navController.navigate("main") { popUpTo(0) { inclusive = true } }
            }
        } else if (!isGuestRoute(route)) {
            navController.navigate("welcome") { popUpTo(0) { inclusive = true } }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
      Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .weight(1f)
                .then(if (showOuterBottomBar) Modifier.consumeWindowInsets(WindowInsets.navigationBars) else Modifier)
        ) {
        NavHost(
            navController = navController,
            startDestination = "splash"
        ) {
        // Splash Screen
        composable("splash") {
            SplashScreen(
                onSplashFinished = {
                    val guestReqId = emergencyRepository.getActiveGuestRequestId()
                    val activeGuestReq = if (!guestReqId.isNullOrBlank()) {
                        emergencyRequests.find { it.id == guestReqId && it.status != EmergencyStatus.COMPLETED && it.status != EmergencyStatus.CANCELLED }
                    } else null

                    if (activeGuestReq != null) {
                        navController.navigate("fast_emergency_offers/${activeGuestReq.id}") {
                            popUpTo("splash") { inclusive = true }
                        }
                    } else if (isLoggedIn) {
                        navController.navigate("main") { popUpTo("splash") { inclusive = true } }
                    } else {
                        navController.navigate("welcome") {
                            popUpTo("splash") { inclusive = true }
                        }
                    }
                }
            )
        }

        // Karşılama ekranı: girişe zorlamaz
        composable("welcome") {
            com.example.ui.screens.auth.WelcomeScreen(
                onQuickRegister = { name, phone, email, pass, asOwner -> authRepository.quickRegisterOwner(name, phone, email, pass, asOwner).map { } },
                onGoogleSignIn = { ctx, wantOwner -> authRepository.signInWithGoogle(ctx, wantOwner).map { } },
                onOwnerReady = {
                    navController.navigate("add_edit_machine") {
                        popUpTo("welcome") { inclusive = true }
                    }
                },
                onProviderReady = {
                    navController.navigate("apply_provider") {
                        popUpTo("welcome") { inclusive = true }
                    }
                },
                onSignedIn = { navController.navigate("main") { popUpTo(0) { inclusive = true } } },
                onBrowseAsGuest = { navController.navigate("main") { popUpTo("welcome") { inclusive = true } } },
                onEmergency = { navController.navigate("fast_emergency") },
                onLogin = { navController.navigate("login") }
            )
        }

        // Auth Screens
        composable("login") {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate("main") {
                        popUpTo("login") { inclusive = true }
                    }
                },
                onNavigateToRegister = { navController.navigate("register") },
                onNavigateToForgotPassword = { navController.navigate("forgot_password") },
                onNavigateToFastEmergency = { navController.navigate("fast_emergency") },
                onLoginAction = { email, pass -> authRepository.login(email, pass).map { } }
            )
        }

        composable("register") {
            RegisterScreen(
                onNavigateBack = { navController.popBackStack() },
                onRegisterSuccess = {
                    navController.navigate("main") {
                        popUpTo("register") { inclusive = true }
                    }
                },
                onRegisterAction = { fullName, phone, email, pass, userType, city, district ->
                    authRepository.register(fullName, phone, email, pass, userType, city, district).map { }
                }
            )
        }

        composable("forgot_password") {
            ForgotPasswordScreen(
                onNavigateBack = { navController.popBackStack() },
                onResetPasswordAction = { email -> authRepository.resetPassword(email) }
            )
        }

        // Main App Container with Bottom Navigation
        composable("main") {
            MainContainerScreen(
                onSaveShopAddress = saveShopAddress,
                requestedTab = requestedTab,
                onTabConsumed = { requestedTab = null },
                currentUser = currentUser,
                machines = machines,
                favorites = favorites,
                offers = offers,
                messages = messages,
                selectedCategory = selectedCategory,
                onCategorySelect = { selectedCategory = it },
                onMachineClick = { machine ->
                    navController.navigate("machine_detail/${machine.id}")
                },
                onRequestOfferClick = { machine ->
                    machineForOfferDialog = machine
                },
                onFavoriteToggle = { machineId ->
                    guardMember("Favorilere ekleme") { machineRepository.toggleFavorite(machineId) }
                },
                onSwitchUserTypeRole = {
                    val newType = if (currentUser?.userType == UserType.OWNER) UserType.CUSTOMER else UserType.OWNER
                    authRepository.switchUserType(newType)
                },
                onNavigateToProfile = {
                    navController.navigate("bottom_profile")
                },
                onAddNewListing = {
                    guardMember("İlan verme") {
                        editingMachine = null
                        navController.navigate("add_edit_machine")
                    }
                },
                onEditMachine = { machine ->
                    editingMachine = machine
                    navController.navigate("add_edit_machine")
                },
                onToggleAvailability = { machineId ->
                    machineRepository.toggleAvailability(machineId)
                },
                onDeleteMachine = { machineId ->
                    machineRepository.deleteMachine(machineId)
                },
                onUpdateOfferStatus = { offerId, status ->
                    if (status == OfferStatus.KABUL_EDILDI) {
                        val offer = offers.find { it.id == offerId }
                        val m = offer?.let { machineRepository.getMachineById(it.machineId) }
                        val days = if (offer != null) com.example.util.DateUtils.expandRange(offer.startDate, offer.endDate) else emptyList()
                        if (m != null && days.any { it in m.reservedDates || it in m.blockedDates }) {
                            Toast.makeText(context, "Bu tarihler başka bir kiralamayla dolu, teklif onaylanamadı.", Toast.LENGTH_LONG).show()
                        } else {
                            offerRepository.updateOfferStatus(offerId, status)
                            if (offer != null && days.isNotEmpty()) machineRepository.addReservedDates(offer.machineId, days)
                        }
                    } else {
                        offerRepository.updateOfferStatus(offerId, status)
                    }
                },
                onSelectConversation = { conv ->
                    navController.navigate("chat/${conv.id}")
                },
                onNavigateToMap = {
                    navController.navigate("map_screen")
                },
                onNavigateToFavorites = {
                    navController.navigate("favorites_screen")
                },
                onNavigateToEmergency = {
                    if (currentUser == null) navController.navigate("fast_emergency")
                    else navController.navigate("emergency_hub")
                },
                onNavigateToTowDuty = {
                    navController.navigate("emergency_duty")
                },
                onNavigateToAdmin = {
                    navController.navigate("admin_panel")
                },
                onNavigateToApplyProvider = {
                    navController.navigate("apply_provider")
                },
                onNavigateToTracking = { reqId ->
                    navController.navigate("emergency_tracking/$reqId")
                },
                onLogout = {
                    authRepository.logout()
                    navController.navigate("welcome") { popUpTo(0) { inclusive = true } }
                },
                onRequireLogin = { reason -> loginPromptReason = reason },
                emergencyRepository = emergencyRepository,
                machineRepository = machineRepository,
                adminRepository = adminRepository,
                offerRepository = offerRepository,
                messageRepository = messageRepository
            )
        }

        // Emergency Roadside Assistance Hub Screen
        composable("emergency_hub") {
            val allEmergencyReqs = emergencyRepository.emergencyRequests.collectAsState().value
            val userEmergencyReqs = allEmergencyReqs.filter {
                it.customerId == currentUser?.id
            }

            EmergencyHubScreen(
                currentUser = currentUser,
                userRequests = userEmergencyReqs,
                onBackClick = { navController.popBackStack() },
                onSelectService = { serviceType ->
                    navController.navigate("emergency_request?serviceType=${serviceType.id}")
                },
                onNavigateToTracking = { reqId ->
                    navController.navigate("emergency_tracking/$reqId")
                }
            )
        }

        // Emergency Service Request Screen
        composable(
            route = "emergency_request?serviceType={serviceType}",
            arguments = listOf(
                navArgument("serviceType") {
                    type = NavType.StringType
                    defaultValue = "TOW_TRUCK"
                }
            )
        ) { backStackEntry ->
            val serviceTypeId = backStackEntry.arguments?.getString("serviceType") ?: "TOW_TRUCK"
            val serviceType = com.example.data.model.EmergencyServiceType.values().find { it.id == serviceTypeId } ?: com.example.data.model.EmergencyServiceType.TOW_TRUCK

            EmergencyCallingScreen(
                currentUser = currentUser,
                serviceType = serviceType,
                onBackClick = { navController.popBackStack() },
                onSubmitRequest = { req ->
                    val created = emergencyRepository.createEmergencyRequest(req)
                    navController.navigate("emergency_tracking/${created.id}") {
                        popUpTo("emergency_hub") { inclusive = false }
                    }
                }
            )
        }

        // Emergency Tracking Screen
        composable(
            route = "emergency_tracking/{requestId}",
            arguments = listOf(navArgument("requestId") { type = NavType.StringType })
        ) { backStackEntry ->
            val requestId = backStackEntry.arguments?.getString("requestId") ?: ""
            val activeReq = emergencyRequests.find { it.id == requestId }

            EmergencyTrackingScreen(
                request = activeReq,
                onBackClick = { navController.popBackStack() },
                onCancelClick = {
                    emergencyRepository.cancelRequest(requestId)
                    navController.popBackStack()
                },
                onStartSimulationClick = {},
                onNavigateToChat = { driverId, driverName ->
                    navController.navigate("chat/$driverId")
                },
                onRespondToOffer = { accept ->
                    activeReq?.let { req ->
                        emergencyRepository.respondToPriceOffer(req.id, accept)
                    }
                },
                onAcceptOffer = { driverId ->
                    activeReq?.let { req ->
                        emergencyRepository.acceptOfferByCustomer(req.id, driverId)
                    }
                },
                providerJobs = providerJobs,
                onRate = { rating, comment ->
                    activeReq?.let { req ->
                        emergencyRepository.rateService(req.id, rating, comment, currentUser?.fullName ?: req.customerName)
                    }
                }
            )
        }

        // Fast Emergency Call without Login (Firebase Anonymous Auth)
        composable("fast_emergency") {
            FastEmergencyCallScreen(
                emergencyRepository = emergencyRepository,
                onBackClick = {
                    if (isLoggedIn) navController.popBackStack() else navController.navigate("welcome") {
                        popUpTo("fast_emergency") { inclusive = true }
                    }
                },
                onRequestCreated = { reqId ->
                    navController.navigate("fast_emergency_offers/$reqId") {
                        popUpTo("fast_emergency") { inclusive = true }
                    }
                }
            )
        }

        composable(
            route = "fast_emergency_offers/{requestId}",
            arguments = listOf(navArgument("requestId") { type = NavType.StringType })
        ) { backStackEntry ->
            val reqId = backStackEntry.arguments?.getString("requestId") ?: ""
            FastEmergencyOffersScreen(
                requestId = reqId,
                emergencyRepository = emergencyRepository,
                onBackClick = {
                    if (isLoggedIn) navController.navigate("main") else navController.navigate("welcome")
                },
                onNavigateToHome = {
                    if (isLoggedIn) navController.navigate("main") else navController.navigate("welcome")
                }
            )
        }

        // Emergency Provider Duty & Control Panel Screen
        composable("emergency_duty") {
            val user = currentUser
            val currentDriver = activeTowDrivers.find { it.id == user?.id }
            val resolvedDriverId = user?.id ?: ""
            val resolvedDriverName = user?.fullName?.takeIf { it.isNotBlank() } ?: "Nöbetçi"
            val resolvedDriverPhone = user?.phone?.takeIf { it.isNotBlank() } ?: currentDriver?.phone ?: ""
            val resolvedDriverPlate = savedDriverPlate(context, resolvedDriverId).ifBlank { currentDriver?.plate ?: "" }
            val isOnDuty = currentDriver?.isOnDuty ?: false

            val isTowOperator = user?.userType == UserType.DUTY_TOW
            val isTireOperator = user?.userType == UserType.DUTY_TIRE

            // Open calls waiting for offers or pending customer decision.
            // Stays visible for all drivers until mission is actually started (startedMissionAt != null)
            var passedIds by remember(resolvedDriverId) { mutableStateOf(passedRequestIds(context, resolvedDriverId)) }
            val pendingReqs = emergencyRequests.filter { req ->
                val isNotTerminal = req.status != com.example.data.model.EmergencyStatus.COMPLETED &&
                        req.status != com.example.data.model.EmergencyStatus.CANCELLED
                val isNotStarted = (req.startedMissionAt == null || req.startedMissionAt == 0L) &&
                        req.status != com.example.data.model.EmergencyStatus.ARRIVING &&
                        req.status != com.example.data.model.EmergencyStatus.ARRIVED &&
                        req.status != com.example.data.model.EmergencyStatus.IN_SERVICE
                val serviceMatches = if (isTowOperator) {
                    req.serviceType == com.example.data.model.EmergencyServiceType.TOW_TRUCK
                } else if (isTireOperator) {
                    req.serviceType == com.example.data.model.EmergencyServiceType.TIRE_SERVICE
                } else {
                    true
                }
                isNotTerminal && isNotStarted && serviceMatches && !isClaimedByOtherDriver(req, resolvedDriverId) && req.id !in passedIds
            }

            // Only show active ongoing mission if it has been started and belongs to this driver
            val activeMission = emergencyRequests.find { req ->
                val isTerminal = req.status == com.example.data.model.EmergencyStatus.COMPLETED ||
                        req.status == com.example.data.model.EmergencyStatus.CANCELLED
                val isMissionStarted = (req.startedMissionAt != null && req.startedMissionAt > 0) ||
                        req.status == com.example.data.model.EmergencyStatus.ARRIVING ||
                        req.status == com.example.data.model.EmergencyStatus.ARRIVED ||
                        req.status == com.example.data.model.EmergencyStatus.IN_SERVICE
                val isAssignedToMe = req.assignedDriverId == resolvedDriverId ||
                        (currentDriver != null && req.assignedDriverId == currentDriver.id)
                val serviceMatches = if (isTowOperator) {
                    req.serviceType == com.example.data.model.EmergencyServiceType.TOW_TRUCK
                } else if (isTireOperator) {
                    req.serviceType == com.example.data.model.EmergencyServiceType.TIRE_SERVICE
                } else {
                    true
                }
                !isTerminal && isMissionStarted && isAssignedToMe && serviceMatches
            }

            TowTruckDutyScreen(
                onSaveShopAddress = saveShopAddress,
                currentUser = currentUser,
                isOnDuty = isOnDuty,
                pendingRequests = pendingReqs,
                activeMission = activeMission,
                onBackClick = { navController.popBackStack() },
                onToggleDuty = { newDuty ->
                    emergencyRepository.toggleDriverDuty(resolvedDriverId, newDuty)
                    emergencyRepository.toggleDriverActive(resolvedDriverId, newDuty)
                },
                onAcceptRequest = { reqId ->
                    val success = emergencyRepository.acceptRequest(
                        requestId = reqId,
                        driverId = resolvedDriverId,
                        driverName = resolvedDriverName,
                        driverPhone = resolvedDriverPhone,
                        driverPlate = resolvedDriverPlate
                    )
                    if (!success) {
                        Toast.makeText(context, "⚠️ Bu çağrı başka bir çekici tarafından kabul edilmiş veya işlem başlatılmıştır.", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "✅ Görev kabul edildi! Navigasyonu başlatabilirsiniz.", Toast.LENGTH_SHORT).show()
                    }
                },
                onRejectRequest = { reqId ->
                    passedIds = markRequestPassed(context, resolvedDriverId, reqId)
                },
                onUpdateMissionStatus = { reqId, newStatus ->
                    emergencyRepository.updateRequestStatus(reqId, newStatus)
                },
                onNavigateToChat = { custId, custName ->
                    navController.navigate("chat/$custId")
                },
                onSendPriceOffer = { reqId, price, plate ->
                    val success = emergencyRepository.sendPriceOffer(
                        requestId = reqId,
                        price = price,
                        driverId = resolvedDriverId,
                        driverName = resolvedDriverName,
                        driverPhone = resolvedDriverPhone,
                        driverPlate = plate.ifBlank { resolvedDriverPlate }
                    )
                    if (!success) {
                        Toast.makeText(context, "⚠️ Bu çağrı başka bir çekici tarafından kabul edilmiş veya işlem başlatılmıştır.", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "✅ Fiyat teklifiniz ($price ₺) müşteriye iletildi.", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        // Admin Panel Screen
        composable("admin_panel") {
            AdminDashboardScreen(
                currentUser = currentUser,
                usersList = allUsers,
                machinesList = machines,
                applicationsList = applications,
                reportsList = reports,
                onBackClick = { navController.popBackStack() },
                onToggleUserActive = { userId, active ->
                    scope.launch {
                        adminRepository.toggleUserActiveStatus(userId, active)
                    }
                },
                onDeleteMachine = { machineId ->
                    scope.launch {
                        machineRepository.deleteMachine(machineId)
                    }
                },
                onProcessApplication = { appId, approve, userId, role ->
                    scope.launch {
                        adminRepository.processApplication(appId, approve, userId, role)
                    }
                },
                onSendDirectMessage = sendAdminMessage,
                onSetMachineStatus = { machineId, status, reason -> machineRepository.setMachineStatus(machineId, status, reason) },
                onSetUserRole = { userId, role -> scope.launch { adminRepository.setUserRole(userId, role) } },
                onDeleteUser = { userId -> scope.launch { adminRepository.deleteUser(userId) } },
                emergencyList = emergencyRequests,
                onCancelEmergency = { id -> emergencyRepository.cancelRequest(id) },
                onDeleteEmergency = { id -> emergencyRepository.deleteRequestAsAdmin(id) },
                onResolveReport = { reportId ->
                    scope.launch {
                        adminRepository.resolveReport(reportId)
                    }
                },
                onSendNotification = { title, body ->
                    FirebaseManager.sendPushNotification(title, body, type = "ADMIN_NOTIFICATION")
                },
                onPurgeTestData = {
                    adminRepository.purgeTestData().getOrElse { "Hata: ${it.localizedMessage}" }
                },
                onCloseAllEmergencies = {
                    adminRepository.closeAllOpenEmergencyRequests().getOrElse { "Hata: ${it.localizedMessage}" }
                }
            )
        }

        // Provider Application Screen
        composable("apply_provider") {
            ProviderApplicationScreen(
                currentUser = currentUser,
                onBackClick = { if (!navController.popBackStack()) navController.navigate("main") { popUpTo(0) { inclusive = true } } },
                onSubmitApplication = { app ->
                    scope.launch {
                        adminRepository.submitApplication(app)
                    }
                }
            )
        }

        // Machine Detail Screen with Reviews & Availability Calendar
        composable(
            route = "machine_detail/{machineId}",
            arguments = listOf(navArgument("machineId") { type = NavType.StringType })
        ) { backStackEntry ->
            val machineId = backStackEntry.arguments?.getString("machineId") ?: ""
            val machine = machineRepository.getMachineById(machineId)
            val machineReviews = reviewRepository.getReviewsForMachine(machineId)

            if (machine != null) {
                MachineDetailScreen(
                    machine = machine,
                    isFavorite = favorites.contains(machine.id),
                    reviews = machineReviews,
                    isOwnerView = machine.ownerId == currentUser?.id,
                    reservations = offers.filter {
                        it.machineId == machine.id &&
                            (it.status == OfferStatus.KABUL_EDILDI || it.status == OfferStatus.TAMAMLANDI)
                    },
                    onNavigateBack = { navController.popBackStack() },
                    onRequestOfferClick = {
                        offerDialogInitialStartDate = null
                        offerDialogInitialEndDate = null
                        offerDialogInitialPrice = null
                        machineForOfferDialog = machine
                    },
                    onSendMessageClick = { guardMember("Mesaj gönderme") { navController.navigate("chat/${machine.id}") } },
                    requireMember = { reason, action -> guardMember(reason, action) },
                    onFavoriteToggle = { machineRepository.toggleFavorite(machine.id) },
                    onShowOnMapClick = { navController.navigate("map_screen") },
                    onAddReview = { rating, comment, tags ->
                        reviewRepository.addReview(
                            targetType = "MACHINE",
                            targetId = machine.id,
                            reviewerId = currentUser?.id ?: "",
                            reviewerName = currentUser?.fullName ?: "Kullanıcı",
                            rating = rating,
                            comment = comment,
                            tags = tags
                        )
                    },
                    onDateRangeSelectedForOffer = { startDate, endDate, daysCount, calculatedPrice ->
                        offerDialogInitialStartDate = startDate
                        offerDialogInitialEndDate = endDate
                        offerDialogInitialPrice = calculatedPrice
                        machineForOfferDialog = machine
                    }
                )
            }
        }

        // Add / Edit Machine Screen
        composable("add_edit_machine") {
            AddEditMachineScreen(
                editingMachine = editingMachine,
                currentUser = currentUser,
                onNavigateBack = { if (!navController.popBackStack()) navController.navigate("main") { popUpTo(0) { inclusive = true } } },
                onSaveMachine = { machineObj ->
                    if (editingMachine == null) {
                        machineRepository.addMachine(machineObj, isAdmin = currentUser?.userType == UserType.ADMIN)
                    } else {
                        machineRepository.updateMachine(
                            // Reddedilmiş ilan düzenlenince yeniden onaya gider
                            if (machineObj.status == "rejected") machineObj.copy(status = "pending") else machineObj
                        )
                    }
                    if (!navController.popBackStack()) navController.navigate("main") { popUpTo(0) { inclusive = true } }
                }
            )
        }

        // Interactive Chat Screen
        composable("chat/{id}") { backStackEntry ->
            val id = backStackEntry.arguments?.getString("id") ?: ""
            val machine = machineRepository.getMachineById(id)
            val myId = currentUser?.id ?: ""
            // id bir ilan değilse karşı tarafın kullanıcı kimliğidir (yönetici mesajı, sürücü, şantiye talebi...)
            val directPeerId = if (machine == null) id else ""
            val conversationMsgs = if (machine != null) {
                messageRepository.getMessagesForConversation(id, myId)
            } else {
                messages.filter {
                    (it.senderId == myId && it.receiverId == id) || (it.senderId == id && it.receiverId == myId)
                }.sortedBy { it.timestamp }
            }
            val participantName = machine?.ownerName
                ?: allUsers.find { it.id == id }?.fullName?.takeIf { it.isNotBlank() }
                ?: conversationMsgs.firstOrNull { it.senderId == id }?.senderName
                ?: "Kullanıcı"
            val title = machine?.title ?: conversationMsgs.lastOrNull()?.machineTitle?.takeIf { it.isNotBlank() } ?: "Mesajlaşma"

            ChatScreen(
                participantName = participantName,
                machineTitle = title,
                currentUser = currentUser,
                messages = conversationMsgs,
                onNavigateBack = { navController.popBackStack() },
                onSendMessage = { text ->
                    messageRepository.sendMessage(
                        senderId = myId,
                        senderName = currentUser?.fullName ?: "Kullanıcı",
                        receiverId = if (machine != null && machine.ownerId == myId)
                            (conversationMsgs.lastOrNull { it.senderId != myId }?.senderId ?: "")
                        else (machine?.ownerId ?: directPeerId),
                        machineId = if (machine != null) id else "",
                        machineTitle = title,
                        text = text
                    )
                },
                onDeleteMessage = { msgId ->
                    messageRepository.deleteMessage(msgId)
                },
                onClearChat = {
                    messageRepository.deleteConversation(id, currentUser?.id ?: "")
                }
            )
        }

        // Map Screen
        composable("map_screen") {
            MapScreen(
                machines = publicMachines,
                onMachineClick = { machine ->
                    navController.navigate("machine_detail/${machine.id}")
                }
            )
        }

        // Favorites Screen
        composable("favorites_screen") {
            FavoritesScreen(
                favoriteMachines = machineRepository.getFavoriteMachines().filter { it.status == "approved" },
                onNavigateBack = { navController.popBackStack() },
                onMachineClick = { machine -> navController.navigate("machine_detail/${machine.id}") },
                onRequestOfferClick = { machine ->
                    offerDialogInitialStartDate = null
                    offerDialogInitialEndDate = null
                    offerDialogInitialPrice = null
                    machineForOfferDialog = machine
                },
                onFavoriteToggle = { machineId -> machineRepository.toggleFavorite(machineId) }
            )
        }
    }
        }
        if (showOuterBottomBar) {
            OuterBottomBar(
                items = bottomNavItemsFor(currentUser?.userType),
                onItemClick = { item ->
                    requestedTab = item.route
                    navController.navigate("main") {
                        popUpTo("main") { inclusive = false }
                        launchSingleTop = true
                    }
                }
            )
        }
      }

    loginPromptReason?.let { reason ->
        com.example.ui.screens.auth.LoginRequiredDialog(
            reason = reason,
            onDismiss = { loginPromptReason = null },
            onLogin = { loginPromptReason = null; navController.navigate("login") },
            onRegister = { loginPromptReason = null; navController.navigate("welcome") }
        )
    }

    // Global Offer Dialog Modal (Available across MachineDetailScreen, MainContainerScreen, Favorites, etc.)
    if (currentUser == null && machineForOfferDialog != null) {
        LaunchedEffect(machineForOfferDialog?.id) {
            loginPromptReason = "Teklif verme"
            machineForOfferDialog = null
        }
    }
    machineForOfferDialog?.takeIf { currentUser != null }?.let { dialogMachine ->
        val machine = machineRepository.getMachineById(dialogMachine.id) ?: dialogMachine
        if (!machine.isAvailable) {
            LaunchedEffect(machine.id) {
                Toast.makeText(context, "Bu ilan pasif olduğu için teklif verilemez.", Toast.LENGTH_LONG).show()
                machineForOfferDialog = null
            }
        } else
        OfferDialog(
            machine = machine,
            initialStartDate = offerDialogInitialStartDate,
            initialEndDate = offerDialogInitialEndDate,
            initialPrice = offerDialogInitialPrice,
            onDismiss = {
                machineForOfferDialog = null
                offerDialogInitialStartDate = null
                offerDialogInitialEndDate = null
                offerDialogInitialPrice = null
            },
            onSubmitOffer = { startDate, endDate, hours, loc, desc, price ->
                val requestedDays = com.example.util.DateUtils.expandRange(startDate, endDate)
                val conflict = requestedDays.any { it in machine.reservedDates || it in machine.blockedDates }
                if (requestedDays.isEmpty()) {
                    Toast.makeText(context, "Tarihler okunamadı. Örnek: 15 Ekim 2026 veya takvimden seçin.", Toast.LENGTH_LONG).show()
                } else if (conflict) {
                    Toast.makeText(context, "Seçtiğiniz tarihlerde ilan dolu. Lütfen takvimden müsait günleri seçin.", Toast.LENGTH_LONG).show()
                } else {
                val result = offerRepository.createOffer(
                    customerId = currentUser?.id ?: "",
                    customerName = currentUser?.fullName ?: "Kullanıcı",
                    customerPhone = currentUser?.phone ?: "",
                    customerCompany = if (currentUser?.userType == UserType.CUSTOMER) "Şantiye & Proje Sahibi" else "Yüklenici Firma",
                    customerRating = currentUser?.rating ?: 0.0,
                    customerCompletedJobs = 0,
                    customerCity = currentUser?.city ?: "",
                    customerDistrict = currentUser?.district ?: "",
                    ownerId = machine.ownerId,
                    machineId = machine.id,
                    machineTitle = machine.title,
                    machineCategory = machine.category,
                    startDate = startDate,
                    endDate = endDate,
                    workingHours = hours,
                    location = loc,
                    description = desc,
                    offeredPrice = price
                )
                machineForOfferDialog = null
                offerDialogInitialStartDate = null
                offerDialogInitialEndDate = null
                offerDialogInitialPrice = null

                if (result.isSuccess) {
                    Toast.makeText(context, "Teklifiniz iletildi", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, result.exceptionOrNull()?.message ?: "Teklif iletilemedi.", Toast.LENGTH_LONG).show()
                }
                }
            }
        )
    }
    }
}

fun bottomNavItemsFor(userType: UserType?): List<BottomNavItem> = when (userType) {
    UserType.OWNER -> listOf(BottomNavItem.Home, BottomNavItem.MyListings, BottomNavItem.Offers, BottomNavItem.Profile)
    UserType.DUTY_TOW, UserType.DUTY_TIRE -> listOf(BottomNavItem.Home, BottomNavItem.Profile)
    UserType.ADMIN -> listOf(BottomNavItem.Home, BottomNavItem.Profile)
    null -> listOf(BottomNavItem.Home, BottomNavItem.Search, BottomNavItem.Profile)
    else -> listOf(BottomNavItem.Home, BottomNavItem.Search, BottomNavItem.Offers, BottomNavItem.Profile)
}

/** Ana kapsayıcı dışındaki sayfalarda (harita, acil çağrı, ilan detayı vb.) gösterilen alt menü. */
@Composable
fun OuterBottomBar(items: List<BottomNavItem>, onItemClick: (BottomNavItem) -> Unit) {
    NavigationBar(containerColor = com.example.ui.theme.NavyLight, contentColor = Color.White, tonalElevation = 0.dp) {
        items.forEach { item ->
            NavigationBarItem(
                icon = { Icon(imageVector = item.icon, contentDescription = item.titleTr) },
                label = { Text(text = item.titleTr, fontSize = 11.sp) },
                selected = false,
                colors = NavigationBarItemDefaults.colors(
                    unselectedIconColor = com.example.ui.theme.TextMuted,
                    unselectedTextColor = com.example.ui.theme.TextMuted
                ),
                onClick = { onItemClick(item) },
                modifier = Modifier.testTag("outer_nav_${item.route}")
            )
        }
    }
}

@Composable
fun MainContainerScreen(
    onSaveShopAddress: suspend (String) -> String = { "" },
    requestedTab: String? = null,
    onTabConsumed: () -> Unit = {},
    currentUser: com.example.data.model.User?,
    machines: List<Machine>,
    favorites: Set<String>,
    offers: List<com.example.data.model.Offer>,
    messages: List<com.example.data.model.Message>,
    selectedCategory: String,
    onCategorySelect: (String) -> Unit,
    onMachineClick: (Machine) -> Unit,
    onRequestOfferClick: (Machine) -> Unit,
    onFavoriteToggle: (String) -> Unit,
    onSwitchUserTypeRole: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onAddNewListing: () -> Unit,
    onEditMachine: (Machine) -> Unit,
    onToggleAvailability: (String) -> Unit,
    onDeleteMachine: (String) -> Unit,
    onUpdateOfferStatus: (String, com.example.data.model.OfferStatus) -> Unit,
    onSelectConversation: (com.example.data.model.Conversation) -> Unit,
    onNavigateToMap: () -> Unit,
    onNavigateToFavorites: () -> Unit = {},
    onNavigateToEmergency: () -> Unit = {},
    onNavigateToTowDuty: () -> Unit = {},
    onNavigateToAdmin: () -> Unit = {},
    onNavigateToApplyProvider: () -> Unit = {},
    onNavigateToTracking: (String) -> Unit = {},
    onLogout: () -> Unit,
    onRequireLogin: (String) -> Unit = {},
    emergencyRepository: EmergencyRepository? = null,
    machineRepository: MachineRepository? = null,
    adminRepository: AdminRepository? = null,
    offerRepository: OfferRepository? = null,
    messageRepository: MessageRepository? = null
) {
    val innerNavController = rememberNavController()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val isOwner = currentUser?.userType == UserType.OWNER
    val publicMachinesInner = machines.filter { it.status == "approved" && it.isAvailable }

    val navItems = bottomNavItemsFor(currentUser?.userType)

    LaunchedEffect(requestedTab) {
        val tab = requestedTab
        if (tab != null) {
            innerNavController.navigate(tab) {
                popUpTo(innerNavController.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
            onTabConsumed()
        }
    }

    val navBackStackEntry by innerNavController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: BottomNavItem.Home.route

    val allUsers = adminRepository?.allUsers?.collectAsState()?.value ?: emptyList()
    val applications = adminRepository?.applications?.collectAsState()?.value ?: emptyList()
    val reports = adminRepository?.reports?.collectAsState()?.value ?: emptyList()

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = com.example.ui.theme.NavyLight,
                contentColor = Color.White,
                tonalElevation = 0.dp
            ) {
                navItems.forEach { item ->
                    val isSelected = currentRoute == item.route
                    NavigationBarItem(
                        icon = {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.titleTr
                            )
                        },
                        label = {
                            Text(
                                text = item.titleTr,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        selected = isSelected,
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = BlueAccent,
                            indicatorColor = BluePrimary,
                            unselectedIconColor = com.example.ui.theme.TextMuted,
                            unselectedTextColor = com.example.ui.theme.TextMuted
                        ),
                        onClick = {
                            if (currentRoute != item.route) {
                                innerNavController.navigate(item.route) {
                                    popUpTo(innerNavController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        modifier = Modifier.testTag("nav_${item.route}")
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = innerNavController,
            startDestination = BottomNavItem.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(BottomNavItem.Home.route) {
                when (currentUser?.userType) {
                    UserType.OWNER -> {
                        OwnerHomeScreen(
                            currentUser = currentUser,
                            ownerMachines = machines.filter { it.ownerId == currentUser?.id },
                            ownerOffers = offers.filter { it.ownerId == currentUser?.id },
                            onAddNewListing = onAddNewListing,
                            onEditMachine = onEditMachine,
                            onMachineClick = onMachineClick,
                            onToggleAvailability = onToggleAvailability,
                            onDeleteMachine = onDeleteMachine,
                            onUpdateOfferStatus = onUpdateOfferStatus,
                            onNavigateToOffers = { innerNavController.navigate(BottomNavItem.Offers.route) { popUpTo(innerNavController.graph.findStartDestination().id); launchSingleTop = true } },
                            onNavigateToMessages = { innerNavController.navigate(BottomNavItem.Messages.route) { popUpTo(innerNavController.graph.findStartDestination().id); launchSingleTop = true } },
                            onNavigateToProfile = { innerNavController.navigate(BottomNavItem.Profile.route) { popUpTo(innerNavController.graph.findStartDestination().id); launchSingleTop = true } },
                            onSwitchUserTypeRole = onSwitchUserTypeRole,
                            onNavigateToEmergency = onNavigateToEmergency
                        )
                    }
                    UserType.DUTY_TOW, UserType.DUTY_TIRE -> {
                        val activeDrivers = emergencyRepository?.activeTowDrivers?.collectAsState()?.value ?: emptyList()
                        val user = currentUser
                        val currentDriver = activeDrivers.find { it.id == user?.id }
                        val resolvedDriverId = user?.id ?: ""
                        val resolvedDriverName = user?.fullName?.takeIf { it.isNotBlank() } ?: "Nöbetçi"
                        val resolvedDriverPhone = user?.phone?.takeIf { it.isNotBlank() } ?: currentDriver?.phone ?: ""
                        val resolvedDriverPlate = savedDriverPlate(context, resolvedDriverId).ifBlank { currentDriver?.plate ?: "" }
                        val isOnDuty = currentDriver?.isOnDuty ?: false
                        val allRequests = emergencyRepository?.emergencyRequests?.collectAsState()?.value ?: emptyList()

                        val isTowOperator = currentUser?.userType == UserType.DUTY_TOW
                        val isTireOperator = currentUser?.userType == UserType.DUTY_TIRE

                        var passedIds by remember(resolvedDriverId) { mutableStateOf(passedRequestIds(context, resolvedDriverId)) }
                        val pendingReqs = allRequests.filter { req ->
                            val isOpen = req.status == com.example.data.model.EmergencyStatus.SEARCHING ||
                                    req.status == com.example.data.model.EmergencyStatus.OFFERED
                            val isNotClaimedByOther = !isClaimedByOtherDriver(req, resolvedDriverId)

                            // STRICT SERVICE FILTER: Tow truck operators NEVER receive tire requests!
                            val serviceMatches = if (isTowOperator) {
                                req.serviceType == com.example.data.model.EmergencyServiceType.TOW_TRUCK
                            } else if (isTireOperator) {
                                req.serviceType == com.example.data.model.EmergencyServiceType.TIRE_SERVICE
                            } else {
                                true
                            }

                            isOpen && isNotClaimedByOther && serviceMatches && req.id !in passedIds
                        }

                        val activeMission = allRequests.find { req ->
                            val isOngoing = req.status == com.example.data.model.EmergencyStatus.ACCEPTED ||
                                    req.status == com.example.data.model.EmergencyStatus.ARRIVING ||
                                    req.status == com.example.data.model.EmergencyStatus.ARRIVED ||
                                    req.status == com.example.data.model.EmergencyStatus.IN_SERVICE
                            val isAssignedToMe = req.assignedDriverId == resolvedDriverId ||
                                    (currentDriver != null && req.assignedDriverId == currentDriver.id)
                            isOngoing && isAssignedToMe
                        }

                        TowTruckDutyScreen(
                            onSaveShopAddress = onSaveShopAddress,
                            currentUser = currentUser,
                            isOnDuty = isOnDuty,
                            pendingRequests = pendingReqs,
                            activeMission = activeMission,
                            onBackClick = { innerNavController.navigate(BottomNavItem.Profile.route) },
                            onToggleDuty = { newDuty ->
                                emergencyRepository?.toggleDriverDuty(resolvedDriverId, newDuty)
                                emergencyRepository?.toggleDriverActive(resolvedDriverId, newDuty)
                            },
                            onAcceptRequest = { reqId ->
                                val success = emergencyRepository?.acceptRequest(
                                    requestId = reqId,
                                    driverId = resolvedDriverId,
                                    driverName = resolvedDriverName,
                                    driverPhone = resolvedDriverPhone,
                                    driverPlate = resolvedDriverPlate
                                ) ?: false
                                if (!success) {
                                    Toast.makeText(context, "⚠️ Bu çağrı başka bir çekici tarafından kabul edilmiş veya işlem başlatılmıştır.", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "✅ Görev kabul edildi! Navigasyonu başlatabilirsiniz.", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onRejectRequest = { reqId ->
                                passedIds = markRequestPassed(context, resolvedDriverId, reqId)
                            },
                            onUpdateMissionStatus = { reqId, newStatus ->
                                emergencyRepository?.updateRequestStatus(reqId, newStatus)
                            },
                            onNavigateToChat = { custId, custName ->
                                innerNavController.navigate(BottomNavItem.Messages.route)
                            },
                            onSendPriceOffer = { reqId, price, plate ->
                                val success = emergencyRepository?.sendPriceOffer(
                                    requestId = reqId,
                                    price = price,
                                    driverId = resolvedDriverId,
                                    driverName = resolvedDriverName,
                                    driverPhone = resolvedDriverPhone,
                                    driverPlate = plate.ifBlank { resolvedDriverPlate }
                                ) ?: false
                                if (!success) {
                                    Toast.makeText(context, "⚠️ Bu çağrı başka bir çekici tarafından kabul edilmiş veya işlem başlatılmıştır.", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "✅ Fiyat teklifiniz ($price ₺) müşteriye iletildi.", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )
                    }
                    UserType.ADMIN -> {
                        AdminDashboardScreen(
                            currentUser = currentUser,
                            usersList = allUsers,
                            machinesList = machines,
                            applicationsList = applications,
                            reportsList = reports,
                            onBackClick = { innerNavController.navigate(BottomNavItem.Profile.route) },
                            onToggleUserActive = { userId, active ->
                                scope.launch {
                                    adminRepository?.toggleUserActiveStatus(userId, active)
                                }
                            },
                            onDeleteMachine = { machineId ->
                                scope.launch {
                                    machineRepository?.deleteMachine(machineId)
                                }
                            },
                            onProcessApplication = { appId, approve, userId, role ->
                                scope.launch {
                                    adminRepository?.processApplication(appId, approve, userId, role)
                                }
                            },
                            onSendDirectMessage = { userId, _, text ->
                                messageRepository?.sendMessage(
                                    senderId = currentUser?.id ?: "",
                                    senderName = "Yönetim",
                                    receiverId = userId,
                                    machineId = "",
                                    machineTitle = "Yönetici Mesajı",
                                    text = text
                                )
                            },
                            onSetMachineStatus = { machineId, status, reason -> machineRepository?.setMachineStatus(machineId, status, reason) },
                            onSetUserRole = { userId, role -> scope.launch { adminRepository?.setUserRole(userId, role) } },
                            onDeleteUser = { userId -> scope.launch { adminRepository?.deleteUser(userId) } },
                            emergencyList = emergencyRepository?.emergencyRequests?.collectAsState()?.value ?: emptyList(),
                            onCancelEmergency = { id -> emergencyRepository?.cancelRequest(id) },
                            onDeleteEmergency = { id -> emergencyRepository?.deleteRequestAsAdmin(id) },
                            onResolveReport = { reportId ->
                                scope.launch {
                                    adminRepository?.resolveReport(reportId)
                                }
                            },
                            onSendNotification = { title, body ->
                                FirebaseManager.sendPushNotification(title, body, type = "ADMIN_NOTIFICATION")
                            }
                        )
                    }
                    else -> {
                        val allEmergencyList = emergencyRepository?.emergencyRequests?.collectAsState()?.value ?: emptyList()
                        val userActiveEmergencyList = allEmergencyList.filter {
                            (it.customerId == currentUser?.id) &&
                            it.status != com.example.data.model.EmergencyStatus.COMPLETED &&
                            it.status != com.example.data.model.EmergencyStatus.CANCELLED
                        }

                        HomeScreen(
                            currentUser = currentUser,
                            machines = if (selectedCategory == "Tümü") publicMachinesInner else publicMachinesInner.filter { it.category.equals(selectedCategory, ignoreCase = true) },
                            favorites = favorites,
                            selectedCategory = selectedCategory,
                            activeEmergencyRequests = userActiveEmergencyList,
                            onCategorySelect = onCategorySelect,
                            onSearchClick = { innerNavController.navigate(BottomNavItem.Search.route) },
                            onMachineClick = onMachineClick,
                            onRequestOfferClick = onRequestOfferClick,
                            onFavoriteToggle = onFavoriteToggle,
                            onSwitchUserTypeRole = onSwitchUserTypeRole,
                            onNavigateToProfile = { innerNavController.navigate(BottomNavItem.Profile.route) },
                            onNavigateToEmergency = onNavigateToEmergency,
                            onNavigateToMap = onNavigateToMap,
                            onNavigateToAdmin = onNavigateToAdmin,
                            onNavigateToTracking = onNavigateToTracking
                        )
                    }
                }
            }

            composable(BottomNavItem.Search.route) {
                SearchFilterScreen(
                    machines = publicMachinesInner,
                    favorites = favorites,
                    onMachineClick = onMachineClick,
                    onRequestOfferClick = onRequestOfferClick,
                    onFavoriteToggle = onFavoriteToggle
                )
            }

            composable(BottomNavItem.MyListings.route) {
                MyListingsScreen(
                    ownerMachines = machines.filter { it.ownerId == currentUser?.id },
                    onNavigateBack = { innerNavController.popBackStack() },
                    onAddNewListing = onAddNewListing,
                    onEditMachine = onEditMachine,
                    onMachineClick = onMachineClick,
                    onToggleAvailability = onToggleAvailability,
                    onDeleteMachine = onDeleteMachine
                )
            }

            composable(BottomNavItem.Offers.route) {
                val filteredOffers = if (isOwner) {
                    offers.filter { it.ownerId == currentUser?.id }
                } else {
                    offers.filter { it.customerId == currentUser?.id }
                }

                OffersScreen(
                    currentUser = currentUser,
                    offers = filteredOffers,
                    onUpdateOfferStatus = onUpdateOfferStatus,
                    onNavigateBack = {
                        val popped = innerNavController.popBackStack()
                        if (!popped) {
                            innerNavController.navigate(BottomNavItem.Profile.route) {
                                popUpTo(innerNavController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    },
                    onDeleteOffer = { offerId ->
                        offerRepository?.deleteOffer(offerId)
                    },
                    onDeleteOffers = { ids ->
                        offerRepository?.deleteOffers(ids)
                    },
                    onDeleteAllOffers = {
                        offerRepository?.deleteAllOffersForUser(currentUser?.id ?: "", isOwner)
                    }
                )
            }

            composable(BottomNavItem.Messages.route) {
                val userConversations = if (currentUser == null) {
                    emptyList()
                } else {
                    messages
                        .filter { (it.senderId == currentUser?.id || it.receiverId == currentUser?.id) && !it.id.startsWith("msg_") }
                        .groupBy { if (it.senderId == currentUser?.id) it.receiverId else it.senderId }
                        .map { (otherUserId, userMsgs) ->
                            val sorted = userMsgs.sortedByDescending { it.timestamp }
                            val latest = sorted.first()
                            val otherUserName = if (latest.senderId == currentUser?.id) latest.machineTitle.ifBlank { "Kullanıcı" } else latest.senderName
                            com.example.data.model.Conversation(
                                id = latest.machineId.ifBlank { otherUserId },
                                participantId = otherUserId,
                                participantName = otherUserName,
                                machineTitle = latest.machineTitle,
                                lastMessage = latest.text,
                                lastTimestamp = latest.timestamp,
                                unreadCount = userMsgs.count { !it.isRead && it.receiverId == currentUser?.id }
                            )
                        }
                }

                MessagesListScreen(
                    conversations = userConversations,
                    onSelectConversation = onSelectConversation,
                    onDeleteConversation = { convId ->
                        messageRepository?.deleteConversation(convId, currentUser?.id ?: "")
                    },
                    onDeleteConversations = { convIds ->
                        messageRepository?.deleteConversations(convIds, currentUser?.id ?: "")
                    },
                    onDeleteAllConversations = {
                        messageRepository?.deleteAllMessagesForUser(currentUser?.id ?: "")
                    }
                )
            }

            composable(BottomNavItem.Profile.route) {
                if (currentUser == null) {
                    GuestPlaceholder(onLogin = { onRequireLogin("Profil") })
                } else ProfileScreen(
                    currentUser = currentUser,
                    onNavigateBack = {
                        innerNavController.navigate(BottomNavItem.Home.route) {
                            popUpTo(innerNavController.graph.findStartDestination().id)
                            launchSingleTop = true
                        }
                    },
                    onSwitchUserTypeRole = onSwitchUserTypeRole,
                    onNavigateToOffers = {
                        innerNavController.navigate(BottomNavItem.Offers.route) {
                            launchSingleTop = true
                        }
                    },
                    onNavigateToFavorites = onNavigateToFavorites,
                    onNavigateToMyListings = {
                        innerNavController.navigate(BottomNavItem.MyListings.route) {
                            popUpTo(innerNavController.graph.findStartDestination().id)
                            launchSingleTop = true
                        }
                    },
                    onNavigateToAddListing = onAddNewListing,
                    onNavigateToTowDuty = onNavigateToTowDuty,
                    onNavigateToAdmin = onNavigateToAdmin,
                    onNavigateToApplyProvider = onNavigateToApplyProvider,
                    onNavigateToMap = onNavigateToMap,
                    onSubmitReport = { type, reason, description ->
                        scope.launch {
                            adminRepository?.submitReport(
                                com.example.data.model.Report(
                                    reportId = "rep_${System.currentTimeMillis()}",
                                    reportedBy = currentUser?.id ?: "",
                                    reportedByName = "${currentUser?.fullName ?: ""} (${currentUser?.userType?.labelTr ?: ""})",
                                    targetId = currentUser?.id ?: "",
                                    targetType = type,
                                    reason = reason,
                                    description = description,
                                    createdAt = System.currentTimeMillis()
                                )
                            )
                        }
                    },
                    onLogout = onLogout
                )
            }
        }
    }
}

/** Müşteri başka bir sürücünün teklifini onayladıysa veya görev başladıysa talep bu sürücüden düşer (çekici ve lastikçi için aynı kural). */
fun isClaimedByOtherDriver(req: com.example.data.model.EmergencyRequest, myId: String): Boolean {
    val assigned = req.assignedDriverId
    if (assigned.isNullOrBlank() || assigned == myId) return false
    return req.priceStatus == "CUSTOMER_ACCEPTED" || req.priceStatus == "ACCEPTED" ||
        req.status == com.example.data.model.EmergencyStatus.ACCEPTED ||
        req.status == com.example.data.model.EmergencyStatus.ARRIVING ||
        req.status == com.example.data.model.EmergencyStatus.ARRIVED ||
        req.status == com.example.data.model.EmergencyStatus.IN_SERVICE ||
        (req.startedMissionAt ?: 0L) > 0L
}

/** Sürücünün hizmette kullanacağı plakayı yerel olarak hatırlar. */
fun savedDriverPlate(context: android.content.Context, driverId: String): String =
    context.getSharedPreferences("makinebul_driver", android.content.Context.MODE_PRIVATE)
        .getString("plate_$driverId", "") ?: ""


/** "Pas geç" denilen talepler yalnızca bu sürücünün listesinden gizlenir; talep diğer sürücülerde ve müşteride aynen kalır. */
fun passedRequestIds(context: android.content.Context, driverId: String): Set<String> =
    context.getSharedPreferences("makinebul_driver", android.content.Context.MODE_PRIVATE)
        .getStringSet("passed_$driverId", emptySet())?.toSet() ?: emptySet()

fun markRequestPassed(context: android.content.Context, driverId: String, requestId: String): Set<String> {
    val updated = passedRequestIds(context, driverId) + requestId
    context.getSharedPreferences("makinebul_driver", android.content.Context.MODE_PRIVATE)
        .edit().putStringSet("passed_$driverId", updated).apply()
    return updated
}

/** Misafirin (girişsiz) gezebildiği ekranlar. */
fun isGuestRoute(route: String): Boolean =
    route in setOf("welcome", "login", "register", "forgot_password", "main", "map_screen", "fast_emergency", "favorites_screen", "splash") ||
        route.startsWith("fast_emergency_offers") || route.startsWith("machine_detail/") || route.startsWith("bottom_")

@Composable
fun GuestPlaceholder(onLogin: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
    ) {
        androidx.compose.material3.Text(
            "Profil ve hesap ayarları için üye girişi yapın.",
            color = com.example.ui.theme.TextSecondary,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        androidx.compose.foundation.layout.Spacer(Modifier.height(16.dp))
        androidx.compose.material3.Button(onClick = onLogin) {
            androidx.compose.material3.Text("Giriş Yap / Üye Ol")
        }
    }
}
