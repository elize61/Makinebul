# Yapılan düzeltmeler

## Güvenlik
- firestore.rules / storage.rules: `if true` kaldırıldı. Giriş zorunlu; rol ADMIN'e istemciden yükseltilemez;
  makine/teklif/mesaj/yorum/başvuru yazma-silme sahiplik kontrollü; tanımsız koleksiyonlar kapalı;
  Storage'a yalnızca <5 MB görsel yazılabilir.
- Kuralları yayınlamak için: `firebase deploy --only firestore:rules,storage`
- İlk yönetici Firebase konsolundan elle atanmalı (users/{uid} -> rol: "ADMIN").
- Konsolda **Anonymous Authentication** açık olmalı (dinleyiciler oturum açılınca başlıyor).

## Yayın
- Release artık debug keystore ile imzalanmıyor (KEYSTORE_PATH, STORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD gerekli).
- R8 + shrinkResources açıldı, proguard kuralları eklendi.
- allowBackup=false; kullanılmayan CAMERA, CALL_PHONE, READ_MEDIA_IMAGES, READ_EXTERNAL_STORAGE izinleri kaldırıldı.

## Demo / sahte veri (artık yalnızca debug build)
- Şifresiz demo giriş (example.com / demo*), hızlı test giriş butonları, loginAsDemo
- Sahte otomatik çekici teklifleri, "Simüle Et" kartı
- Açılışta istemci tarafı veri temizliği
- Varsayılan puan 4.8/4.9, 12 yorum, "telefon doğrulandı", İstanbul/Kadıköy varsayılanları sıfırlandı.

## Altyapı
- FirebaseManager.runWhenAuthenticated: tüm Firestore dinleyicileri oturum varken başlar, yoksa anonim giriş yapılır.

## Yapılmadı / sonraki adımlar
- Mesaj, teklif ve acil çağrı okuma izinleri "giriş yapmış herkes". Sorguları kullanıcıya göre daraltıp kuralı sıkılaştırın.
- FCM (arka plan bildirimi), App Check, API anahtarı kısıtlaması.
- users/kullanıcılar ve machines/makineler çift koleksiyonunun birleştirilmesi.
- Büyük dosyaların bölünmesi, ViewModel'e geçiş, Tasks.await -> await(), gerçek testler.
- public/index.html web panelindeki sahte Firebase ayarları gerçek değerlerle değiştirilmeli.

## Harita (ücretsiz / OpenStreetMap)
- Tüm haritalar osmdroid + OpenStreetMap (API anahtarı yok). Eski Canvas tabanlı `EmergencyLiveMap.kt` silindi.
- Google Maps bağımlılıkları (maps-compose, play-services-maps/location), MAPS_API_KEY ve Google Play Services kontrolü kaldırıldı.
- "Yol tarifi / haritada aç" artık `geo:` niyeti (telefondaki herhangi bir harita uygulaması) ya da openstreetmap.org bağlantısı kullanıyor.
- OSM lisansı gereği harita üstüne atıf (© OpenStreetMap) eklendi; tile önbelleği uygulama içinde, depolama izni gerekmiyor.
- Not: tile.openstreetmap.org yoğun kullanım için tasarlanmadı. Kullanıcı sayısı artarsa kendi tile sunucunuzu ya da MapTiler/Stadia gibi ücretsiz planlı bir sağlayıcıyı kullanın.
- Sahte "AdMob test banner" release'te gizlendi.

## v2 — Demo temizliği ve Google Haritalar
- Tüm demo/test kodu silindi: hızlı demo giriş butonları, şifresiz demo girişi, DemoDataProvider, "demo_" kullanıcı kimlikleri,
  sahte otomatik çekici teklifleri, "Simüle Et" kartı, AdMob test banner'ı, açılışta otomatik veri temizliği.
  (Yönetici panelindeki elle temizlik butonu duruyor.)
- Firebase bağlanamazsa artık sahte kullanıcıyla girilmiyor; hata mesajı gösteriliyor.
- "Haritada aç" / "Yol tarifi" / "Navigasyon" butonları telefonda kurulu Google Haritalar uygulamasını açar
  (util/MapLauncher.kt). Kurulu değilse başka bir harita uygulaması, o da yoksa tarayıcı. API anahtarı gerekmez.
- Uygulama içi harita hâlâ ücretsiz OpenStreetMap.
