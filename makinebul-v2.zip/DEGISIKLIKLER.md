# Yapılan düzeltmeler

## Güvenlik
- firestore.rules / storage.rules: `if true` kaldırıldı. Giriş zorunlu; rol ADMIN'e istemciden yükseltilemez;
  makine/teklif/mesaj/yorum/başvuru yazma-silme sahiplik kontrollü; tanımsız koleksiyonlar kapalı;
  Storage'a yalnızca <5 MB görsel yazılabilir.
- Kuralları yayınlamak için: `firebase deploy --only firestore:rules,storage`
- İlk yönetici Firebase konsolundan elle atanmalı (users/{uid} -> rol: "ADMIN").
- Konsolda **Anonymous Authentication** açık olmalı (dinleyiciler oturum açılınca başlıyor).

## Yayın
- Release artık debug keystore ile imzalanmıyor (KEYSTORE_PATH, STORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD gerekli).
- R8 + shrinkResources açıldı, proguard kuralları eklendi.
- allowBackup=false; kullanılmayan CAMERA, CALL_PHONE, READ_MEDIA_IMAGES, READ_EXTERNAL_STORAGE izinleri kaldırıldı.

## Demo / sahte veri (artık yalnızca debug build)
- Şifresiz demo giriş (example.com / demo*), hızlı test giriş butonları, loginAsDemo
- Sahte otomatik çekici teklifleri, "Simüle Et" kartı
- Açılışta istemci tarafı veri temizliği
- Varsayılan puan 4.8/4.9, 12 yorum, "telefon doğrulandı", İstanbul/Kadıköy varsayılanları sıfırlandı.

## Altyapı
- FirebaseManager.runWhenAuthenticated: tüm Firestore dinleyicileri oturum varken başlar, yoksa anonim giriş yapılır.

## Yapılmadı / sonraki adımlar
- Mesaj, teklif ve acil çağrı okuma izinleri "giriş yapmış herkes". Sorguları kullanıcıya göre daraltıp kuralı sıkılaştırın.
- FCM (arka plan bildirimi), App Check, API anahtarı kısıtlaması.
- users/kullanıcılar ve machines/makineler çift koleksiyonunun birleştirilmesi.
- Büyük dosyaların bölünmesi, ViewModel'e geçiş, Tasks.await -> await(), gerçek testler.
- public/index.html web panelindeki sahte Firebase ayarları gerçek değerlerle değiştirilmeli.

## Harita (ücretsiz / OpenStreetMap)
- Tüm haritalar osmdroid + OpenStreetMap (API anahtarı yok). Eski Canvas tabanlı `EmergencyLiveMap.kt` silindi.
- Google Maps bağımlılıkları (maps-compose, play-services-maps/location), MAPS_API_KEY ve Google Play Services kontrolü kaldırıldı.
- "Yol tarifi / haritada aç" artık `geo:` niyeti (telefondaki herhangi bir harita uygulaması) ya da openstreetmap.org bağlantısı kullanıyor.
- OSM lisansı gereği harita üstüne atıf (© OpenStreetMap) eklendi; tile önbelleği uygulama içinde, depolama izni gerekmiyor.
- Not: tile.openstreetmap.org yoğun kullanım için tasarlanmadı. Kullanıcı sayısı artarsa kendi tile sunucunuzu ya da MapTiler/Stadia gibi ücretsiz planlı bir sağlayıcıyı kullanın.
- Sahte "AdMob test banner" release'te gizlendi.

## v2 — Demo temizliği ve Google Haritalar
- Tüm demo/test kodu silindi: hızlı demo giriş butonları, şifresiz demo girişi, DemoDataProvider, "demo_" kullanıcı kimlikleri,
  sahte otomatik çekici teklifleri, "Simüle Et" kartı, AdMob test banner'ı, açılışta otomatik veri temizliği.
  (Yönetici panelindeki elle temizlik butonu duruyor.)
- Firebase bağlanamazsa artık sahte kullanıcıyla girilmiyor; hata mesajı gösteriliyor.
- "Haritada aç" / "Yol tarifi" / "Navigasyon" butonları telefonda kurulu Google Haritalar uygulamasını açar
  (util/MapLauncher.kt). Kurulu değilse başka bir harita uygulaması, o da yoksa tarayıcı. API anahtarı gerekmez.
- Uygulama içi harita hâlâ ücretsiz OpenStreetMap.

## v2.1 — Yönetici temizlik araçları
- Yönetici Paneli → "Veritabanı & Arşiv" sekmesine eklendi:
  - "Eski Demo/Test Kayıtlarını Sil": kimliği "demo" ile başlayan ilan, teklif, mesaj, acil çağrı, yorum vb. siler.
  - "Tüm Açık Acil Çağrıları Kapat": tamamlanmamış tüm acil çağrıları İPTAL yapar.

## v2.2 — Yönetici rolü düzeltmesi
- Giriş sırasında hem `kullanıcılar` hem `users` okunur; ikisinden biri ADMIN ise yönetici kalır.
- Mevcut bir profil girişte artık Firestore'a yeniden yazılmaz (rol "MÜŞTERİ"ye ezilmez).
- Yöneticiler "müşteri/mal sahibi" geçişiyle rolünü kaybedemez.
- Sahte 5.0 puan ve İstanbul/Kadıköy varsayılanları kaldırıldı.

## v2.3 — Çekici paneli, alt menü, mükerrer kart
- Çekici/lastikçi panelinde sabit "Ümraniye, İstanbul" yazısı kaldırıldı. Yerine düzenlenebilir "Dükkan Adresi" kartı geldi.
  Adres kaydedilirken OpenStreetMap (Nominatim) ile koordinata çevrilir ve kullanıcı belgesine `shopAddress`, `latitude`, `longitude` olarak yazılır.
  Çağrı eşleştirme ve haritadaki çekici başlangıç konumu bu koordinatı kullanır. Adres girilmeden hizmet açılamaz.
- Çekici/lastikçi profilinde "Hızlı Menü" kaldırıldı.
- Alt menü artık ana kapsayıcı dışındaki tüm sayfalarda da görünür (harita, acil çağrı, ilan detayı, mesaj, yönetim vb.) ve sekmeye geçişi çalıştırır.
- Müşteri acil çağrı ekranından üyeliksiz "Hızlı Acil Çağrı" kartı kaldırıldı (giriş ekranındaki üyeliksiz çağrı butonu duruyor).
- GeocodeUtils: ifade gövdeli fonksiyonlardaki return derleme hatası düzeltildi.

## v2.3
- Admin: Hızlı Yönetim kartı ve profildeki "Hızlı Menü" başlığı kaldırıldı; kullanıcıya "Mesaj Gönder"; "Şikayetler & Talepler" ve "Onay Bekleyen İlanlar" sekmeleri.
- Askıya alınan hesap (isSuspended / status=SUSPENDED) giriş yapamaz: "Hesabınız yönetici tarafından askıya alınmıştır".
- Müşteri/hizmet veren profilinde "Şikayet / Destek Bildir" formu (reports koleksiyonu).
- İlan: açılır kategori, en fazla 3 galeri fotoğrafı (Storage), adresten konum, yeni ilan status=pending; müşteriler yalnız approved + aktif ilanları görür.
- Haritada Gör ilanın kendi koordinatını Google Haritalar'da açar; Mesaj butonları WhatsApp'a yönlenir.
- Ana sayfa: sade yatay kategori çipleri.
- Çekici/lastikçi: teklifte plaka girilir (sabit plaka ve sahte sürücüler kaldırıldı); onaylanan teklifte talep diğer sürücülerden düşer.
- Pasif ilanda teklif kapalı; onaylanan teklifin tarihleri reservedDates'e yazılır, takvimde kırmızı/seçilemez.
- Grup bildirimleri yalnız çevrimiçi ve ≤50 km sağlayıcılara.
- firestore.rules güncellendi (YENİDEN YAYINLAYIN).

## v2.4
- Sahte varsayılanlar kaldırıldı (puan/yorum/mesafe, sahte isim-telefon-plaka, örnek tarih/konum, "Kaskolu" rozeti, demo kimlikleri); yeni kayıtlar "Yeni" olarak görünür.
- Mesajlar yalnızca gönderen/alıcıya açık (iki sorgu); kullanıcı listesi yalnızca yönetici veya çevrimiçi sürücü sorgusuna açık. firestore.rules güncellendi.
- Askıya alınan kullanıcı oturum açıkken anında çıkarılır.
- İlan reddinde sebep yazılır, ilan sahibine bildirim gider; onayda da bildirim.
- rezerve günler arrayUnion ile eklenir; okunamayan tarihli teklif engellenir.
- Galeri fotoğrafları EXIF yönüne göre düzeltilir. Çevrimdışı sürücü listeleri doğru boşalır.

## v2.5
- Acil çekici/lastikçi talebi artık **gerçek, anlık GPS konumu** olmadan gönderilemez. Sahte "İstanbul merkezi" varsayılan konumu tamamen kaldırıldı; konum alınamazsa net hata gösterilir.
- Çekici/lastikçi **yola çıkınca** uygulama, arka planda çalışan bir konum servisiyle (bildirimde "Konumunuz müşteriyle canlı paylaşılıyor" görünür) gerçek GPS'ini `emergencyRequests` kaydına yazar; müşteri haritada sürücüyü canlı görür, harita iki noktayı kapsayacak şekilde yakınlaşır, kalan km ve dk canlı hesaplanır. Sahte (simüle) hareket kaldırıldı.
- **Talep Havuzu** ve **Dijital Teslim Tutanağı** özellikleri tamamen kaldırıldı (ekranlar, kartlar, rotalar, modeller, depolar, harita pinleri). Firestore kurallarında eski koleksiyonlar sadece yöneticiye açık bırakıldı.
- Manifest: FOREGROUND_SERVICE + FOREGROUND_SERVICE_LOCATION izinleri ve `DriverLocationService` eklendi.
- Güncel `firestore.rules` dosyasını Firebase'de yeniden yayınlayın.

## v2.5.1
- "PAS GEÇ" artık talebi iptal etmiyor; talep yalnızca o sürücünün (çekici veya lastikçi) listesinden gizleniyor. Diğer sürücülerde ve müşteride talep aynen devam ediyor.

## v2.5.2
- GitHub iş akışı artık hem debug APK hem Play Console için imzalı AAB üretir. İlk çalıştırmada yükleme anahtarı otomatik üretilir ve "ANAHTAR-SAKLA-kaybetme" paketinde verilir; GitHub Secrets'a eklenirse sonraki sürümlerde aynı anahtar kullanılır.
- versionCode her çalıştırmada otomatik artar (GitHub çalıştırma numarası).
- Release derlemesinde küçültme (R8) kapatıldı (test edilemediği için çökme riskine karşı).

## v2.5.3
- Uygulama kimliği `com.reisgamestudio.makinebul` oldu. google-services.json'a geçici olarak bu paket adı için kayıt eklendi; Firebase'de bu paket adıyla Android uygulaması eklenip yeni google-services.json ile değiştirilmesi önerilir.

## v2.5.4
- Firebase'den alınan gerçek google-services.json (com.reisgamestudio.makinebul) yerleştirildi.
