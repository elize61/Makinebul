package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.util.LocationUtils
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

/**
 * Cekici/lastikci yola ciktiginda calisir; gercek GPS konumunu
 * emergencyRequests/{id} belgesine yazar. Musteri bu belgeyi canli dinler.
 * Talep ARRIVING durumundan cikinca (vardi/tamamlandi/iptal) kendini durdurur.
 */
class DriverLocationService : Service() {

    private var stopUpdates: (() -> Unit)? = null
    private var registration: ListenerRegistration? = null
    private var requestId: String = ""
    private var lastWrite = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra(EXTRA_REQUEST_ID).orEmpty()
        if (id.isBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (id == requestId) return START_REDELIVER_INTENT
        cleanup()
        requestId = id
        startForegroundCompat()

        val db = try { FirebaseFirestore.getInstance() } catch (e: Throwable) { null }
        if (db == null) { stopSelf(); return START_NOT_STICKY }
        val doc = db.collection("emergencyRequests").document(id)

        registration = doc.addSnapshotListener { snap, _ ->
            if (snap != null && snap.exists()) {
                val status = snap.getString("status")
                if (status != null && status != "ARRIVING") {
                    stopSelf()
                }
            }
        }

        stopUpdates = LocationUtils.startUpdates(this, 4000L, 5f) { lat, lng ->
            val now = System.currentTimeMillis()
            if (now - lastWrite < 3000L) return@startUpdates
            lastWrite = now
            doc.update(
                mapOf(
                    "driverLat" to lat,
                    "driverLng" to lng,
                    "driverLocationUpdatedAt" to now
                )
            ).addOnFailureListener { Log.w(TAG, "konum yazilamadi: ${it.message}") }
        }
        return START_REDELIVER_INTENT
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Canli konum paylasimi", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val n: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("MakineBul - Görev devam ediyor")
            .setContentText("Konumunuz müşteriyle canlı paylaşılıyor")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun cleanup() {
        try { stopUpdates?.invoke() } catch (_: Throwable) {}
        stopUpdates = null
        try { registration?.remove() } catch (_: Throwable) {}
        registration = null
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "DriverLocationService"
        private const val CHANNEL_ID = "driver_live_location"
        private const val NOTIF_ID = 7731
        const val EXTRA_REQUEST_ID = "requestId"

        fun start(context: Context, requestId: String) {
            try {
                ContextCompat.startForegroundService(
                    context,
                    Intent(context, DriverLocationService::class.java).putExtra(EXTRA_REQUEST_ID, requestId)
                )
            } catch (e: Throwable) {
                Log.w(TAG, "servis baslatilamadi: ${e.message}")
            }
        }

        fun stop(context: Context) {
            try { context.stopService(Intent(context, DriverLocationService::class.java)) } catch (_: Throwable) {}
        }
    }
}
