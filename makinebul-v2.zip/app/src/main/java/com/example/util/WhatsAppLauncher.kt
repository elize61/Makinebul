package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.net.URLEncoder

/** "Mesaj Gönder" butonları uygulama içi sohbet yerine WhatsApp'a yönlendirir. */
object WhatsAppLauncher {

    /** Türkiye numaralarını uluslararası biçime (90…) çevirir; rakam dışı karakterleri atar. */
    fun normalizePhone(raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.substring(2)
        if (d.startsWith("0")) d = "90" + d.substring(1)
        if (d.length == 10) d = "90$d"
        return d
    }

    fun open(context: Context, phone: String, message: String) {
        val number = normalizePhone(phone)
        if (number.length < 10) {
            Toast.makeText(context, "Bu kullanıcının telefon numarası bulunamadı.", Toast.LENGTH_LONG).show()
            return
        }
        val url = "https://api.whatsapp.com/send?phone=$number&text=" + URLEncoder.encode(message, "UTF-8")
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "WhatsApp açılamadı.", Toast.LENGTH_LONG).show()
        }
    }
}
