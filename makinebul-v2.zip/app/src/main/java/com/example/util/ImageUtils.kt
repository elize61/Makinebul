package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.example.data.firebase.FirebaseManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.resume

/** Galeriden seçilen fotoğrafı küçültüp (Storage kuralı 5 MB) yükleme için hazırlar. */
object ImageUtils {

    suspend fun compressToCacheJpeg(context: Context, uri: Uri, maxSide: Int = 1280, quality: Int = 82): Uri? =
        withContext(Dispatchers.IO) {
            try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > maxSide * 2 || bounds.outHeight / sample > maxSide * 2) sample *= 2
                val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
                val decoded = context.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it, null, decodeOpts)
                }
                if (decoded == null) {
                    null
                } else {
                    // Telefon kamerası fotoğrafları yan kaydedebilir: EXIF yönüne göre döndür
                    val degrees = try {
                        context.contentResolver.openInputStream(uri)?.use { ins ->
                            when (android.media.ExifInterface(ins).getAttributeInt(
                                android.media.ExifInterface.TAG_ORIENTATION,
                                android.media.ExifInterface.ORIENTATION_NORMAL
                            )) {
                                android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                                android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                                android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                                else -> 0f
                            }
                        } ?: 0f
                    } catch (e: Exception) { 0f }
                    val upright = if (degrees != 0f) {
                        val m = android.graphics.Matrix().apply { postRotate(degrees) }
                        Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, m, true)
                    } else decoded
                    val longest = maxOf(upright.width, upright.height)
                    val scaled = if (longest > maxSide) {
                        val ratio = maxSide.toFloat() / longest
                        Bitmap.createScaledBitmap(
                            upright,
                            (upright.width * ratio).toInt().coerceAtLeast(1),
                            (upright.height * ratio).toInt().coerceAtLeast(1),
                            true
                        )
                    } else upright
                    val file = File(context.cacheDir, "up_${System.nanoTime()}.jpg")
                    FileOutputStream(file).use { out -> scaled.compress(Bitmap.CompressFormat.JPEG, quality, out) }
                    Uri.fromFile(file)
                }
            } catch (e: Exception) {
                null
            }
        }

    /**
     * Kartsız yöntem: fotoğrafı küçültüp "data:image/jpeg;base64,..." metnine çevirir (Firestore'da saklanır).
     * Her fotoğraf yaklaşık 150 KB altına indirilir (3 fotoğraf Firestore'un 1 MB belge sınırının altında kalır).
     */
    suspend fun compressToDataUri(context: Context, uri: Uri, maxBytes: Int = 180_000): String? {
        val attempts = listOf(900 to 65, 800 to 55, 700 to 48, 600 to 40, 500 to 35)
        for ((side, quality) in attempts) {
            val local = compressToCacheJpeg(context, uri, side, quality) ?: return null
            val bytes = withContext(Dispatchers.IO) {
                try { File(local.path!!).readBytes().also { File(local.path!!).delete() } } catch (e: Exception) { null }
            } ?: return null
            if (bytes.size <= maxBytes || side == 500) {
                if (bytes.size > maxBytes * 2) return null
                return "data:image/jpeg;base64," + android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
            }
        }
        return null
    }

    suspend fun uploadToStorage(path: String, uri: Uri): Result<String> =
        suspendCancellableCoroutine { cont ->
            FirebaseManager.uploadImage(
                storagePath = path,
                fileUri = uri,
                onSuccess = { url -> if (cont.isActive) cont.resume(Result.success(url)) },
                onError = { msg -> if (cont.isActive) cont.resume(Result.failure(Exception(msg))) }
            )
        }
}
