package com.example.util

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat

object LocationUtils {
    private const val TAG = "LocationUtils"
    private const val MAX_FIX_AGE_MS = 60_000L
    private const val TIMEOUT_MS = 20_000L

    fun hasLocationPermission(context: Context): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    private fun isFresh(loc: Location): Boolean {
        val ageMs = (android.os.SystemClock.elapsedRealtimeNanos() - loc.elapsedRealtimeNanos) / 1_000_000L
        return ageMs in 0..MAX_FIX_AGE_MS
    }

    /**
     * Gercek, taze bir konum dondurur. Konum alinamazsa onError cagrilir;
     * ASLA sahte/varsayilan koordinat dondurulmez.
     */
    @SuppressLint("MissingPermission")
    fun getCurrentLocation(
        context: Context,
        onSuccess: (latitude: Double, longitude: Double) -> Unit,
        onError: (message: String) -> Unit
    ) {
        if (!hasLocationPermission(context)) {
            onError("Konum izni verilmedi.")
            return
        }
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (lm == null) {
            onError("Konum servisi bulunamadi.")
            return
        }
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            .filter { try { lm.isProviderEnabled(it) } catch (_: Throwable) { false } }
        if (providers.isEmpty()) {
            onError("Telefonunuzun konum (GPS) ozelligi kapali. Lutfen acin.")
            return
        }

        // 1) Sadece cok yeni (<60 sn) son konum kabul edilir
        var best: Location? = null
        for (p in providers) {
            try {
                val loc = lm.getLastKnownLocation(p)
                if (loc != null && isFresh(loc) && (best == null || loc.accuracy < best.accuracy)) best = loc
            } catch (e: Throwable) {
                Log.d(TAG, "lastKnown $p: ${e.message}")
            }
        }
        if (best != null) {
            onSuccess(best.latitude, best.longitude)
            return
        }

        val handler = Handler(Looper.getMainLooper())
        var handled = false
        val listeners = mutableListOf<LocationListener>()
        var cancel: CancellationSignal? = null

        fun finish(loc: Location?, err: String?) {
            if (handled) return
            handled = true
            handler.removeCallbacksAndMessages(null)
            for (l in listeners) { try { lm.removeUpdates(l) } catch (_: Throwable) {} }
            try { cancel?.cancel() } catch (_: Throwable) {}
            if (loc != null) onSuccess(loc.latitude, loc.longitude)
            else onError(err ?: "Konum alinamadi.")
        }

        handler.postDelayed({
            finish(null, "Konum alinamadi. Acik alanda GPS'in acik oldugundan emin olup tekrar deneyin.")
        }, TIMEOUT_MS)

        // 2) Android 11+: taze tek konum istegi
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                cancel = CancellationSignal()
                val executor = ContextCompat.getMainExecutor(context)
                for (p in providers) {
                    lm.getCurrentLocation(p, cancel, executor) { loc: Location? ->
                        if (loc != null) finish(loc, null)
                    }
                }
                return
            } catch (e: Throwable) {
                Log.d(TAG, "getCurrentLocation failed: ${e.message}")
            }
        }

        // 3) Eski surumler: surekli guncelleme ile ilk konum
        try {
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) { finish(location, null) }
                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            listeners.add(listener)
            for (p in providers) lm.requestLocationUpdates(p, 0L, 0f, listener, Looper.getMainLooper())
        } catch (e: Throwable) {
            finish(null, "Konum alinamadi: ${e.message}")
        }
    }

    /** Surekli konum takibi. Donen fonksiyon cagrilinca takip durur. */
    @SuppressLint("MissingPermission")
    fun startUpdates(
        context: Context,
        intervalMs: Long,
        minDistanceM: Float,
        onLocation: (latitude: Double, longitude: Double) -> Unit
    ): () -> Unit {
        if (!hasLocationPermission(context)) return {}
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return {}
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                onLocation(location.latitude, location.longitude)
            }
            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
            try {
                if (lm.isProviderEnabled(p)) {
                    lm.requestLocationUpdates(p, intervalMs, minDistanceM, listener, Looper.getMainLooper())
                }
            } catch (e: Throwable) {
                Log.d(TAG, "startUpdates $p: ${e.message}")
            }
        }
        return { try { lm.removeUpdates(listener) } catch (_: Throwable) {} }
    }
}
