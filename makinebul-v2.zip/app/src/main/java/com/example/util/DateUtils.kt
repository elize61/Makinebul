package com.example.util

import java.util.Calendar
import java.util.Locale

/** Teklifteki serbest metin tarihleri ("15 Ağustos 2026", "2026-08-15", "15.08.2026") ISO günlere çevirir. */
object DateUtils {
    private val months = listOf(
        "ocak", "şubat", "mart", "nisan", "mayıs", "haziran",
        "temmuz", "ağustos", "eylül", "ekim", "kasım", "aralık"
    )

    private fun normalize(s: String): String =
        s.trim().lowercase(Locale("tr", "TR"))
            .replace('ı', 'i').replace('ş', 's').replace('ğ', 'g').replace('ü', 'u').replace('ö', 'o').replace('ç', 'c')

    private val normMonths by lazy { months.map { normalize(it) } }

    /** Geçersizse null. Dönüş: [yıl, ay(1-12), gün] */
    fun parse(text: String): IntArray? {
        val t = text.trim()
        if (t.isEmpty()) return null
        Regex("""^(\d{4})-(\d{1,2})-(\d{1,2})$""").find(t)?.let {
            return intArrayOf(it.groupValues[1].toInt(), it.groupValues[2].toInt(), it.groupValues[3].toInt())
        }
        Regex("""^(\d{1,2})[./](\d{1,2})[./](\d{4})$""").find(t)?.let {
            return intArrayOf(it.groupValues[3].toInt(), it.groupValues[2].toInt(), it.groupValues[1].toInt())
        }
        val m = Regex("""^(\d{1,2})\s+(\S+)\s+(\d{4})$""").find(t) ?: return null
        val monthIndex = normMonths.indexOf(normalize(m.groupValues[2]))
        if (monthIndex < 0) return null
        return intArrayOf(m.groupValues[3].toInt(), monthIndex + 1, m.groupValues[1].toInt())
    }

    /** Bugünden offsetDays sonrasının "15 Ağustos 2026" biçimindeki metni. */
    fun todayTr(offsetDays: Int): String {
        val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, offsetDays) }
        val name = months[c.get(Calendar.MONTH)].replaceFirstChar { it.uppercase(Locale("tr", "TR")) }
        return "${c.get(Calendar.DAY_OF_MONTH)} $name ${c.get(Calendar.YEAR)}"
    }

    fun iso(y: Int, m: Int, d: Int): String = String.format(Locale.ROOT, "%04d-%02d-%02d", y, m, d)

    /** Başlangıç ve bitiş dahil tüm günlerin ISO listesi. Çözümlenemezse boş liste. */
    fun expandRange(start: String, end: String): List<String> {
        val s = parse(start) ?: return emptyList()
        val e = parse(end.ifBlank { start }) ?: return emptyList()
        val cal = Calendar.getInstance().apply { clear(); set(s[0], s[1] - 1, s[2]) }
        val endCal = Calendar.getInstance().apply { clear(); set(e[0], e[1] - 1, e[2]) }
        if (endCal.before(cal)) return listOf(iso(s[0], s[1], s[2]))
        val out = mutableListOf<String>()
        var guard = 0
        while (!cal.after(endCal) && guard < 400) {
            out.add(iso(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH)))
            cal.add(Calendar.DAY_OF_MONTH, 1)
            guard++
        }
        return out
    }
}
