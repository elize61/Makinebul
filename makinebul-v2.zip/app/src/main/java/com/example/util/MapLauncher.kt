package com.example.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/**
 * Harita işlemlerini telefonda kurulu Google Haritalar uygulamasında açar.
 * Google Haritalar yoksa herhangi bir harita uygulamasına, o da yoksa tarayıcıya düşer.
 * API anahtarı gerektirmez.
 */
object MapLauncher {
    private const val GOOGLE_MAPS_PACKAGE = "com.google.android.apps.maps"

    /** Konumu Google Haritalar'da işaretçiyle gösterir. */
    fun openLocation(context: Context, lat: Double, lng: Double, label: String? = null) {
        val name = if (label.isNullOrBlank()) "" else "(${Uri.encode(label)})"
        val geo = Uri.parse("geo:0,0?q=$lat,$lng$name")
        val web = Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lng")
        launch(context, geo, web)
    }

    /** Hedefe adım adım navigasyon başlatır (Google Haritalar). */
    fun openDirections(context: Context, destLat: Double, destLng: Double) {
        val nav = Uri.parse("google.navigation:q=$destLat,$destLng")
        val web = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=$destLat,$destLng")
        launch(context, nav, web)
    }

    /** Başlangıç ve hedef belli olan yol tarifini gösterir. */
    fun openDirections(context: Context, originLat: Double, originLng: Double, destLat: Double, destLng: Double) {
        val web = Uri.parse(
            "https://www.google.com/maps/dir/?api=1&origin=$originLat,$originLng&destination=$destLat,$destLng&travelmode=driving"
        )
        // Web bağlantısı kurulu Google Haritalar uygulamasında açılır; yoksa tarayıcıda.
        launch(context, web, web, preferGoogleApp = true)
    }

    private fun launch(context: Context, uri: Uri, fallback: Uri, preferGoogleApp: Boolean = true) {
        val flags = if (context is android.app.Activity) 0 else Intent.FLAG_ACTIVITY_NEW_TASK
        // 1) Google Haritalar uygulaması
        if (preferGoogleApp && tryStart(context, Intent(Intent.ACTION_VIEW, uri).setPackage(GOOGLE_MAPS_PACKAGE).addFlags(flags))) return
        // 2) Kurulu herhangi bir harita uygulaması
        if (tryStart(context, Intent(Intent.ACTION_VIEW, uri).addFlags(flags))) return
        // 3) Tarayıcı
        if (tryStart(context, Intent(Intent.ACTION_VIEW, fallback).addFlags(flags))) return
        Toast.makeText(context, "Harita açılamadı", Toast.LENGTH_SHORT).show()
    }

    private fun tryStart(context: Context, intent: Intent): Boolean = try {
        context.startActivity(intent)
        true
    } catch (e: ActivityNotFoundException) {
        false
    } catch (e: SecurityException) {
        false
    }
}
