package com.example.util

import android.location.Geocoder
import com.example.data.firebase.FirebaseManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Adres metnini harita koordinatına çevirir. Ücretsiz: OpenStreetMap Nominatim, yedek olarak cihazın Geocoder'ı. */
object GeocodeUtils {
    data class GeoResult(
        val latitude: Double,
        val longitude: Double,
        val displayName: String,
        val city: String = "",
        val district: String = ""
    )

    private val client by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()
    }

    suspend fun geocode(address: String): GeoResult? = withContext(Dispatchers.IO) {
        val query = address.trim()
        if (query.isBlank()) return@withContext null
        fromNominatim(query) ?: fromDeviceGeocoder(query)
    }

    private fun fromNominatim(query: String): GeoResult? {
        return try {
            val url = "https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=1&countrycodes=tr&accept-language=tr&q=" +
                URLEncoder.encode(query, "UTF-8")
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "MakineBul-Android/1.0")
                .build()
            client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) {
                    null
                } else {
                    val arr = JSONArray(resp.body?.string() ?: "[]")
                    if (arr.length() == 0) {
                        null
                    } else {
                        val o = arr.getJSONObject(0)
                        val addr = o.optJSONObject("address")
                        val city = addr?.optString("province").orEmpty()
                            .ifBlank { addr?.optString("city").orEmpty() }
                        val district = addr?.optString("county").orEmpty()
                            .ifBlank { addr?.optString("town").orEmpty() }
                            .ifBlank { addr?.optString("suburb").orEmpty() }
                        GeoResult(
                            latitude = o.getString("lat").toDouble(),
                            longitude = o.getString("lon").toDouble(),
                            displayName = o.optString("display_name", query),
                            city = city,
                            district = district
                        )
                    }
                }
            }
        } catch (e: Exception) {
            null
        }
    }

    @Suppress("DEPRECATION")
    private fun fromDeviceGeocoder(query: String): GeoResult? {
        return try {
            val ctx = FirebaseManager.appContext
            if (ctx == null || !Geocoder.isPresent()) {
                null
            } else {
                val a = Geocoder(ctx, Locale("tr", "TR")).getFromLocationName(query, 1)?.firstOrNull()
                if (a == null) {
                    null
                } else {
                    GeoResult(
                        latitude = a.latitude,
                        longitude = a.longitude,
                        displayName = a.getAddressLine(0) ?: query,
                        city = a.adminArea.orEmpty(),
                        district = a.subAdminArea.orEmpty()
                    )
                }
            }
        } catch (e: Exception) {
            null
        }
    }
}
