package com.example.util

import android.location.Geocoder
import com.example.data.firebase.FirebaseManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.TimeUnit

/** Adres metnini harita koordinatına çevirir. Ücretsiz: OpenStreetMap Nominatim, yedek olarak cihazın Geocoder'ı. */
object GeocodeUtils {
    data class GeoResult(
        val latitude: Double,
        val longitude: Double,
        val displayName: String,
        val city: String = "",
        val district: String = ""
    )

    private val client by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()
    }

    suspend fun geocode(address: String): GeoResult? = withContext(Dispatchers.IO) {
        val query = address.trim()
        if (query.isBlank()) return@withContext null
        fromNominatim(query) ?: fromDeviceGeocoder(query)
    }

    private fun fromNominatim(query: String): GeoResult? = try {
        val url = "https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=1&countrycodes=tr&accept-language=tr&q=" +
            URLEncoder.encode(query, "UTF-8")
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "MakineBul-Android/1.0")
            .build()
        client.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) return@use null
            val arr = JSONArray(resp.body?.string() ?: "[]")
            if (arr.length() == 0) return@use null
            val o = arr.getJSONObject(0)
            val addr = o.optJSONObject("address")
            GeoResult(
                latitude = o.getString("lat").toDouble(),
                longitude = o.getString("lon").toDouble(),
                displayName = o.optString("display_name", query),
                city = addr?.optString("province").orEmpty().ifBlank { addr?.optString("city").orEmpty() },
                district = addr?.optString("county").orEmpty().ifBlank { addr?.optString("town").orEmpty() }
                    .ifBlank { addr?.optString("suburb").orEmpty() }
            )
        }
    } catch (e: Exception) {
        null
    }

    @Suppress("DEPRECATION")
    private fun fromDeviceGeocoder(query: String): GeoResult? = try {
        val ctx = FirebaseManager.appContext ?: return null
        if (!Geocoder.isPresent()) return null
        val a = Geocoder(ctx, Locale("tr", "TR")).getFromLocationName(query, 1)?.firstOrNull() ?: return null
        GeoResult(
            latitude = a.latitude,
            longitude = a.longitude,
            displayName = a.getAddressLine(0) ?: query,
            city = a.adminArea.orEmpty(),
            district = a.subAdminArea.orEmpty()
        )
    } catch (e: Exception) {
        null
    }
}
