package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RequestQuote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.firebase.FirebaseManager
import com.example.data.model.HandoverProtocol
import com.example.data.model.JobDemand
import com.example.data.model.Machine
import com.example.data.model.Review
import com.example.data.model.UserType
import com.example.data.repository.AdminRepository
import com.example.data.repository.AuthRepository
import com.example.data.repository.EmergencyRepository
import com.example.data.repository.HandoverRepository
import com.example.data.repository.JobBidRepository
import com.example.data.repository.JobDemandRepository
import com.example.data.repository.MachineRepository
import com.example.data.repository.MessageRepository
import com.example.data.repository.OfferRepository
import com.example.data.repository.ReviewRepository
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.admin.AdminDashboardScreen
import com.example.ui.screens.auth.ForgotPasswordScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.auth.RegisterScreen
import com.example.ui.screens.chat.ChatScreen
import com.example.ui.screens.chat.MessagesListScreen
import com.example.ui.screens.demands.JobDemandsScreen
import com.example.ui.screens.emergency.EmergencyCallingScreen
import com.example.ui.screens.emergency.EmergencyHubScreen
import com.example.ui.screens.emergency.EmergencyTrackingScreen
import com.example.ui.screens.emergency.FastEmergencyCallScreen
import com.example.ui.screens.emergency.FastEmergencyOffersScreen
import com.example.ui.screens.emergency.TowTruckDutyScreen
import com.example.data.model.EmergencyStatus
import com.example.ui.screens.favorites.FavoritesScreen
import com.example.ui.screens.handover.HandoverScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.home.OwnerHomeScreen
import com.example.ui.screens.machine.AddEditMachineScreen
import com.example.ui.screens.machine.MachineDetailScreen
import com.example.ui.screens.machine.MyListingsScreen
import com.example.ui.screens.map.MapScreen
import com.example.ui.screens.offer.OfferDialog
import com.example.ui.screens.offer.OffersScreen
import com.example.ui.screens.profile.ProfileScreen
import com.example.ui.screens.profile.ProviderApplicationScreen
import com.example.ui.screens.search.SearchFilterScreen
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.MakineBulTheme
import com.example.ui.theme.NavyDark
import com.example.ui.theme.StatusWarning

class MainActivity : ComponentActivity() {

    private val authRepository by lazy { AuthRepository() }
    private val machineRepository by lazy { MachineRepository() }
    private val offerRepository by lazy { OfferRepository() }
    private val messageRepository by lazy { MessageRepository() }
    private val emergencyRepository by lazy { EmergencyRepository() }
    private val adminRepository by lazy { AdminRepository() }
    private val reviewRepository by lazy { ReviewRepository() }
    private val jobDemandRepository by lazy { JobDemandRepository() }
    private val jobBidRepository by lazy { JobBidRepository() }
    private val handoverRepository by lazy { HandoverRepository() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Safely initialize Firebase
        FirebaseManager.initialize(applicationContext)

        // Request POST_NOTIFICATIONS permission on Android 13+ (API 33+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }

        setContent {
            MakineBulTheme {
                MakineBulApp(
                    authRepository = authRepository,
                    machineRepository = machineRepository,
                    offerRepository = offerRepository,
                    messageRepository = messageRepository,
                    emergencyRepository = emergencyRepository,
                    adminRepository = adminRepository,
                    reviewRepository = reviewRepository,
                    jobDemandRepository = jobDemandRepository,
                    jobBidRepository = jobBidRepository,
                    handoverRepository = handoverRepository
                )
            }
        }
    }
}

sealed class BottomNavItem(val route: String, val titleTr: String, val icon: ImageVector) {
    object Home : BottomNavItem("bottom_home", "Ana Sayfa", Icons.Filled.Home)
    object Search : BottomNavItem("bottom_search", "Ara", Icons.Filled.Search)
    object MyListings : BottomNavItem("bottom_my_listings", "İlanlarım", Icons.Filled.ListAlt)
    object Offers : BottomNavItem("bottom_offers", "Teklifler", Icons.Filled.RequestQuote)
    object Messages : BottomNavItem("bottom_messages", "Mesajlar", Icons.Filled.Chat)
    object Profile : BottomNavItem("bottom_profile", "Profil", Icons.Filled.Person)
}

@Composable
fun MakineBulApp(
    authRepository: AuthRepository,
    machineRepository: MachineRepository,
    offerRepository: OfferRepository,
    messageRepository: MessageRepository,
    emergencyRepository: EmergencyRepository,
    adminRepository: AdminRepository,
    reviewRepository: ReviewRepository,
    jobDemandRepository: JobDemandRepository,
    jobBidRepository: JobBidRepository,
    handoverRepository: HandoverRepository
) {
    val navController = rememberNavController()
    val scope = rememberCoroutineScope()

    val currentUser by authRepository.currentUser.collectAsState()
    val isLoggedIn by authRepository.isLoggedIn.collectAsState()

    val machines by machineRepository.machines.collectAsState()
    val favorites by machineRepository.favorites.collectAsState()
    val offers by offerRepository.offers.collectAsState()
    val messages by messageRepository.messages.collectAsState()
    val emergencyRequests by emergencyRepository.emergencyRequests.collectAsState()
    val activeTowDrivers by emergencyRepository.activeTowDrivers.collectAsState()

    val allUsers by adminRepository.allUsers.collectAsState()
    val applications by adminRepository.applications.collectAsState()
    val reports by adminRepository.reports.collectAsState()

    val allReviews by reviewRepository.reviews.collectAsState()
    val jobDemands by jobDemandRepository.demands.collectAsState()
    val jobBids by jobBidRepository.bids.collectAsState()
    val handoverProtocols by handoverRepository.protocols.collectAsState()

    val context = LocalContext.current
    var selectedCategory by remember { mutableStateOf("Tümü") }
    var machineForOfferDialog by remember { mutableStateOf<Machine?>(null) }
    var offerDialogInitialStartDate by remember { mutableStateOf<String?>(null) }
    var offerDialogInitialEndDate by remember { mutableStateOf<String?>(null) }
    var offerDialogInitialPrice by remember { mutableStateOf<Double?>(null) }
    var editingMachine by remember { mutableStateOf<Machine?>(null) }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // Sync current logged in user to FirebaseManager for targeted push notifications
    LaunchedEffect(currentUser) {
        FirebaseManager.setActiveUser(currentUser?.id, currentUser?.userType)
    }

    // Reactive single source-of-truth AuthState navigation listener
    LaunchedEffect(isLoggedIn) {
        if (currentRoute == "splash") return@LaunchedEffect
        if (isLoggedIn) {
            if (currentRoute == "login" || currentRoute == "register") {
                navController.navigate("main") {
                    popUpTo("login") { inclusive = true }
                    popUpTo("register") { inclusive = true }
                }
            }
        } else {
            val isFastEmergency = currentRoute != null && (
                currentRoute == "fast_emergency" ||
                currentRoute!!.startsWith("fast_emergency_offers")
            )
            if (currentRoute != null && currentRoute != "login" && currentRoute != "register" && currentRoute != "forgot_password" && !isFastEmergency) {
                navController.navigate("login") {
                    popUpTo(0) { inclusive = true }
                }
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        NavHost(
            navController = navController,
            startDestination = "splash"
        ) {
        // Splash Screen
        composable("splash") {
            SplashScreen(
                onSplashFinished = {
                    val guestReqId = emergencyRepository.getActiveGuestRequestId()
                    val activeGuestReq = if (!guestReqId.isNullOrBlank()) {
                        emergencyRequests.find { it.id == guestReqId && it.status != EmergencyStatus.COMPLETED && it.status != EmergencyStatus.CANCELLED }
                    } else null

                    if (activeGuestReq != null) {
                        navController.navigate("fast_emergency_offers/${activeGuestReq.id}") {
                            popUpTo("splash") { inclusive = true }
                        }
                    } else if (isLoggedIn) {
                        navController.navigate("main") {
                            popUpTo("splash") { inclusive = true }
                        }
                    } else {
                        navController.navigate("login") {
                            popUpTo("splash") { inclusive = true }
                        }
                    }
                }
            )
        }

        // Auth Screens
        composable("login") {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate("main") {
                        popUpTo("login") { inclusive = true }
                    }
                },
                onNavigateToRegister = { navController.navigate("register") },
                onNavigateToForgotPassword = { navController.navigate("forgot_password") },
                onNavigateToFastEmergency = { navController.navigate("fast_emergency") },
                onLoginAction = { email, pass -> authRepository.login(email, pass).map { } }
            )
        }

        composable("register") {
            RegisterScreen(
                onNavigateBack = { navController.popBackStack() },
                onRegisterSuccess = {
                    navController.navigate("main") {
                        popUpTo("register") { inclusive = true }
                    }
                },
                onRegisterAction = { fullName, phone, email, pass, userType, city, district ->
                    authRepository.register(fullName, phone, email, pass, userType, city, district).map { }
                }
            )
        }

        composable("forgot_password") {
            ForgotPasswordScreen(
                onNavigateBack = { navController.popBackStack() },
                onResetPasswordAction = { email -> authRepository.resetPassword(email) }
            )
        }

        // Main App Container with Bottom Navigation
        composable("main") {
            MainContainerScreen(
                currentUser = currentUser,
                machines = machines,
                favorites = favorites,
                offers = offers,
                messages = messages,
                selectedCategory = selectedCategory,
                onCategorySelect = { selectedCategory = it },
                onMachineClick = { machine ->
                    navController.navigate("machine_detail/${machine.id}")
                },
                onRequestOfferClick = { machine ->
                    machineForOfferDialog = machine
                },
                onFavoriteToggle = { machineId ->
                    machineRepository.toggleFavorite(machineId)
                },
                onSwitchUserTypeRole = {
                    val newType = if (currentUser?.userType == UserType.OWNER) UserType.CUSTOMER else UserType.OWNER
                    authRepository.switchUserType(newType)
                },
                onNavigateToProfile = {
                    navController.navigate("bottom_profile")
                },
                onAddNewListing = {
                    editingMachine = null
                    navController.navigate("add_edit_machine")
                },
                onEditMachine = { machine ->
                    editingMachine = machine
                    navController.navigate("add_edit_machine")
                },
                onToggleAvailability = { machineId ->
                    machineRepository.toggleAvailability(machineId)
                },
                onDeleteMachine = { machineId ->
                    machineRepository.deleteMachine(machineId)
                },
                onUpdateOfferStatus = { offerId, status ->
                    offerRepository.updateOfferStatus(offerId, status)
                },
                onSelectConversation = { conv ->
                    navController.navigate("chat/${conv.id}")
                },
                onNavigateToMap = {
                    navController.navigate("map_screen")
                },
                onNavigateToFavorites = {
                    navController.navigate("favorites_screen")
                },
                onNavigateToEmergency = {
                    navController.navigate("emergency_hub")
                },
                onNavigateToDemands = {
                    navController.navigate("job_demands")
                },
                onNavigateToHandover = {
                    navController.navigate("handover_protocols")
                },
                onNavigateToTowDuty = {
                    navController.navigate("emergency_duty")
                },
                onNavigateToAdmin = {
                    navController.navigate("admin_panel")
                },
                onNavigateToApplyProvider = {
                    navController.navigate("apply_provider")
                },
                onNavigateToTracking = { reqId ->
                    navController.navigate("emergency_tracking/$reqId")
                },
                onLogout = {
                    authRepository.logout()
                },
                emergencyRepository = emergencyRepository,
                machineRepository = machineRepository,
                adminRepository = adminRepository,
                offerRepository = offerRepository,
                messageRepository = messageRepository
            )
        }

        // Job Demands / Şantiye Talep Havuzu Screen
        composable("job_demands") {
            JobDemandsScreen(
                currentUser = currentUser,
                demands = jobDemands,
                bids = jobBids,
                userMachines = machines.filter { it.ownerId == currentUser?.id },
                onBackClick = { navController.popBackStack() },
                onCreateDemand = { newDemand ->
                    jobDemandRepository.createDemand(newDemand)
                },
                onSubmitBid = { newBid ->
                    jobBidRepository.submitBid(newBid)
                    jobDemandRepository.incrementOffersCount(newBid.demandId)
                },
                onUpdateBidStatus = { bidId, status ->
                    jobBidRepository.updateBidStatus(bidId, status)
                },
                onNavigateToChat = { targetUserId, targetUserName ->
                    navController.navigate("chat/$targetUserId")
                },
                onDeleteDemand = { demandId ->
                    jobDemandRepository.deleteDemand(demandId)
                    Toast.makeText(context, "🗑️ İş talebi başarıyla silindi.", Toast.LENGTH_SHORT).show()
                },
                onDeleteBid = { bidId ->
                    jobBidRepository.deleteBid(bidId)
                    Toast.makeText(context, "🗑️ Teklif silindi.", Toast.LENGTH_SHORT).show()
                }
            )
        }

        // Handover / Dijital Teslim Tutanağı Screen
        composable("handover_protocols") {
            HandoverScreen(
                currentUser = currentUser,
                protocols = handoverProtocols,
                machines = machines,
                onBackClick = { navController.popBackStack() },
                onCreateProtocol = { proto ->
                    handoverRepository.createProtocol(proto)
                },
                onCompleteProtocol = { protoId, finalHours, finalFuel, notes ->
                    handoverRepository.completeProtocol(protoId, finalHours, finalFuel, notes)
                }
            )
        }

        // Emergency Roadside Assistance Hub Screen
        composable("emergency_hub") {
            val allEmergencyReqs = emergencyRepository.emergencyRequests.collectAsState().value
            val userEmergencyReqs = allEmergencyReqs.filter {
                it.customerId == currentUser?.id
            }

            EmergencyHubScreen(
                currentUser = currentUser,
                userRequests = userEmergencyReqs,
                onBackClick = { navController.popBackStack() },
                onSelectService = { serviceType ->
                    navController.navigate("emergency_request?serviceType=${serviceType.id}")
                },
                onNavigateToTracking = { reqId ->
                    navController.navigate("emergency_tracking/$reqId")
                },
                onFastEmergencyClick = {
                    navController.navigate("fast_emergency")
                }
            )
        }

        // Emergency Service Request Screen
        composable(
            route = "emergency_request?serviceType={serviceType}",
            arguments = listOf(
                navArgument("serviceType") {
                    type = NavType.StringType
                    defaultValue = "TOW_TRUCK"
                }
            )
        ) { backStackEntry ->
            val serviceTypeId = backStackEntry.arguments?.getString("serviceType") ?: "TOW_TRUCK"
            val serviceType = com.example.data.model.EmergencyServiceType.values().find { it.id == serviceTypeId } ?: com.example.data.model.EmergencyServiceType.TOW_TRUCK

            EmergencyCallingScreen(
                currentUser = currentUser,
                serviceType = serviceType,
                onBackClick = { navController.popBackStack() },
                onSubmitRequest = { req ->
                    val created = emergencyRepository.createEmergencyRequest(req)
                    navController.navigate("emergency_tracking/${created.id}") {
                        popUpTo("emergency_hub") { inclusive = false }
                    }
                }
            )
        }

        // Emergency Tracking Screen
        composable(
            route = "emergency_tracking/{requestId}",
            arguments = listOf(navArgument("requestId") { type = NavType.StringType })
        ) { backStackEntry ->
            val requestId = backStackEntry.arguments?.getString("requestId") ?: ""
            val activeReq = emergencyRequests.find { it.id == requestId } ?: emergencyRequests.firstOrNull()

            EmergencyTrackingScreen(
                request = activeReq,
                onBackClick = { navController.popBackStack() },
                onCancelClick = {
                    emergencyRepository.cancelRequest(requestId)
                    navController.popBackStack()
                },
                onStartSimulationClick = {
                    emergencyRepository.simulateDriverProgress(requestId)
                },
                onNavigateToChat = { driverId, driverName ->
                    navController.navigate("chat/$driverId")
                },
                onRespondToOffer = { accept ->
                    activeReq?.let { req ->
                        emergencyRepository.respondToPriceOffer(req.id, accept)
                    }
                },
                onAcceptOffer = { driverId ->
                    activeReq?.let { req ->
                        emergencyRepository.acceptOfferByCustomer(req.id, driverId)
                    }
                }
            )
        }

        // Fast Emergency Call without Login (Firebase Anonymous Auth)
        composable("fast_emergency") {
            FastEmergencyCallScreen(
                emergencyRepository = emergencyRepository,
                onBackClick = {
                    if (isLoggedIn) navController.popBackStack() else navController.navigate("login") {
                        popUpTo("fast_emergency") { inclusive = true }
                    }
                },
                onRequestCreated = { reqId ->
                    navController.navigate("fast_emergency_offers/$reqId") {
                        popUpTo("fast_emergency") { inclusive = true }
                    }
                }
            )
        }

        composable(
            route = "fast_emergency_offers/{requestId}",
            arguments = listOf(navArgument("requestId") { type = NavType.StringType })
        ) { backStackEntry ->
            val reqId = backStackEntry.arguments?.getString("requestId") ?: ""
            FastEmergencyOffersScreen(
                requestId = reqId,
                emergencyRepository = emergencyRepository,
                onBackClick = {
                    if (isLoggedIn) navController.navigate("main") else navController.navigate("login")
                },
                onNavigateToHome = {
                    if (isLoggedIn) navController.navigate("main") else navController.navigate("login")
                }
            )
        }

        // Emergency Provider Duty & Control Panel Screen
        composable("emergency_duty") {
            val user = currentUser
            val currentDriver = activeTowDrivers.find { it.id == user?.id } ?: activeTowDrivers.firstOrNull()
            val resolvedDriverId = user?.id?.takeIf { it.isNotBlank() } ?: currentDriver?.id ?: "tow_driver_1"
            val resolvedDriverName = user?.fullName?.takeIf { it.isNotBlank() } ?: currentDriver?.name ?: "Ahmet Çekici & Mobil Lastik"
            val resolvedDriverPhone = user?.phone?.takeIf { it.isNotBlank() } ?: currentDriver?.phone ?: "+90 532 111 22 33"
            val resolvedDriverPlate = currentDriver?.plate ?: "34 ABC 123"
            val isOnDuty = currentDriver?.isOnDuty ?: true

            val isTowOperator = user?.userType == UserType.DUTY_TOW
            val isTireOperator = user?.userType == UserType.DUTY_TIRE

            // Open calls waiting for offers or pending customer decision.
            // Stays visible for all drivers until mission is actually started (startedMissionAt != null)
            val pendingReqs = emergencyRequests.filter { req ->
                val isNotTerminal = req.status != com.example.data.model.EmergencyStatus.COMPLETED &&
                        req.status != com.example.data.model.EmergencyStatus.CANCELLED
                val isNotStarted = (req.startedMissionAt == null || req.startedMissionAt == 0L) &&
                        req.status != com.example.data.model.EmergencyStatus.ARRIVING &&
                        req.status != com.example.data.model.EmergencyStatus.ARRIVED &&
                        req.status != com.example.data.model.EmergencyStatus.IN_SERVICE
                val serviceMatches = if (isTowOperator) {
                    req.serviceType == com.example.data.model.EmergencyServiceType.TOW_TRUCK
                } else if (isTireOperator) {
                    req.serviceType == com.example.data.model.EmergencyServiceType.TIRE_SERVICE
                } else {
                    true
                }
                isNotTerminal && isNotStarted && serviceMatches
            }

            // Only show active ongoing mission if it has been started and belongs to this driver
            val activeMission = emergencyRequests.find { req ->
                val isTerminal = req.status == com.example.data.model.EmergencyStatus.COMPLETED ||
                        req.status == com.example.data.model.EmergencyStatus.CANCELLED
                val isMissionStarted = (req.startedMissionAt != null && req.startedMissionAt > 0) ||
                        req.status == com.example.data.model.EmergencyStatus.ARRIVING ||
                        req.status == com.example.data.model.EmergencyStatus.ARRIVED ||
                        req.status == com.example.data.model.EmergencyStatus.IN_SERVICE
                val isAssignedToMe = req.assignedDriverId == resolvedDriverId ||
                        (currentDriver != null && req.assignedDriverId == currentDriver.id) ||
                        (req.assignedDriverId == "tow_driver_1" && isTowOperator)
                val serviceMatches = if (isTowOperator) {
                    req.serviceType == com.example.data.model.EmergencyServiceType.TOW_TRUCK
                } else if (isTireOperator) {
                    req.serviceType == com.example.data.model.EmergencyServiceType.TIRE_SERVICE
                } else {
                    true
                }
                !isTerminal && isMissionStarted && isAssignedToMe && serviceMatches
            }

            TowTruckDutyScreen(
                currentUser = currentUser,
                isOnDuty = isOnDuty,
                pendingRequests = pendingReqs,
                activeMission = activeMission,
                onBackClick = { navController.popBackStack() },
                onToggleDuty = { newDuty ->
                    emergencyRepository.toggleDriverDuty(resolvedDriverId, newDuty)
                    emergencyRepository.toggleDriverActive(resolvedDriverId, newDuty)
                },
                onAcceptRequest = { reqId ->
                    val success = emergencyRepository.acceptRequest(
                        requestId = reqId,
                        driverId = resolvedDriverId,
                        driverName = resolvedDriverName,
                        driverPhone = resolvedDriverPhone,
                        driverPlate = resolvedDriverPlate
                    )
                    if (!success) {
                        Toast.makeText(context, "⚠️ Bu çağrı başka bir çekici tarafından kabul edilmiş veya işlem başlatılmıştır.", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "✅ Görev kabul edildi! Navigasyonu başlatabilirsiniz.", Toast.LENGTH_SHORT).show()
                    }
                },
                onRejectRequest = { reqId ->
                    emergencyRepository.cancelRequest(reqId)
                },
                onUpdateMissionStatus = { reqId, newStatus ->
                    emergencyRepository.updateRequestStatus(reqId, newStatus)
                },
                onNavigateToChat = { custId, custName ->
                    navController.navigate("chat/$custId")
                },
                onSendPriceOffer = { reqId, price ->
                    val success = emergencyRepository.sendPriceOffer(
                        requestId = reqId,
                        price = price,
                        driverId = resolvedDriverId,
                        driverName = resolvedDriverName,
                        driverPhone = resolvedDriverPhone,
                        driverPlate = resolvedDriverPlate
                    )
                    if (!success) {
                        Toast.makeText(context, "⚠️ Bu çağrı başka bir çekici tarafından kabul edilmiş veya işlem başlatılmıştır.", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "✅ Fiyat teklifiniz ($price ₺) müşteriye iletildi.", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        // Admin Panel Screen
        composable("admin_panel") {
            AdminDashboardScreen(
                currentUser = currentUser,
                usersList = allUsers,
                machinesList = machines,
                applicationsList = applications,
                reportsList = reports,
                onBackClick = { navController.popBackStack() },
                onToggleUserActive = { userId, active ->
                    scope.launch {
                        adminRepository.toggleUserActiveStatus(userId, active)
                    }
                },
                onDeleteMachine = { machineId ->
                    scope.launch {
                        machineRepository.deleteMachine(machineId)
                    }
                },
                onProcessApplication = { appId, approve, userId, role ->
                    scope.launch {
                        adminRepository.processApplication(appId, approve, userId, role)
                    }
                },
                onResolveReport = { reportId ->
                    scope.launch {
                        adminRepository.resolveReport(reportId)
                    }
                },
                onSendNotification = { title, body ->
                    FirebaseManager.sendPushNotification(title, body, type = "ADMIN_NOTIFICATION")
                }
            )
        }

        // Provider Application Screen
        composable("apply_provider") {
            ProviderApplicationScreen(
                currentUser = currentUser,
                onBackClick = { navController.popBackStack() },
                onSubmitApplication = { app ->
                    scope.launch {
                        adminRepository.submitApplication(app)
                    }
                }
            )
        }

        // Machine Detail Screen with Reviews & Availability Calendar
        composable(
            route = "machine_detail/{machineId}",
            arguments = listOf(navArgument("machineId") { type = NavType.StringType })
        ) { backStackEntry ->
            val machineId = backStackEntry.arguments?.getString("machineId") ?: ""
            val machine = machineRepository.getMachineById(machineId)
            val machineReviews = reviewRepository.getReviewsForMachine(machineId)

            if (machine != null) {
                MachineDetailScreen(
                    machine = machine,
                    isFavorite = favorites.contains(machine.id),
                    reviews = machineReviews,
                    onNavigateBack = { navController.popBackStack() },
                    onRequestOfferClick = {
                        offerDialogInitialStartDate = null
                        offerDialogInitialEndDate = null
                        offerDialogInitialPrice = null
                        machineForOfferDialog = machine
                    },
                    onSendMessageClick = { navController.navigate("chat/${machine.id}") },
                    onFavoriteToggle = { machineRepository.toggleFavorite(machine.id) },
                    onShowOnMapClick = { navController.navigate("map_screen") },
                    onAddReview = { rating, comment, tags ->
                        reviewRepository.addReview(
                            targetType = "MACHINE",
                            targetId = machine.id,
                            reviewerId = currentUser?.id ?: "",
                            reviewerName = currentUser?.fullName ?: "Ahmet Yılmaz",
                            rating = rating,
                            comment = comment,
                            tags = tags
                        )
                    },
                    onDateRangeSelectedForOffer = { startDate, endDate, daysCount, calculatedPrice ->
                        offerDialogInitialStartDate = startDate
                        offerDialogInitialEndDate = endDate
                        offerDialogInitialPrice = calculatedPrice
                        machineForOfferDialog = machine
                    }
                )
            }
        }

        // Add / Edit Machine Screen
        composable("add_edit_machine") {
            AddEditMachineScreen(
                editingMachine = editingMachine,
                currentUser = currentUser,
                onNavigateBack = { navController.popBackStack() },
                onSaveMachine = { machineObj ->
                    if (editingMachine == null) {
                        machineRepository.addMachine(machineObj)
                    } else {
                        machineRepository.updateMachine(machineObj)
                    }
                    navController.popBackStack()
                }
            )
        }

        // Interactive Chat Screen
        composable("chat/{id}") { backStackEntry ->
            val id = backStackEntry.arguments?.getString("id") ?: ""
            val machine = machineRepository.getMachineById(id)
            val participantName = machine?.ownerName ?: "Demir Makine Kiralama"
            val title = machine?.title ?: "Liebherr LTM 1100 Mobil Vinç"

            val conversationMsgs = messageRepository.getMessagesForConversation(id, currentUser?.id ?: "")

            ChatScreen(
                participantName = participantName,
                machineTitle = title,
                currentUser = currentUser,
                messages = conversationMsgs,
                onNavigateBack = { navController.popBackStack() },
                onSendMessage = { text ->
                    messageRepository.sendMessage(
                        senderId = currentUser?.id ?: "",
                        senderName = currentUser?.fullName ?: "Ahmet Yılmaz",
                        receiverId = machine?.ownerId ?: "",
                        machineId = id,
                        machineTitle = title,
                        text = text
                    )
                },
                onDeleteMessage = { msgId ->
                    messageRepository.deleteMessage(msgId)
                },
                onClearChat = {
                    messageRepository.deleteConversation(id, currentUser?.id ?: "")
                }
            )
        }

        // Map Screen
        composable("map_screen") {
            MapScreen(
                machines = machines,
                demands = jobDemands,
                onMachineClick = { machine ->
                    navController.navigate("machine_detail/${machine.id}")
                },
                onDemandClick = { demand ->
                    navController.navigate("job_demands")
                }
            )
        }

        // Favorites Screen
        composable("favorites_screen") {
            FavoritesScreen(
                favoriteMachines = machineRepository.getFavoriteMachines(),
                onNavigateBack = { navController.popBackStack() },
                onMachineClick = { machine -> navController.navigate("machine_detail/${machine.id}") },
                onRequestOfferClick = { machine ->
                    offerDialogInitialStartDate = null
                    offerDialogInitialEndDate = null
                    offerDialogInitialPrice = null
                    machineForOfferDialog = machine
                },
                onFavoriteToggle = { machineId -> machineRepository.toggleFavorite(machineId) }
            )
        }
    }

    // Global Offer Dialog Modal (Available across MachineDetailScreen, MainContainerScreen, Favorites, etc.)
    machineForOfferDialog?.let { machine ->
        OfferDialog(
            machine = machine,
            initialStartDate = offerDialogInitialStartDate,
            initialEndDate = offerDialogInitialEndDate,
            initialPrice = offerDialogInitialPrice,
            onDismiss = {
                machineForOfferDialog = null
                offerDialogInitialStartDate = null
                offerDialogInitialEndDate = null
                offerDialogInitialPrice = null
            },
            onSubmitOffer = { startDate, endDate, hours, loc, desc, price ->
                val result = offerRepository.createOffer(
                    customerId = currentUser?.id ?: "",
                    customerName = currentUser?.fullName ?: "Ahmet Yılmaz",
                    customerPhone = currentUser?.phone ?: "+90 532 111 22 33",
                    customerCompany = if (currentUser?.userType == UserType.CUSTOMER) "Şantiye & Proje Sahibi" else "Yüklenici Firma",
                    customerRating = currentUser?.rating ?: 4.9,
                    customerCompletedJobs = 12,
                    customerCity = currentUser?.city ?: "İstanbul",
                    customerDistrict = currentUser?.district ?: "Kadıköy",
                    ownerId = machine.ownerId,
                    machineId = machine.id,
                    machineTitle = machine.title,
                    machineCategory = machine.category,
                    startDate = startDate,
                    endDate = endDate,
                    workingHours = hours,
                    location = loc,
                    description = desc,
                    offeredPrice = price
                )
                machineForOfferDialog = null
                offerDialogInitialStartDate = null
                offerDialogInitialEndDate = null
                offerDialogInitialPrice = null

                if (result.isSuccess) {
                    Toast.makeText(context, "Teklifiniz iletildi", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, result.exceptionOrNull()?.message ?: "Teklif iletilemedi.", Toast.LENGTH_LONG).show()
                }
            }
        )
    }
    }
}

@Composable
fun MainContainerScreen(
    currentUser: com.example.data.model.User?,
    machines: List<Machine>,
    favorites: Set<String>,
    offers: List<com.example.data.model.Offer>,
    messages: List<com.example.data.model.Message>,
    selectedCategory: String,
    onCategorySelect: (String) -> Unit,
    onMachineClick: (Machine) -> Unit,
    onRequestOfferClick: (Machine) -> Unit,
    onFavoriteToggle: (String) -> Unit,
    onSwitchUserTypeRole: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onAddNewListing: () -> Unit,
    onEditMachine: (Machine) -> Unit,
    onToggleAvailability: (String) -> Unit,
    onDeleteMachine: (String) -> Unit,
    onUpdateOfferStatus: (String, com.example.data.model.OfferStatus) -> Unit,
    onSelectConversation: (com.example.data.model.Conversation) -> Unit,
    onNavigateToMap: () -> Unit,
    onNavigateToFavorites: () -> Unit = {},
    onNavigateToEmergency: () -> Unit = {},
    onNavigateToDemands: () -> Unit = {},
    onNavigateToHandover: () -> Unit = {},
    onNavigateToTowDuty: () -> Unit = {},
    onNavigateToAdmin: () -> Unit = {},
    onNavigateToApplyProvider: () -> Unit = {},
    onNavigateToTracking: (String) -> Unit = {},
    onLogout: () -> Unit,
    emergencyRepository: EmergencyRepository? = null,
    machineRepository: MachineRepository? = null,
    adminRepository: AdminRepository? = null,
    offerRepository: OfferRepository? = null,
    messageRepository: MessageRepository? = null
) {
    val innerNavController = rememberNavController()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val isOwner = currentUser?.userType == UserType.OWNER

    val navItems = when (currentUser?.userType) {
        UserType.OWNER -> listOf(
            BottomNavItem.Home,
            BottomNavItem.MyListings,
            BottomNavItem.Offers,
            BottomNavItem.Messages,
            BottomNavItem.Profile
        )
        UserType.DUTY_TOW, UserType.DUTY_TIRE -> listOf(
            BottomNavItem.Home,
            BottomNavItem.Messages,
            BottomNavItem.Profile
        )
        UserType.ADMIN -> listOf(
            BottomNavItem.Home,
            BottomNavItem.Messages,
            BottomNavItem.Profile
        )
        else -> listOf(
            BottomNavItem.Home,
            BottomNavItem.Search,
            BottomNavItem.Offers,
            BottomNavItem.Messages,
            BottomNavItem.Profile
        )
    }

    val navBackStackEntry by innerNavController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: BottomNavItem.Home.route

    val allUsers = adminRepository?.allUsers?.collectAsState()?.value ?: emptyList()
    val applications = adminRepository?.applications?.collectAsState()?.value ?: emptyList()
    val reports = adminRepository?.reports?.collectAsState()?.value ?: emptyList()

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = NavyDark,
                contentColor = Color.White
            ) {
                navItems.forEach { item ->
                    val isSelected = currentRoute == item.route
                    NavigationBarItem(
                        icon = {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.titleTr
                            )
                        },
                        label = {
                            Text(
                                text = item.titleTr,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        selected = isSelected,
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = BlueAccent,
                            indicatorColor = BluePrimary,
                            unselectedIconColor = Color.LightGray,
                            unselectedTextColor = Color.LightGray
                        ),
                        onClick = {
                            if (currentRoute != item.route) {
                                innerNavController.navigate(item.route) {
                                    popUpTo(innerNavController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        modifier = Modifier.testTag("nav_${item.route}")
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = innerNavController,
            startDestination = BottomNavItem.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(BottomNavItem.Home.route) {
                when (currentUser?.userType) {
                    UserType.OWNER -> {
                        OwnerHomeScreen(
                            currentUser = currentUser,
                            ownerMachines = machines.filter { it.ownerId == currentUser?.id },
                            ownerOffers = offers.filter { it.ownerId == currentUser?.id },
                            onAddNewListing = onAddNewListing,
                            onEditMachine = onEditMachine,
                            onToggleAvailability = onToggleAvailability,
                            onDeleteMachine = onDeleteMachine,
                            onUpdateOfferStatus = onUpdateOfferStatus,
                            onNavigateToOffers = { innerNavController.navigate(BottomNavItem.Offers.route) { popUpTo(innerNavController.graph.findStartDestination().id); launchSingleTop = true } },
                            onNavigateToMessages = { innerNavController.navigate(BottomNavItem.Messages.route) { popUpTo(innerNavController.graph.findStartDestination().id); launchSingleTop = true } },
                            onNavigateToProfile = { innerNavController.navigate(BottomNavItem.Profile.route) { popUpTo(innerNavController.graph.findStartDestination().id); launchSingleTop = true } },
                            onSwitchUserTypeRole = onSwitchUserTypeRole,
                            onNavigateToEmergency = onNavigateToEmergency
                        )
                    }
                    UserType.DUTY_TOW, UserType.DUTY_TIRE -> {
                        val activeDrivers = emergencyRepository?.activeTowDrivers?.collectAsState()?.value ?: emptyList()
                        val user = currentUser
                        val currentDriver = activeDrivers.find { it.id == user?.id } ?: activeDrivers.firstOrNull()
                        val resolvedDriverId = user?.id?.takeIf { it.isNotBlank() } ?: currentDriver?.id ?: "tow_driver_1"
                        val resolvedDriverName = user?.fullName?.takeIf { it.isNotBlank() } ?: currentDriver?.name ?: "Ahmet Çekici & Mobil Lastik"
                        val resolvedDriverPhone = user?.phone?.takeIf { it.isNotBlank() } ?: currentDriver?.phone ?: "+90 532 111 22 33"
                        val resolvedDriverPlate = currentDriver?.plate ?: "34 ABC 123"
                        val isOnDuty = currentDriver?.isOnDuty ?: true
                        val allRequests = emergencyRepository?.emergencyRequests?.collectAsState()?.value ?: emptyList()

                        val isTowOperator = currentUser?.userType == UserType.DUTY_TOW
                        val isTireOperator = currentUser?.userType == UserType.DUTY_TIRE

                        val pendingReqs = allRequests.filter { req ->
                            val isOpen = req.status == com.example.data.model.EmergencyStatus.SEARCHING ||
                                    req.status == com.example.data.model.EmergencyStatus.OFFERED
                            val isNotClaimedByOther = req.assignedDriverId.isNullOrBlank() ||
                                    req.assignedDriverId == resolvedDriverId ||
                                    (currentDriver != null && req.assignedDriverId == currentDriver.id) ||
                                    req.status == com.example.data.model.EmergencyStatus.SEARCHING

                            // STRICT SERVICE FILTER: Tow truck operators NEVER receive tire requests!
                            val serviceMatches = if (isTowOperator) {
                                req.serviceType == com.example.data.model.EmergencyServiceType.TOW_TRUCK
                            } else if (isTireOperator) {
                                req.serviceType == com.example.data.model.EmergencyServiceType.TIRE_SERVICE
                            } else {
                                true
                            }

                            isOpen && isNotClaimedByOther && serviceMatches
                        }

                        val activeMission = allRequests.find { req ->
                            val isOngoing = req.status == com.example.data.model.EmergencyStatus.ACCEPTED ||
                                    req.status == com.example.data.model.EmergencyStatus.ARRIVING ||
                                    req.status == com.example.data.model.EmergencyStatus.ARRIVED ||
                                    req.status == com.example.data.model.EmergencyStatus.IN_SERVICE
                            val isAssignedToMe = req.assignedDriverId == resolvedDriverId ||
                                    (currentDriver != null && req.assignedDriverId == currentDriver.id) ||
                                    (req.assignedDriverId == "tow_driver_1" && isTowOperator)
                            isOngoing && isAssignedToMe
                        }

                        TowTruckDutyScreen(
                            currentUser = currentUser,
                            isOnDuty = isOnDuty,
                            pendingRequests = pendingReqs,
                            activeMission = activeMission,
                            onBackClick = { innerNavController.navigate(BottomNavItem.Profile.route) },
                            onToggleDuty = { newDuty ->
                                emergencyRepository?.toggleDriverDuty(resolvedDriverId, newDuty)
                                emergencyRepository?.toggleDriverActive(resolvedDriverId, newDuty)
                            },
                            onAcceptRequest = { reqId ->
                                val success = emergencyRepository?.acceptRequest(
                                    requestId = reqId,
                                    driverId = resolvedDriverId,
                                    driverName = resolvedDriverName,
                                    driverPhone = resolvedDriverPhone,
                                    driverPlate = resolvedDriverPlate
                                ) ?: false
                                if (!success) {
                                    Toast.makeText(context, "⚠️ Bu çağrı başka bir çekici tarafından kabul edilmiş veya işlem başlatılmıştır.", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "✅ Görev kabul edildi! Navigasyonu başlatabilirsiniz.", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onRejectRequest = { reqId ->
                                emergencyRepository?.cancelRequest(reqId)
                            },
                            onUpdateMissionStatus = { reqId, newStatus ->
                                emergencyRepository?.updateRequestStatus(reqId, newStatus)
                            },
                            onNavigateToChat = { custId, custName ->
                                innerNavController.navigate(BottomNavItem.Messages.route)
                            },
                            onSendPriceOffer = { reqId, price ->
                                val success = emergencyRepository?.sendPriceOffer(
                                    requestId = reqId,
                                    price = price,
                                    driverId = resolvedDriverId,
                                    driverName = resolvedDriverName,
                                    driverPhone = resolvedDriverPhone,
                                    driverPlate = resolvedDriverPlate
                                ) ?: false
                                if (!success) {
                                    Toast.makeText(context, "⚠️ Bu çağrı başka bir çekici tarafından kabul edilmiş veya işlem başlatılmıştır.", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "✅ Fiyat teklifiniz ($price ₺) müşteriye iletildi.", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )
                    }
                    UserType.ADMIN -> {
                        AdminDashboardScreen(
                            currentUser = currentUser,
                            usersList = allUsers,
                            machinesList = machines,
                            applicationsList = applications,
                            reportsList = reports,
                            onBackClick = { innerNavController.navigate(BottomNavItem.Profile.route) },
                            onToggleUserActive = { userId, active ->
                                scope.launch {
                                    adminRepository?.toggleUserActiveStatus(userId, active)
                                }
                            },
                            onDeleteMachine = { machineId ->
                                scope.launch {
                                    machineRepository?.deleteMachine(machineId)
                                }
                            },
                            onProcessApplication = { appId, approve, userId, role ->
                                scope.launch {
                                    adminRepository?.processApplication(appId, approve, userId, role)
                                }
                            },
                            onResolveReport = { reportId ->
                                scope.launch {
                                    adminRepository?.resolveReport(reportId)
                                }
                            },
                            onSendNotification = { title, body ->
                                FirebaseManager.sendPushNotification(title, body, type = "ADMIN_NOTIFICATION")
                            }
                        )
                    }
                    else -> {
                        val allEmergencyList = emergencyRepository?.emergencyRequests?.collectAsState()?.value ?: emptyList()
                        val userActiveEmergencyList = allEmergencyList.filter {
                            (it.customerId == currentUser?.id) &&
                            it.status != com.example.data.model.EmergencyStatus.COMPLETED &&
                            it.status != com.example.data.model.EmergencyStatus.CANCELLED
                        }

                        HomeScreen(
                            currentUser = currentUser,
                            machines = if (selectedCategory == "Tümü") machines else machines.filter { it.category.equals(selectedCategory, ignoreCase = true) },
                            favorites = favorites,
                            selectedCategory = selectedCategory,
                            activeEmergencyRequests = userActiveEmergencyList,
                            onCategorySelect = onCategorySelect,
                            onSearchClick = { innerNavController.navigate(BottomNavItem.Search.route) },
                            onMachineClick = onMachineClick,
                            onRequestOfferClick = onRequestOfferClick,
                            onFavoriteToggle = onFavoriteToggle,
                            onSwitchUserTypeRole = onSwitchUserTypeRole,
                            onNavigateToProfile = { innerNavController.navigate(BottomNavItem.Profile.route) },
                            onNavigateToEmergency = onNavigateToEmergency,
                            onNavigateToDemands = onNavigateToDemands,
                            onNavigateToHandover = onNavigateToHandover,
                            onNavigateToMap = onNavigateToMap,
                            onNavigateToAdmin = onNavigateToAdmin,
                            onNavigateToTracking = onNavigateToTracking
                        )
                    }
                }
            }

            composable(BottomNavItem.Search.route) {
                SearchFilterScreen(
                    machines = machines,
                    favorites = favorites,
                    onMachineClick = onMachineClick,
                    onRequestOfferClick = onRequestOfferClick,
                    onFavoriteToggle = onFavoriteToggle
                )
            }

            composable(BottomNavItem.MyListings.route) {
                MyListingsScreen(
                    ownerMachines = machines.filter { it.ownerId == currentUser?.id },
                    onNavigateBack = { innerNavController.popBackStack() },
                    onAddNewListing = onAddNewListing,
                    onEditMachine = onEditMachine,
                    onToggleAvailability = onToggleAvailability,
                    onDeleteMachine = onDeleteMachine
                )
            }

            composable(BottomNavItem.Offers.route) {
                val filteredOffers = if (isOwner) {
                    offers.filter { it.ownerId == currentUser?.id }
                } else {
                    offers.filter { it.customerId == currentUser?.id }
                }

                OffersScreen(
                    currentUser = currentUser,
                    offers = filteredOffers,
                    onUpdateOfferStatus = onUpdateOfferStatus,
                    onNavigateBack = {
                        val popped = innerNavController.popBackStack()
                        if (!popped) {
                            innerNavController.navigate(BottomNavItem.Profile.route) {
                                popUpTo(innerNavController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    },
                    onDeleteOffer = { offerId ->
                        offerRepository?.deleteOffer(offerId)
                    },
                    onDeleteOffers = { ids ->
                        offerRepository?.deleteOffers(ids)
                    },
                    onDeleteAllOffers = {
                        offerRepository?.deleteAllOffersForUser(currentUser?.id ?: "", isOwner)
                    }
                )
            }

            composable(BottomNavItem.Messages.route) {
                val userConversations = if (currentUser == null) {
                    emptyList()
                } else {
                    messages
                        .filter { (it.senderId == currentUser?.id || it.receiverId == currentUser?.id) && !it.id.startsWith("msg_") }
                        .groupBy { if (it.senderId == currentUser?.id) it.receiverId else it.senderId }
                        .map { (otherUserId, userMsgs) ->
                            val sorted = userMsgs.sortedByDescending { it.timestamp }
                            val latest = sorted.first()
                            val otherUserName = if (latest.senderId == currentUser?.id) latest.machineTitle.ifBlank { "Kullanıcı" } else latest.senderName
                            com.example.data.model.Conversation(
                                id = latest.machineId.ifBlank { otherUserId },
                                participantId = otherUserId,
                                participantName = otherUserName,
                                machineTitle = latest.machineTitle,
                                lastMessage = latest.text,
                                lastTimestamp = latest.timestamp,
                                unreadCount = userMsgs.count { !it.isRead && it.receiverId == currentUser?.id }
                            )
                        }
                }

                MessagesListScreen(
                    conversations = userConversations,
                    onSelectConversation = onSelectConversation,
                    onDeleteConversation = { convId ->
                        messageRepository?.deleteConversation(convId, currentUser?.id ?: "")
                    },
                    onDeleteConversations = { convIds ->
                        messageRepository?.deleteConversations(convIds, currentUser?.id ?: "")
                    },
                    onDeleteAllConversations = {
                        messageRepository?.deleteAllMessagesForUser(currentUser?.id ?: "")
                    }
                )
            }

            composable(BottomNavItem.Profile.route) {
                ProfileScreen(
                    currentUser = currentUser,
                    onNavigateBack = {
                        innerNavController.navigate(BottomNavItem.Home.route) {
                            popUpTo(innerNavController.graph.findStartDestination().id)
                            launchSingleTop = true
                        }
                    },
                    onSwitchUserTypeRole = onSwitchUserTypeRole,
                    onNavigateToOffers = {
                        innerNavController.navigate(BottomNavItem.Offers.route) {
                            launchSingleTop = true
                        }
                    },
                    onNavigateToFavorites = onNavigateToFavorites,
                    onNavigateToMyListings = {
                        innerNavController.navigate(BottomNavItem.MyListings.route) {
                            popUpTo(innerNavController.graph.findStartDestination().id)
                            launchSingleTop = true
                        }
                    },
                    onNavigateToAddListing = onAddNewListing,
                    onNavigateToTowDuty = onNavigateToTowDuty,
                    onNavigateToAdmin = onNavigateToAdmin,
                    onNavigateToApplyProvider = onNavigateToApplyProvider,
                    onNavigateToDemands = onNavigateToDemands,
                    onNavigateToHandover = onNavigateToHandover,
                    onNavigateToMap = onNavigateToMap,
                    onLogout = onLogout
                )
            }
        }
    }
}
