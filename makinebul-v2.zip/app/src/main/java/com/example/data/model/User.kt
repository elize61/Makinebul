package com.example.data.model

enum class UserType(val labelTr: String) {
    CUSTOMER("Müşteri"),
    OWNER("Makine Sahibi"),
    DUTY_TOW("Nöbetçi Çekici"),
    DUTY_TIRE("Nöbetçi Lastikçi"),
    ADMIN("Yönetici")
}

data class User(
    val id: String = "",
    val fullName: String = "",
    val phone: String = "",
    val email: String = "",
    val userType: UserType = UserType.CUSTOMER,
    val city: String = "",
    val district: String = "",
    val address: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val rating: Double = 0.0,
    val ratingCount: Int = 0,
    val profileImageUrl: String = "",
    val isTowDriver: Boolean = false,
    val isOnDuty: Boolean = false,
    val isActive: Boolean = true,
    val phoneVerified: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
