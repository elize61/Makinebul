package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.Conversation
import com.example.data.model.Message
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MessageRepository {

    private val _messages = MutableStateFlow<List<Message>>(emptyList())
    val messages: StateFlow<List<Message>> = _messages.asStateFlow()

    init {
        FirebaseManager.runWhenAuthenticated { fetchMessagesFromFirestore() }
    }

    private var sentMsgs: List<Message> = emptyList()
    private var receivedMsgs: List<Message> = emptyList()

    private fun parseMsgs(docs: List<com.google.firebase.firestore.DocumentSnapshot>): List<Message> =
        docs.mapNotNull { doc ->
            try {
                Message(
                    id = doc.getString("id") ?: doc.id,
                    conversationId = doc.getString("conversationId") ?: "",
                    senderId = doc.getString("senderId") ?: "",
                    senderName = doc.getString("senderName") ?: "",
                    receiverId = doc.getString("receiverId") ?: "",
                    machineId = doc.getString("machineId") ?: "",
                    machineTitle = doc.getString("machineTitle") ?: "",
                    text = doc.getString("text") ?: "",
                    timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis(),
                    isRead = doc.getBoolean("isRead") ?: false
                )
            } catch (ex: Exception) {
                null
            }
        }

    private fun publishMsgs() {
        _messages.value = (sentMsgs + receivedMsgs).distinctBy { it.id }
    }

    // Kurallar gereği yalnızca kullanıcının gönderdiği ve aldığı mesajlar okunur (iki ayrı sorgu)
    private var sentReg: com.google.firebase.firestore.ListenerRegistration? = null
    private var recvReg: com.google.firebase.firestore.ListenerRegistration? = null

    /** Kullanıcı değişince (giriş/çıkış) dinleyicileri yeni kullanıcı için yeniden kurar. */
    fun restartListeners() {
        sentReg?.remove(); recvReg?.remove()
        sentReg = null; recvReg = null
        sentMsgs = emptyList(); receivedMsgs = emptyList(); publishMsgs()
        fetchMessagesFromFirestore()
    }

    private fun fetchMessagesFromFirestore() {
        try {
            val db = FirebaseManager.getFirestore() ?: return
            val uid = FirebaseManager.getAuth()?.currentUser?.uid ?: return
            sentReg = db.collection("messages").whereEqualTo("senderId", uid).addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                sentMsgs = parseMsgs(snapshot.documents)
                publishMsgs()
            }
            recvReg = db.collection("messages").whereEqualTo("receiverId", uid).addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                receivedMsgs = parseMsgs(snapshot.documents)
                publishMsgs()
            }
        } catch (e: Exception) {
            // Graceful fallback
        }
    }

    fun getMessagesForConversation(machineId: String, currentUserId: String): List<Message> {
        return _messages.value.filter {
            (it.machineId == machineId || machineId.isBlank()) &&
                    (it.senderId == currentUserId || it.receiverId == currentUserId)
        }.sortedBy { it.timestamp }
    }

    fun sendMessage(
        senderId: String,
        senderName: String,
        receiverId: String,
        machineId: String,
        machineTitle: String,
        text: String
    ): Result<Message> {
        if (text.isBlank()) return Result.failure(Exception("Mesaj metni boş olamaz."))

        val newMsg = Message(
            id = "msg_${System.currentTimeMillis()}",
            conversationId = "conv_${machineId}_$senderId",
            senderId = senderId,
            senderName = senderName,
            receiverId = receiverId,
            machineId = machineId,
            machineTitle = machineTitle,
            text = text,
            timestamp = System.currentTimeMillis(),
            isRead = false
        )

        _messages.value = _messages.value + newMsg
        saveMessageToFirestore(newMsg)

        // Trigger FCM Push Notification for new message
        FirebaseManager.sendPushNotification(
            title = "💬 $senderName: Mesajınız Var",
            body = text,
            type = "NEW_MESSAGE",
            recipientUserId = receiverId,
            extraData = mapOf(
                "conversationId" to newMsg.conversationId,
                "machineId" to machineId,
                "senderId" to senderId
            )
        )

        return Result.success(newMsg)
    }

    fun getConversations(userId: String): List<Conversation> {
        val msgs = _messages.value
            .filter { it.senderId == userId || it.receiverId == userId }
        if (msgs.isEmpty()) return emptyList()

        return msgs
            .groupBy { if (it.senderId == userId) it.receiverId else it.senderId }
            .map { (otherUserId, userMsgs) ->
                val sorted = userMsgs.sortedByDescending { it.timestamp }
                val latest = sorted.first()
                val otherUserName = if (latest.senderId == userId) latest.machineTitle.ifBlank { "Kullanıcı" } else latest.senderName
                Conversation(
                    id = latest.machineId.ifBlank { otherUserId },
                    participantId = otherUserId,
                    participantName = otherUserName,
                    machineTitle = latest.machineTitle,
                    lastMessage = latest.text,
                    lastTimestamp = latest.timestamp,
                    unreadCount = userMsgs.count { !it.isRead && it.receiverId == userId }
                )
            }
    }

    fun deleteMessage(messageId: String) {
        _messages.value = _messages.value.filter { it.id != messageId }
        try {
            FirebaseManager.getFirestore()?.collection("messages")?.document(messageId)?.delete()
        } catch (e: Exception) {
            // Graceful fallback
        }
    }

    fun deleteConversation(conversationKey: String, currentUserId: String) {
        val toDelete = _messages.value.filter {
            (it.conversationId == conversationKey || it.machineId == conversationKey || it.senderId == conversationKey || it.receiverId == conversationKey) &&
                    (it.senderId == currentUserId || it.receiverId == currentUserId)
        }
        val ids = toDelete.map { it.id }.toSet()
        _messages.value = _messages.value.filter { it.id !in ids }
        try {
            val db = FirebaseManager.getFirestore() ?: return
            ids.forEach { id ->
                db.collection("messages").document(id).delete()
            }
        } catch (e: Exception) {
            // Graceful fallback
        }
    }

    fun deleteConversations(conversationKeys: Collection<String>, currentUserId: String) {
        val keys = conversationKeys.toSet()
        val toDelete = _messages.value.filter { msg ->
            (msg.conversationId in keys || msg.machineId in keys || msg.senderId in keys || msg.receiverId in keys) &&
                    (msg.senderId == currentUserId || msg.receiverId == currentUserId)
        }
        val ids = toDelete.map { it.id }.toSet()
        _messages.value = _messages.value.filter { it.id !in ids }
        try {
            val db = FirebaseManager.getFirestore() ?: return
            ids.forEach { id ->
                db.collection("messages").document(id).delete()
            }
        } catch (e: Exception) {
            // Graceful fallback
        }
    }

    fun deleteAllMessagesForUser(userId: String) {
        val toDelete = _messages.value.filter { it.senderId == userId || it.receiverId == userId }
        val ids = toDelete.map { it.id }.toSet()
        _messages.value = _messages.value.filter { it.id !in ids }
        try {
            val db = FirebaseManager.getFirestore() ?: return
            ids.forEach { id ->
                db.collection("messages").document(id).delete()
            }
        } catch (e: Exception) {
            // Graceful fallback
        }
    }

    private fun saveMessageToFirestore(message: Message) {
        try {
            val db = FirebaseManager.getFirestore() ?: return
            val msgMap = hashMapOf(
                "id" to message.id,
                "conversationId" to message.conversationId,
                "senderId" to message.senderId,
                "senderName" to message.senderName,
                "receiverId" to message.receiverId,
                "machineId" to message.machineId,
                "machineTitle" to message.machineTitle,
                "text" to message.text,
                "timestamp" to message.timestamp,
                "isRead" to message.isRead
            )
            db.collection("messages").document(message.id).set(msgMap)
        } catch (e: Exception) {
            // Graceful fallback
        }
    }
}
