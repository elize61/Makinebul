package com.example.data.model

data class Review(
    val id: String = "",
    val targetType: String = "MACHINE", // "MACHINE" or "USER"
    val targetId: String = "",
    val reviewerId: String = "",
    val reviewerName: String = "",
    val reviewerAvatar: String = "",
    val rating: Double = 5.0,
    val comment: String = "",
    val tags: List<String> = emptyList(), // e.g. "Zamanında Teslimat", "Uzman Operatör", "Temiz Ekipman"
    val createdAt: Long = System.currentTimeMillis()
)
