package com.example.data.model

enum class EmergencyServiceType(
    val id: String,
    val title: String,
    val subtitle: String,
    val iconEmoji: String,
    val isAvailable: Boolean = true
) {
    TOW_TRUCK("TOW_TRUCK", "Acil Çekici", "Yolda kaldım, oto kurtarma & çekici", "🚛", true),
    TIRE_SERVICE("TIRE_SERVICE", "Acil Lastikçi", "Lastiğim patladı / indi, mobil tamir", "🛞", true),
    BATTERY("BATTERY", "Akü Takviye", "Aküm bitti, yerinde takviye / değişim", "🔋", false),
    FUEL("FUEL", "Yakıt Getir", "Yakıtım bitti, acil yakıt ikmali", "⛽", false),
    LOCKSMITH("LOCKSMITH", "Oto Çilingir", "Anahtar kilitli kaldı, oto çilingir", "🔑", false),
    MOBILE_MECHANIC("MOBILE_MECHANIC", "Mobil Oto Servis", "Olay yerinde acil arıza onarımı", "🔧", false)
}

enum class EmergencyStatus(val labelTr: String, val iconEmoji: String) {
    SEARCHING("Servis aranıyor...", "🔎"),
    OFFERED("Sağlayıcılara bildirildi", "📬"),
    ACCEPTED("Sağlayıcı kabul etti", "🤝"),
    ARRIVING("Sağlayıcı size geliyor", "🚗"),
    ARRIVED("Sağlayıcı konumunuza ulaştı", "📍"),
    IN_SERVICE("Hizmet başladı", "🔧"),
    COMPLETED("Hizmet tamamlandı", "✅"),
    CANCELLED("Çağrı iptal edildi", "❌")
}

data class EmergencyProvider(
    val id: String = "",
    val name: String = "",
    val phone: String = "",
    val plate: String = "",
    val role: String = "CEKICI",
    val isOnline: Boolean = true,
    val serviceTypes: List<EmergencyServiceType> = listOf(EmergencyServiceType.TOW_TRUCK, EmergencyServiceType.TIRE_SERVICE),
    val detailInfo: String = "7/24 Mobil Acil Yol Yardım Servisi",
    val city: String = "İstanbul",
    val district: String = "Ümraniye",
    val latitude: Double = 41.028,
    val longitude: Double = 29.118,
    val isActive: Boolean = true, // "ŞU AN HİZMET VERİYORUM"
    val isOnDuty: Boolean = true, // Nöbet durumu
    val lastLocationUpdate: Long = System.currentTimeMillis(),
    val rating: Double = 0.0,
    val completedJobs: Int = 184
)

// Alias for backwards compatibility
typealias TowTruckDriver = EmergencyProvider

data class EmergencyDriverOffer(
    val id: String = "",
    val driverId: String = "",
    val driverName: String = "",
    val driverPhone: String = "",
    val driverPlate: String = "",
    val price: Double = 0.0,
    val note: String = "",
    val estimatedMinutes: Int = 10,
    val rating: Double = 0.0,
    val completedJobs: Int = 184,
    val offeredAt: Long = System.currentTimeMillis(),
    val isAcceptedByCustomer: Boolean = false
)

data class EmergencyRequest(
    val id: String = "",
    val serviceType: EmergencyServiceType = EmergencyServiceType.TOW_TRUCK,
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val customerLocationName: String = "",
    val customerLat: Double = 41.025,
    val customerLng: Double = 29.112,
    val destinationLocationName: String = "",
    val destinationLat: Double = 41.060,
    val destinationLng: Double = 29.010,
    val vehicleType: String = "Otomobil",
    val plate: String = "",
    val problemType: String = "Aracım çalışmıyor",
    val tireDimension: String = "",
    val hasSpareTire: Boolean = true,
    val description: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val status: EmergencyStatus = EmergencyStatus.SEARCHING,
    val offers: List<EmergencyDriverOffer> = emptyList(),
    val assignedDriverId: String? = null,
    val assignedDriverName: String? = null,
    val assignedDriverPhone: String? = null,
    val assignedDriverPlate: String? = null,
    val driverLat: Double = 0.0,
    val driverLng: Double = 0.0,
    val estimatedDistanceKm: Double = 3.2,
    val estimatedTimeMinutes: Int = 8,
    val agreedPrice: Double? = null,
    val priceStatus: String? = null, // "OFFERED", "NEGOTIATING", "ACCEPTED", "REJECTED"
    val acceptedAt: Long? = null,
    val startedMissionAt: Long? = null,
    val completedAt: Long? = null,
    val userRating: Int? = null,
    val userComment: String? = null
)
