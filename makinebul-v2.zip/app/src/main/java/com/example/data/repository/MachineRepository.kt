package com.example.data.repository

import android.util.Log
import com.example.data.firebase.FirebaseManager
import com.example.data.model.Machine
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MachineRepository {

    companion object {
        private const val TAG = "MachineRepo"
    }

    private val _machines = MutableStateFlow<List<Machine>>(emptyList())
    val machines: StateFlow<List<Machine>> = _machines.asStateFlow()

    private val _favorites = MutableStateFlow<Set<String>>(emptySet())
    val favorites: StateFlow<Set<String>> = _favorites.asStateFlow()

    init {
        FirebaseManager.runWhenAuthenticated { fetchMachinesFromFirestore() }
    }

    private fun fetchMachinesFromFirestore() {
        try {
            val db = FirebaseManager.getFirestore()
            if (db == null) {
                Log.d(TAG, "Firestore instance is not available.")
                return
            }

            Log.d(TAG, "Starting real-time snapshot listener on 'makineler' collection...")
            db.collection("makineler").addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Log.w(TAG, "Firestore snapshot warning on 'makineler' collection: ${e.localizedMessage}")
                    return@addSnapshotListener
                }

                if (snapshot == null) {
                    Log.w(TAG, "Firestore snapshot received is null for 'makineler' collection")
                    return@addSnapshotListener
                }

                val remoteMachines = snapshot.documents.mapNotNull { doc ->
                    try {
                        val title = getString(doc, "title", "baslik", "name", "ad")
                        val category = getString(doc, "category", "kategori").ifBlank { "Diğer" }

                        Machine(
                            id = getString(doc, "id").ifBlank { doc.id },
                            title = title.ifBlank { "Makine (${doc.id})" },
                            category = category,
                            brand = getString(doc, "brand", "marka"),
                            model = getString(doc, "model"),
                            year = getInt(doc, 2022, "year", "yil", "modelYili"),
                            hourlyPrice = getDouble(doc, 0.0, "hourlyPrice", "saatlikFiyat", "fiyat", "hourly"),
                            dailyPrice = getDouble(doc, 0.0, "dailyPrice", "gunlukFiyat", "daily"),
                            minWorkingHours = getInt(doc, 2, "minWorkingHours", "minCalismaSuresi"),
                            city = getString(doc, "city", "sehir", "konum").ifBlank { "İstanbul" },
                            district = getString(doc, "district", "ilce"),
                            address = getString(doc, "address", "adres"),
                            description = getString(doc, "description", "aciklama"),
                            photos = getPhotos(doc, "photos", "fotograflar", "images"),
                            ownerId = getString(doc, "ownerId", "sahipId", "userId").ifBlank { "" },
                            ownerName = getString(doc, "ownerName", "sahipAdi", "userName").ifBlank { "Makine Sahibi" },
                            ownerPhone = getString(doc, "ownerPhone", "sahipTelefon", "phone", "telefon"),
                            isAvailable = getBoolean(doc, true, "isAvailable", "durum", "aktif", "available"),
                            hasOperator = getBoolean(doc, true, "hasOperator", "operatorlu", "operatorDahil"),
                            fuelIncluded = getBoolean(doc, false, "fuelIncluded", "yakitDahil"),
                            isLowbedTransport = getBoolean(doc, category.contains("lowbed", ignoreCase = true), "isLowbedTransport", "lowbed"),
                            blockedDates = getBlockedDates(doc, "blockedDates", "doluTarihler", "rezerveTarihler"),
                            reservedDates = getBlockedDates(doc, "reservedDates"),
                            status = getString(doc, "status", "onayDurumu").ifBlank { "approved" }.lowercase(),
                            rating = getDouble(doc, 5.0, "rating", "puan"),
                            latitude = getDouble(doc, 41.0082, "latitude", "lat"),
                            longitude = getDouble(doc, 28.9784, "longitude", "lng", "lon"),
                            createdAt = getLong(doc, System.currentTimeMillis(), "createdAt", "olusturmaTarihi", "timestamp")
                        )
                    } catch (ex: Exception) {
                        Log.w(TAG, "Failed to parse machine document '${doc.id}': ${ex.localizedMessage}")
                        null
                    }
                }

                Log.d(TAG, "FIREBASE MACHINE READ: ${remoteMachines.size}")
                _machines.value = remoteMachines
            }
        } catch (e: Exception) {
            Log.w(TAG, "Exception setting up Firestore listener: ${e.localizedMessage}")
        }
    }

    fun getMachineById(id: String): Machine? {
        return _machines.value.find { it.id == id }
    }

    fun searchMachines(
        query: String = "",
        category: String = "Tümü",
        brand: String = "",
        city: String = "",
        district: String = "",
        maxHourlyPrice: Double? = null,
        onlyAvailable: Boolean = false,
        onlyWithOperator: Boolean = false,
        onlyLowbed: Boolean = false
    ): List<Machine> {
        return _machines.value.filter { machine ->
            val matchesQuery = query.isBlank() ||
                    machine.title.contains(query, ignoreCase = true) ||
                    machine.brand.contains(query, ignoreCase = true) ||
                    machine.model.contains(query, ignoreCase = true) ||
                    machine.category.contains(query, ignoreCase = true)

            val matchesCategory = category == "Tümü" || machine.category.equals(category, ignoreCase = true)
            val matchesBrand = brand.isBlank() || machine.brand.contains(brand, ignoreCase = true)
            val matchesCity = city.isBlank() || machine.city.contains(city, ignoreCase = true)
            val matchesDistrict = district.isBlank() || machine.district.contains(district, ignoreCase = true)
            val matchesPrice = maxHourlyPrice == null || machine.hourlyPrice <= maxHourlyPrice
            val matchesAvailability = !onlyAvailable || machine.isAvailable
            val matchesOperator = !onlyWithOperator || machine.hasOperator
            val matchesLowbed = !onlyLowbed || machine.isLowbedTransport || machine.category.contains("Lowbed", ignoreCase = true)

            matchesQuery && matchesCategory && matchesBrand && matchesCity && matchesDistrict && matchesPrice && matchesAvailability && matchesOperator && matchesLowbed
        }
    }

    fun toggleFavorite(machineId: String) {
        val current = _favorites.value.toMutableSet()
        val isNowFav = if (current.contains(machineId)) {
            current.remove(machineId)
            false
        } else {
            current.add(machineId)
            true
        }
        _favorites.value = current
        syncFavoriteToFirestore(machineId, isNowFav)
    }

    fun isFavorite(machineId: String): Boolean {
        return _favorites.value.contains(machineId)
    }

    fun getFavoriteMachines(): List<Machine> {
        return _machines.value.filter { _favorites.value.contains(it.id) }
    }

    fun toggleAvailability(machineId: String) {
        _machines.value = _machines.value.map { machine ->
            if (machine.id == machineId) {
                val updated = machine.copy(isAvailable = !machine.isAvailable)
                saveMachineToFirestore(updated)
                updated
            } else {
                machine
            }
        }
    }

    fun toggleDateBlocked(machineId: String, dateStr: String) {
        _machines.value = _machines.value.map { machine ->
            if (machine.id == machineId) {
                val currentBlocked = machine.blockedDates.toMutableList()
                if (currentBlocked.contains(dateStr)) {
                    currentBlocked.remove(dateStr)
                } else {
                    currentBlocked.add(dateStr)
                }
                val updated = machine.copy(blockedDates = currentBlocked)
                saveMachineToFirestore(updated)
                updated
            } else {
                machine
            }
        }
    }

    fun addMachine(machine: Machine, isAdmin: Boolean = false) {
        val base = if (machine.id.isBlank()) {
            machine.copy(id = "mach_${System.currentTimeMillis()}")
        } else {
            machine
        }
        // Yeni ilanlar yönetici onayına düşer (yönetici kendi eklediğini doğrudan yayınlayabilir)
        val newMachine = base.copy(status = if (isAdmin) "approved" else "pending")
        _machines.value = listOf(newMachine) + _machines.value.filter { it.id != newMachine.id }
        saveMachineToFirestore(newMachine)
    }

    fun updateMachine(machine: Machine) {
        _machines.value = _machines.value.map {
            if (it.id == machine.id) machine else it
        }
        saveMachineToFirestore(machine)
    }

    /** Yönetici: ilanı onayla ("approved") veya reddet ("rejected"). */
    fun setMachineStatus(machineId: String, status: String) {
        _machines.value = _machines.value.map {
            if (it.id == machineId) {
                val updated = it.copy(status = status)
                saveMachineToFirestore(updated)
                updated
            } else it
        }
    }

    /** Onaylanan teklif/kiralama için seçilen tarih aralığını reservedDates dizisine ekler. */
    fun addReservedDates(machineId: String, dates: List<String>) {
        if (dates.isEmpty()) return
        _machines.value = _machines.value.map { m ->
            if (m.id == machineId) {
                val updated = m.copy(reservedDates = (m.reservedDates + dates).distinct().sorted())
                saveMachineToFirestore(updated)
                updated
            } else m
        }
    }

    fun deleteMachine(machineId: String) {
        _machines.value = _machines.value.filter { it.id != machineId }
        deleteMachineFromFirestore(machineId)
    }

    private fun saveMachineToFirestore(machine: Machine) {
        try {
            val db = FirebaseManager.getFirestore() ?: return

            val machineMap = hashMapOf<String, Any>(
                "id" to machine.id,
                "title" to machine.title,
                "category" to machine.category,
                "brand" to machine.brand,
                "model" to machine.model,
                "year" to machine.year,
                "hourlyPrice" to machine.hourlyPrice,
                "dailyPrice" to machine.dailyPrice,
                "minWorkingHours" to machine.minWorkingHours,
                "city" to machine.city,
                "district" to machine.district,
                "address" to machine.address,
                "description" to machine.description,
                "photos" to machine.photos,
                "ownerId" to machine.ownerId,
                "ownerName" to machine.ownerName,
                "ownerPhone" to machine.ownerPhone,
                "isAvailable" to machine.isAvailable,
                "hasOperator" to machine.hasOperator,
                "fuelIncluded" to machine.fuelIncluded,
                "isLowbedTransport" to machine.isLowbedTransport,
                "blockedDates" to machine.blockedDates,
                "reservedDates" to machine.reservedDates,
                "status" to machine.status,
                "rating" to machine.rating,
                "latitude" to machine.latitude,
                "longitude" to machine.longitude,
                "createdAt" to machine.createdAt,

                // Turkish aliases for multi-device / backwards compatibility
                "baslik" to machine.title,
                "kategori" to machine.category,
                "marka" to machine.brand,
                "yil" to machine.year,
                "saatlikFiyat" to machine.hourlyPrice,
                "gunlukFiyat" to machine.dailyPrice,
                "sehir" to machine.city,
                "ilce" to machine.district,
                "aciklama" to machine.description,
                "fotograflar" to machine.photos,
                "sahipId" to machine.ownerId,
                "sahipAdi" to machine.ownerName,
                "sahipTelefon" to machine.ownerPhone,
                "durum" to machine.isAvailable,
                "olusturmaTarihi" to machine.createdAt
            )

            Log.d(TAG, "Writing machine to Firestore 'makineler' collection with Document ID: ${machine.id}")
            db.collection("makineler").document(machine.id).set(machineMap)
                .addOnSuccessListener {
                    Log.d(TAG, "FIRESTORE MACHINE WRITE SUCCESS ID: ${machine.id}")
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "FIRESTORE MACHINE WRITE ERROR ID: ${machine.id}: ${e.localizedMessage}", e)
                }
        } catch (e: Exception) {
            Log.e(TAG, "FIRESTORE MACHINE WRITE ERROR ID: ${machine.id}: ${e.localizedMessage}", e)
        }
    }

    private fun deleteMachineFromFirestore(machineId: String) {
        try {
            val db = FirebaseManager.getFirestore() ?: return
            Log.d(TAG, "Deleting machine $machineId from Firestore 'makineler' collection...")
            db.collection("makineler").document(machineId).delete()
                .addOnSuccessListener {
                    Log.d(TAG, "SUCCESS: Deleted machine $machineId from Firestore 'makineler'")
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "FIRESTORE MACHINE DELETE ERROR ID: $machineId: ${e.localizedMessage}", e)
                }
        } catch (e: Exception) {
            Log.e(TAG, "Exception deleting machine $machineId: ${e.localizedMessage}", e)
        }
    }

    private fun syncFavoriteToFirestore(machineId: String, isFav: Boolean) {
        try {
            val db = FirebaseManager.getFirestore() ?: return
            val auth = FirebaseManager.getAuth()
            val userId = auth?.currentUser?.uid ?: return
            val favRef = db.collection("favorites").document("${userId}_${machineId}")
            if (isFav) {
                favRef.set(mapOf("userId" to userId, "machineId" to machineId, "timestamp" to System.currentTimeMillis()))
            } else {
                favRef.delete()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error syncing favorite to Firestore: ${e.localizedMessage}", e)
        }
    }

    // Helper functions for safe type parsing from Firestore DocumentSnapshot
    private fun getString(doc: DocumentSnapshot, vararg keys: String): String {
        for (key in keys) {
            val valStr = doc.getString(key)
            if (!valStr.isNullOrBlank()) return valStr
            val rawObj = doc.get(key)
            if (rawObj != null && rawObj.toString().isNotBlank()) return rawObj.toString()
        }
        return ""
    }

    private fun getDouble(doc: DocumentSnapshot, defaultValue: Double, vararg keys: String): Double {
        for (key in keys) {
            val obj = doc.get(key)
            if (obj is Number) return obj.toDouble()
            if (obj is String) {
                val parsed = obj.toDoubleOrNull()
                if (parsed != null) return parsed
            }
        }
        return defaultValue
    }

    private fun getInt(doc: DocumentSnapshot, defaultValue: Int, vararg keys: String): Int {
        for (key in keys) {
            val obj = doc.get(key)
            if (obj is Number) return obj.toInt()
            if (obj is String) {
                val parsed = obj.toIntOrNull()
                if (parsed != null) return parsed
            }
        }
        return defaultValue
    }

    private fun getLong(doc: DocumentSnapshot, defaultValue: Long, vararg keys: String): Long {
        for (key in keys) {
            val obj = doc.get(key)
            if (obj is Number) return obj.toLong()
            if (obj is String) {
                val parsed = obj.toLongOrNull()
                if (parsed != null) return parsed
            }
        }
        return defaultValue
    }

    private fun getBoolean(doc: DocumentSnapshot, defaultValue: Boolean, vararg keys: String): Boolean {
        for (key in keys) {
            val obj = doc.get(key)
            if (obj is Boolean) return obj
            if (obj is String) {
                if (obj.equals("true", ignoreCase = true) || obj.equals("1") || obj.equals("aktif", ignoreCase = true)) return true
                if (obj.equals("false", ignoreCase = true) || obj.equals("0") || obj.equals("pasif", ignoreCase = true)) return false
            }
            if (obj is Number) return obj.toInt() != 0
        }
        return defaultValue
    }

    private fun getPhotos(doc: DocumentSnapshot, vararg keys: String): List<String> {
        for (key in keys) {
            val list = doc.get(key) as? List<*>
            if (list != null) {
                val photos = list.mapNotNull { it?.toString() }.filter { it.isNotBlank() }
                if (photos.isNotEmpty()) return photos
            }
        }
        return emptyList()
    }

    private fun getBlockedDates(doc: DocumentSnapshot, vararg keys: String): List<String> {
        for (key in keys) {
            val list = doc.get(key) as? List<*>
            if (list != null) {
                val dates = list.mapNotNull { it?.toString() }.filter { it.isNotBlank() }
                if (dates.isNotEmpty()) return dates
            }
        }
        return emptyList()
    }
}
