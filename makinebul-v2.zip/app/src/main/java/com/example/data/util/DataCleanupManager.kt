package com.example.data.util

import android.util.Log
import com.example.data.firebase.FirebaseManager
import com.example.data.model.EmergencyStatus
import com.example.data.model.OfferStatus
import com.google.android.gms.tasks.Tasks
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class CleanupStats(
    val archivedEmergencyCalls: Int = 0,
    val archivedOffers: Int = 0,
    val cleanedNotifications: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val message: String = ""
)

object DataCleanupManager {
    private const val TAG = "DataCleanupManager"
    const val RETENTION_PERIOD_MS = 24 * 60 * 60 * 1000L // 24 Hours

    /**
     * Executes database archiving and pruning of records older than 24 hours
     * or completed/cancelled entries from active query tables.
     */
    suspend fun performDatabaseCleanup(): CleanupStats = withContext(Dispatchers.IO) {
        val db = FirebaseManager.getFirestore()
        if (db == null) {
            Log.d(TAG, "Firestore not connected, performing local cache pruning.")
            return@withContext CleanupStats(
                archivedEmergencyCalls = 0,
                archivedOffers = 0,
                cleanedNotifications = 0,
                message = "Yerel önbellek temizlendi (Firebase bağlantısı yok)."
            )
        }

        val cutoffTime = System.currentTimeMillis() - RETENTION_PERIOD_MS
        var archivedEmergency = 0
        var archivedOffers = 0
        var cleanedNotifs = 0

        try {
            // 1. Clean & Archive Emergency Requests
            val emergencySnap = Tasks.await(db.collection("emergencyRequests").get())
            for (doc in emergencySnap.documents) {
                try {
                    val statusStr = (doc.getString("status") ?: doc.getString("durum") ?: "").uppercase()
                    val createdAt = doc.getLong("createdAt") ?: doc.getLong("olusturmaTarihi") ?: 0L
                    val isTerminal = statusStr == EmergencyStatus.COMPLETED.name || statusStr == EmergencyStatus.CANCELLED.name
                    val isExpired = createdAt < cutoffTime

                    if (isTerminal || isExpired) {
                        // Copy to archive collection
                        val data = doc.data
                        if (data != null) {
                            val archiveDoc = HashMap(data)
                            archiveDoc["archivedAt"] = System.currentTimeMillis()
                            Tasks.await(db.collection("archived_emergencyRequests").document(doc.id).set(archiveDoc))
                        }
                        // Remove from active collection to keep query fast
                        Tasks.await(db.collection("emergencyRequests").document(doc.id).delete())
                        archivedEmergency++
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error archiving emergency request ${doc.id}: ${e.localizedMessage}")
                }
            }

            // 2. Clean & Archive Offers
            val offersSnap = Tasks.await(db.collection("offers").get())
            for (doc in offersSnap.documents) {
                try {
                    val statusStr = (doc.getString("status") ?: "").uppercase()
                    val createdAt = doc.getLong("createdAt") ?: 0L
                    val isTerminalOffer = statusStr == OfferStatus.REDDEDILDI.name || statusStr == OfferStatus.IPTAL_EDILDI.name || statusStr == OfferStatus.TAMAMLANDI.name
                    val isExpiredOffer = createdAt < cutoffTime

                    if (isTerminalOffer || isExpiredOffer) {
                        val data = doc.data
                        if (data != null) {
                            val archiveDoc = HashMap(data)
                            archiveDoc["archivedAt"] = System.currentTimeMillis()
                            Tasks.await(db.collection("archived_offers").document(doc.id).set(archiveDoc))
                        }
                        Tasks.await(db.collection("offers").document(doc.id).delete())
                        archivedOffers++
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error archiving offer ${doc.id}: ${e.localizedMessage}")
                }
            }

            // 3. Clean Old Notifications (> 48h or read)
            val notifCutoff = System.currentTimeMillis() - (48 * 60 * 60 * 1000L)
            val notifsSnap = Tasks.await(db.collection("notifications").get())
            for (doc in notifsSnap.documents) {
                try {
                    val timestamp = doc.getLong("timestamp") ?: 0L
                    val isRead = doc.getBoolean("isRead") ?: false
                    if (timestamp < notifCutoff || (isRead && timestamp < cutoffTime)) {
                        Tasks.await(db.collection("notifications").document(doc.id).delete())
                        cleanedNotifs++
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Error pruning notification ${doc.id}: ${e.localizedMessage}")
                }
            }

            Log.i(TAG, "Database cleanup successful: $archivedEmergency calls archived, $archivedOffers offers archived, $cleanedNotifs notifications pruned.")
            return@withContext CleanupStats(
                archivedEmergencyCalls = archivedEmergency,
                archivedOffers = archivedOffers,
                cleanedNotifications = cleanedNotifs,
                message = "24 saati geçen $archivedEmergency acil çağrı ve $archivedOffers teklif arşive taşındı, $cleanedNotifs eski bildirim temizlendi."
            )
        } catch (e: Exception) {
            Log.e(TAG, "General cleanup error: ${e.localizedMessage}", e)
            return@withContext CleanupStats(
                archivedEmergencyCalls = archivedEmergency,
                archivedOffers = archivedOffers,
                cleanedNotifications = cleanedNotifs,
                message = "Temizlik tamamlandı (${e.localizedMessage})"
            )
        }
    }
}
