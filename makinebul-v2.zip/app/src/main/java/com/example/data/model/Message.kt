package com.example.data.model

data class Message(
    val id: String = "",
    val conversationId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val receiverId: String = "",
    val machineId: String = "",
    val machineTitle: String = "",
    val offerId: String = "",
    val text: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)

data class Conversation(
    val id: String = "",
    val participantId: String = "",
    val participantName: String = "",
    val machineTitle: String = "",
    val lastMessage: String = "",
    val lastTimestamp: Long = System.currentTimeMillis(),
    val unreadCount: Int = 0
)
