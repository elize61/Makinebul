package com.example.data.repository

import android.util.Log
import com.example.data.firebase.FirebaseManager
import com.example.data.model.EmergencyProvider
import com.example.data.model.EmergencyRequest
import com.example.data.model.EmergencyServiceType
import com.example.data.model.EmergencyStatus
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class EmergencyRepository {

    companion object {
        private const val TAG = "EmergencyRepo"
    }

    private val scope = CoroutineScope(Dispatchers.Main)

    private val _activeTowDrivers = MutableStateFlow<List<EmergencyProvider>>(
        listOf(
            EmergencyProvider(
                id = "tow_driver_1",
                name = "Ahmet Çekici & Kurtarma",
                phone = "+90 532 111 22 33",
                plate = "34 ABC 123",
                role = "DUTY_TOW",
                isOnline = true,
                serviceTypes = listOf(EmergencyServiceType.TOW_TRUCK),
                detailInfo = "Sürgülü Kasa Çekici & Oto Kurtarma",
                city = "İstanbul",
                district = "Ümraniye",
                latitude = 41.028,
                longitude = 29.118,
                isActive = true,
                isOnDuty = true,
                lastLocationUpdate = System.currentTimeMillis(),
                rating = 4.9,
                completedJobs = 184
            ),
            EmergencyProvider(
                id = "tire_driver_2",
                name = "Gebze 7/24 Gece Mobil Lastik",
                phone = "+90 533 222 33 44",
                plate = "41 XYZ 789",
                role = "CEKICI",
                isOnline = true,
                serviceTypes = listOf(EmergencyServiceType.TIRE_SERVICE),
                detailInfo = "7/24 Yolda Yerinde Mobil Lastik Onarım & Stepne Değişimi",
                city = "Kocaeli",
                district = "Gebze",
                latitude = 41.035,
                longitude = 29.135,
                isActive = true,
                isOnDuty = true,
                lastLocationUpdate = System.currentTimeMillis(),
                rating = 4.8,
                completedJobs = 120
            ),
            EmergencyProvider(
                id = "tow_driver_3",
                name = "Marmara Acil Çekici & Kurtarma",
                phone = "+90 535 333 44 55",
                plate = "34 EFG 456",
                role = "CEKICI",
                isOnline = true,
                serviceTypes = listOf(EmergencyServiceType.TOW_TRUCK),
                detailInfo = "Aptal Ahtapot / Vinçli Heavy Duty Çekici",
                city = "İstanbul",
                district = "Kadıköy",
                latitude = 41.010,
                longitude = 29.080,
                isActive = true,
                isOnDuty = true,
                lastLocationUpdate = System.currentTimeMillis(),
                rating = 5.0,
                completedJobs = 210
            ),
            EmergencyProvider(
                id = "tire_driver_4",
                name = "Kocaeli Hızlı Mobil Lastik Tamiri",
                phone = "+90 536 444 55 66",
                plate = "41 LST 999",
                role = "CEKICI",
                isOnline = false, // Currently off-duty for demo test
                serviceTypes = listOf(EmergencyServiceType.TIRE_SERVICE),
                detailInfo = "Mobil Lastik Sökme, Balans & Yama Tamiri",
                city = "Kocaeli",
                district = "Izmit",
                latitude = 40.765,
                longitude = 29.940,
                isActive = false,
                isOnDuty = false,
                lastLocationUpdate = System.currentTimeMillis() - 3600000,
                rating = 4.7,
                completedJobs = 85
            )
        )
    )
    val activeTowDrivers: StateFlow<List<EmergencyProvider>> = _activeTowDrivers.asStateFlow()

    private val _emergencyRequests = MutableStateFlow<List<EmergencyRequest>>(emptyList())
    val emergencyRequests: StateFlow<List<EmergencyRequest>> = _emergencyRequests.asStateFlow()

    init {
        FirebaseManager.runWhenAuthenticated {
            fetchEmergencyRequestsFromFirestore()
            fetchOnlineTowDriversFromFirestore()
        }
    }

    suspend fun performManualCleanup(): com.example.data.util.CleanupStats {
        val stats = com.example.data.util.DataCleanupManager.performDatabaseCleanup()
        // Prune local state
        val cutoff = System.currentTimeMillis() - com.example.data.util.DataCleanupManager.RETENTION_PERIOD_MS
        _emergencyRequests.value = _emergencyRequests.value.filter {
            val isTerminal = it.status == EmergencyStatus.COMPLETED || it.status == EmergencyStatus.CANCELLED
            !isTerminal || (it.completedAt ?: it.createdAt) >= cutoff
        }
        return stats
    }

    private fun fetchOnlineTowDriversFromFirestore() {
        try {
            val db = FirebaseManager.getFirestore() ?: return

            // Query 'kullanıcılar' collection where role == 'CEKICI' and isOnline == true
            db.collection("kullanıcılar").addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                parseAndMergeOnlineDrivers(snapshot.documents)
            }

            // Also query 'users' collection as fallback
            db.collection("users").addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                parseAndMergeOnlineDrivers(snapshot.documents)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Exception setting up Firestore online tow drivers listener: ${e.localizedMessage}")
        }
    }

    private fun parseAndMergeOnlineDrivers(documents: List<DocumentSnapshot>) {
        val firestoreDrivers = documents.mapNotNull { doc ->
            try {
                val roleStr = (doc.getString("role") ?: doc.getString("rol") ?: doc.getString("userType") ?: "").uppercase()
                val isOnline = doc.getBoolean("isOnline") ?: doc.getBoolean("online") ?: doc.getBoolean("isOnDuty") ?: false
                val isActive = doc.getBoolean("isActive") ?: (doc.getString("status") != "SUSPENDED")

                // STRICT FILTER: Only role == 'CEKICI', 'DUTY_TOW', 'yol_yardim', 'TOW_TRUCK'
                // NEVER include machine owners (OWNER) or customers (CUSTOMER)
                val isExcludedRole = roleStr == "OWNER" || roleStr.contains("SAHİP") || roleStr.contains("SAHIP") ||
                        roleStr == "CUSTOMER" || roleStr.contains("MÜŞTERİ") || roleStr.contains("MUSTERI")

                if (isExcludedRole) {
                    return@mapNotNull null
                }

                val isCekiciRole = roleStr == "CEKICI" || roleStr == "DUTY_TOW" || roleStr == "YOL_YARDIM" ||
                        roleStr.contains("ÇEKİCİ") || roleStr.contains("CEKICI") || roleStr.contains("TOW") ||
                        roleStr.contains("LASTİK") || roleStr.contains("LASTIK") || roleStr.contains("TIRE")

                if (!isCekiciRole) {
                    return@mapNotNull null
                }

                // Must be online (isOnline == true)
                if (!isOnline) {
                    return@mapNotNull null
                }

                val id = doc.getString("id") ?: doc.id
                val name = doc.getString("fullName") ?: doc.getString("adSoyad") ?: doc.getString("name") ?: "Nöbetçi Çekici"
                val phone = doc.getString("phone") ?: doc.getString("telefon") ?: "+90 532 000 00 00"
                val plate = doc.getString("plate") ?: doc.getString("plaka") ?: "34 CK 100"
                val city = doc.getString("city") ?: doc.getString("il") ?: "İstanbul"
                val district = doc.getString("district") ?: doc.getString("ilce") ?: "Merkez"
                val lat = getDouble(doc, 0.0, "latitude", "lat")
                val lng = getDouble(doc, 0.0, "longitude", "lng", "lon")
                val rating = getDouble(doc, 4.9, "rating", "puan")

                val isTire = roleStr.contains("LASTİK") || roleStr.contains("LASTIK") || roleStr.contains("TIRE") || roleStr == "DUTY_TIRE"
                val serviceTypes = if (isTire) {
                    listOf(EmergencyServiceType.TIRE_SERVICE)
                } else {
                    listOf(EmergencyServiceType.TOW_TRUCK)
                }

                EmergencyProvider(
                    id = id,
                    name = name,
                    phone = phone,
                    plate = plate,
                    role = if (isTire) "DUTY_TIRE" else "DUTY_TOW",
                    isOnline = true,
                    serviceTypes = serviceTypes,
                    detailInfo = if (isTire) "7/24 Nöbetçi Mobil Lastik Tamiri" else "7/24 Nöbetçi Çekici & Kurtarma",
                    city = city,
                    district = district,
                    latitude = lat,
                    longitude = lng,
                    isActive = isActive,
                    isOnDuty = true,
                    lastLocationUpdate = getLong(doc, System.currentTimeMillis(), "lastActive", "lastLocationUpdate"),
                    rating = rating,
                    completedJobs = getInt(doc, 100, "completedJobs")
                )
            } catch (ex: Exception) {
                null
            }
        }

        if (firestoreDrivers.isNotEmpty()) {
            val firestoreMap = firestoreDrivers.associateBy { it.id }
            val currentStatic = _activeTowDrivers.value.filter { it.id !in firestoreMap && it.role == "CEKICI" && it.isOnline }
            _activeTowDrivers.value = firestoreDrivers + currentStatic
            Log.d(TAG, "Updated active online tow drivers count: ${_activeTowDrivers.value.size}")
        }
    }

    private fun fetchEmergencyRequestsFromFirestore() {
        try {
            val db = FirebaseManager.getFirestore()
            if (db == null) {
                Log.w(TAG, "Firestore instance is null for emergency requests.")
                return
            }

            Log.d(TAG, "Starting real-time snapshot listener on 'emergencyRequests' collection...")
            db.collection("emergencyRequests").addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Log.w(TAG, "Firestore snapshot warning on 'emergencyRequests': ${e.localizedMessage}")
                    return@addSnapshotListener
                }

                if (snapshot == null) {
                    Log.w(TAG, "Firestore snapshot received is null for 'emergencyRequests' collection")
                    return@addSnapshotListener
                }

                val remoteReqs = snapshot.documents.mapNotNull { doc ->
                    try {
                        val serviceTypeStr = getString(doc, "serviceType", "hizmetTipi")
                        val serviceType = when {
                            serviceTypeStr.contains("TIRE", ignoreCase = true) || serviceTypeStr.contains("LASTIK", ignoreCase = true) -> EmergencyServiceType.TIRE_SERVICE
                            else -> EmergencyServiceType.TOW_TRUCK
                        }

                        val statusStr = getString(doc, "status", "durum")
                        val status = try {
                            EmergencyStatus.valueOf(statusStr.uppercase())
                        } catch (ex: Exception) {
                            EmergencyStatus.SEARCHING
                        }

                        val destinationLocationName = getString(doc, "destinationLocationName", "varisYeri", "hedefKonum")
                        val destinationLat = getDouble(doc, 41.060, "destinationLat", "hedefLat")
                        val destinationLng = getDouble(doc, 29.010, "destinationLng", "hedefLng")
                        val plate = getString(doc, "plate", "plaka")
                        val problemType = getString(doc, "problemType", "arizaTipi", "problem").ifBlank { "Aracım çalışmıyor" }
                        val tireDimension = getString(doc, "tireDimension", "lastikEbadi")
                        val hasSpareTire = doc.getBoolean("hasSpareTire") ?: doc.getBoolean("stepneVar") ?: true

                        @Suppress("UNCHECKED_CAST")
                        val rawOffers = doc.get("offers") as? List<Map<String, Any>> ?: emptyList()
                        val parsedOffers = rawOffers.mapNotNull { offMap ->
                            try {
                                com.example.data.model.EmergencyDriverOffer(
                                    id = (offMap["id"] as? String) ?: "",
                                    driverId = (offMap["driverId"] as? String) ?: "",
                                    driverName = (offMap["driverName"] as? String) ?: "",
                                    driverPhone = (offMap["driverPhone"] as? String) ?: "",
                                    driverPlate = (offMap["driverPlate"] as? String) ?: "",
                                    price = (offMap["price"] as? Number)?.toDouble() ?: 0.0,
                                    note = (offMap["note"] as? String) ?: "",
                                    estimatedMinutes = (offMap["estimatedMinutes"] as? Number)?.toInt() ?: 10,
                                    rating = (offMap["rating"] as? Number)?.toDouble() ?: 4.9,
                                    completedJobs = (offMap["completedJobs"] as? Number)?.toInt() ?: 184,
                                    offeredAt = (offMap["offeredAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
                                    isAcceptedByCustomer = (offMap["isAcceptedByCustomer"] as? Boolean) ?: false
                                )
                            } catch (e: Exception) { null }
                        }

                        EmergencyRequest(
                            id = getString(doc, "id").ifBlank { doc.id },
                            customerId = getString(doc, "customerId", "musteriId"),
                            customerName = getString(doc, "customerName", "musteriAdSoyad"),
                            customerPhone = getString(doc, "customerPhone", "musteriTelefon"),
                            customerLat = getDouble(doc, 41.0082, "customerLat", "lat"),
                            customerLng = getDouble(doc, 28.9784, "customerLng", "lng", "lon"),
                            customerLocationName = getString(doc, "customerLocationName", "konumAdi", "adres"),
                            destinationLocationName = destinationLocationName,
                            destinationLat = destinationLat,
                            destinationLng = destinationLng,
                            vehicleType = getString(doc, "vehicleType", "aracTipi").ifBlank { "Otomobil" },
                            plate = plate,
                            problemType = problemType,
                            tireDimension = tireDimension,
                            hasSpareTire = hasSpareTire,
                            description = getString(doc, "description", "aciklama"),
                            serviceType = serviceType,
                            status = status,
                            offers = parsedOffers,
                            assignedDriverId = getString(doc, "assignedDriverId", "surucuId"),
                            assignedDriverName = getString(doc, "assignedDriverName", "surucuAdi"),
                            assignedDriverPhone = getString(doc, "assignedDriverPhone", "surucuTelefon"),
                            assignedDriverPlate = getString(doc, "assignedDriverPlate", "surucuPlaka"),
                            driverLat = getDouble(doc, 41.0082, "driverLat"),
                            driverLng = getDouble(doc, 28.9784, "driverLng"),
                            estimatedDistanceKm = getDouble(doc, 0.0, "estimatedDistanceKm", "mesafeKm"),
                            estimatedTimeMinutes = getInt(doc, 0, "estimatedTimeMinutes", "tahminiDakika"),
                            agreedPrice = getDouble(doc, 0.0, "agreedPrice", "fiyat").takeIf { it > 0 },
                            priceStatus = getString(doc, "priceStatus", "fiyatDurumu"),
                            createdAt = getLong(doc, System.currentTimeMillis(), "createdAt", "olusturmaTarihi"),
                            acceptedAt = getLong(doc, 0L, "acceptedAt", "kabulTarihi"),
                            startedMissionAt = getLong(doc, 0L, "startedMissionAt"),
                            completedAt = getLong(doc, 0L, "completedAt", "tamamlanmaTarihi"),
                            userRating = getInt(doc, 0, "userRating", "puan").takeIf { it > 0 },
                            userComment = getString(doc, "userComment", "yorum")
                        )
                    } catch (ex: Exception) {
                        Log.w(TAG, "Failed to parse emergency request document '${doc.id}': ${ex.localizedMessage}")
                        null
                    }
                }

                val cutoffTime = System.currentTimeMillis() - com.example.data.util.DataCleanupManager.RETENTION_PERIOD_MS
                val activeOrRecentReqs = remoteReqs.filter { req ->
                    val isTerminal = req.status == EmergencyStatus.COMPLETED || req.status == EmergencyStatus.CANCELLED
                    val lastActionTime = req.completedAt?.takeIf { it > 0 } ?: req.acceptedAt?.takeIf { it > 0 } ?: req.createdAt
                    !isTerminal || lastActionTime >= cutoffTime
                }

                Log.d(TAG, "FIREBASE EMERGENCY READ: total=${remoteReqs.size}, activeOrRecent=${activeOrRecentReqs.size}")

                if (activeOrRecentReqs.isNotEmpty()) {
                    _emergencyRequests.value = activeOrRecentReqs
                } else if (remoteReqs.isEmpty()) {
                    _emergencyRequests.value = emptyList()
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Exception setting up Firestore emergency requests listener: ${e.localizedMessage}")
        }
    }

    // Helper: Haversine distance in KM
    fun calculateDistanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0 // Radius of earth in kilometers
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return String.format("%.1f", r * c).replace(",", ".").toDoubleOrNull() ?: (r * c)
    }

    // Radius search algorithm: 5km -> 10km -> 20km -> 30km
    fun findNearbyOnDutyProviders(
        serviceType: EmergencyServiceType,
        customerLat: Double,
        customerLng: Double
    ): List<Pair<EmergencyProvider, Double>> {
        // STRICT FILTER:
        // 1. Role must be 'CEKICI' / 'DUTY_TOW' / 'yol_yardim' (for tow service) or matching service type
        // 2. isOnline == true AND isActive == true AND isOnDuty == true
        // 3. Reject ANY machine owners or non-emergency roles
        val activeProviders = _activeTowDrivers.value.filter { provider ->
            val hasService = provider.serviceTypes.contains(serviceType)
            val isTow = serviceType == EmergencyServiceType.TOW_TRUCK
            val isTire = serviceType == EmergencyServiceType.TIRE_SERVICE
            val roleMatched = if (isTow) {
                hasService && !provider.role.contains("LASTİK", ignoreCase = true) && !provider.role.contains("TIRE", ignoreCase = true) && provider.role != "DUTY_TIRE"
            } else if (isTire) {
                hasService && !provider.role.contains("ÇEKİCİ", ignoreCase = true) && provider.role != "DUTY_TOW"
            } else {
                hasService
            }
            roleMatched && provider.isOnline && provider.isActive && provider.isOnDuty
        }

        val radiuses = listOf(5.0, 10.0, 20.0, 30.0)

        for (radius in radiuses) {
            val matched = activeProviders.map { provider ->
                val dist = calculateDistanceKm(customerLat, customerLng, provider.latitude, provider.longitude)
                Pair(provider, dist)
            }.filter { it.second <= radius }

            if (matched.isNotEmpty()) {
                return matched.sortedBy { it.second }
            }
        }

        // If none within 30km, return all active online providers sorted by distance
        return activeProviders.map { provider ->
            val dist = calculateDistanceKm(customerLat, customerLng, provider.latitude, provider.longitude)
            Pair(provider, dist)
        }.sortedBy { it.second }
    }

    // Deprecated alias for backwards compatibility
    fun findNearbyOnDutyDrivers(customerLat: Double, customerLng: Double): List<Pair<EmergencyProvider, Double>> {
        return findNearbyOnDutyProviders(EmergencyServiceType.TOW_TRUCK, customerLat, customerLng)
    }

    // Create Emergency Request
    fun createEmergencyRequest(request: EmergencyRequest): EmergencyRequest {
        val nearbyProviders = findNearbyOnDutyProviders(request.serviceType, request.customerLat, request.customerLng)
        val closestProvider = nearbyProviders.firstOrNull()?.first
        val initialDist = nearbyProviders.firstOrNull()?.second ?: 3.5
        val initialEta = (initialDist * 2.5).toInt().coerceAtLeast(3)

        val newRequest = request.copy(
            id = if (request.id.isBlank()) "req_${System.currentTimeMillis()}" else request.id,
            createdAt = System.currentTimeMillis(),
            status = EmergencyStatus.SEARCHING,
            estimatedDistanceKm = initialDist,
            estimatedTimeMinutes = initialEta,
            driverLat = closestProvider?.latitude ?: (request.customerLat + 0.015),
            driverLng = closestProvider?.longitude ?: (request.customerLng + 0.012)
        )

        _emergencyRequests.value = listOf(newRequest) + _emergencyRequests.value.filter { it.id != newRequest.id }
        syncEmergencyRequestToFirestore(newRequest)

        val detailSnippet = buildString {
            append("${newRequest.customerName} (${newRequest.vehicleType}")
            if (newRequest.plate.isNotBlank()) append(" - ${newRequest.plate}")
            append(")")
            if (newRequest.destinationLocationName.isNotBlank()) append(" ➔ Hedef: ${newRequest.destinationLocationName}")
            append(" • Sorun: ${newRequest.problemType}")
        }

        // Trigger FCM Push Notification for Emergency Request (STRICTLY TARGETED)
        val isTireRequest = newRequest.serviceType == EmergencyServiceType.TIRE_SERVICE
        val targetRoleRecipient = if (isTireRequest) "DUTY_TIRE_PROVIDERS" else "DUTY_TOW_PROVIDERS"
        val specificType = if (isTireRequest) "EMERGENCY_REQUEST_TIRE" else "EMERGENCY_REQUEST_TOW"
        val titleIcon = if (isTireRequest) "🛞 YENİ ACİL LASTİK ÇAĞRISI!" else "🚨 YENİ ACİL ÇEKİCİ ÇAĞRISI!"

        FirebaseManager.sendPushNotification(
            title = "$titleIcon (${newRequest.serviceType.title})",
            body = "$detailSnippet | Konum: ${newRequest.customerLocationName}",
            type = specificType,
            recipientUserId = targetRoleRecipient,
            extraData = mapOf(
                "requestId" to newRequest.id,
                "serviceType" to newRequest.serviceType.name,
                "customerName" to newRequest.customerName,
                "customerPhone" to newRequest.customerPhone,
                "vehicleType" to newRequest.vehicleType,
                "plate" to newRequest.plate,
                "problemType" to newRequest.problemType,
                "destination" to newRequest.destinationLocationName,
                "location" to newRequest.customerLocationName,
                "description" to newRequest.description
            )
        )

        return newRequest
    }

    /**
     * Observe a specific emergency request reactively as a Flow
     */
    fun getRequestFlow(requestId: String): Flow<EmergencyRequest?> {
        return _emergencyRequests.map { list -> list.find { it.id == requestId } }
    }

    private fun getGuestPrefs(): android.content.SharedPreferences? {
        return FirebaseManager.appContext?.getSharedPreferences("makinebul_guest_prefs", android.content.Context.MODE_PRIVATE)
    }

    fun saveActiveGuestRequestId(requestId: String) {
        try {
            getGuestPrefs()?.edit()?.putString("active_guest_request_id", requestId)?.apply()
        } catch (e: Exception) {
            Log.w(TAG, "Could not save guest request id: ${e.localizedMessage}")
        }
    }

    fun getActiveGuestRequestId(): String? {
        return try {
            getGuestPrefs()?.getString("active_guest_request_id", null)
        } catch (e: Exception) {
            null
        }
    }

    fun clearActiveGuestRequestId() {
        try {
            getGuestPrefs()?.edit()?.remove("active_guest_request_id")?.apply()
        } catch (e: Exception) {
            Log.w(TAG, "Could not clear guest request id: ${e.localizedMessage}")
        }
    }

    /**
     * Fast Emergency Call creation without login / registration.
     * Uses Firebase Anonymous Authentication in the background.
     */
    suspend fun createAnonymousEmergencyRequest(
        serviceType: EmergencyServiceType,
        customerPhone: String,
        customerName: String = "Misafir Sürücü",
        customerLocationName: String,
        customerLat: Double,
        customerLng: Double,
        destinationLocationName: String = "",
        vehicleType: String = "Otomobil",
        plate: String = "",
        problemType: String = "",
        tireDimension: String = "",
        hasSpareTire: Boolean = true,
        description: String = ""
    ): EmergencyRequest = withContext(Dispatchers.IO) {
        // 1. Firebase Anonymous Authentication
        val auth = FirebaseManager.getAuth()
        val anonUid = if (auth != null) {
            val currentUser = auth.currentUser
            if (currentUser != null) {
                currentUser.uid
            } else {
                try {
                    val task = auth.signInAnonymously()
                    val res = com.google.android.gms.tasks.Tasks.await(task)
                    res.user?.uid ?: "anon_${System.currentTimeMillis()}"
                } catch (e: Exception) {
                    Log.w(TAG, "Anonymous sign in exception: ${e.localizedMessage}")
                    "anon_${System.currentTimeMillis()}"
                }
            }
        } else {
            "anon_${System.currentTimeMillis()}"
        }

        // 2. Set active user in FirebaseManager for notification routing
        FirebaseManager.setActiveUser(anonUid, com.example.data.model.UserType.CUSTOMER)

        val reqId = "anon_req_${System.currentTimeMillis()}"

        // 3. Create EmergencyRequest
        val request = EmergencyRequest(
            id = reqId,
            serviceType = serviceType,
            customerId = anonUid,
            customerName = customerName.ifBlank { "Misafir Sürücü (Acil)" },
            customerPhone = customerPhone,
            customerLocationName = customerLocationName,
            customerLat = customerLat,
            customerLng = customerLng,
            destinationLocationName = destinationLocationName,
            vehicleType = vehicleType.ifBlank { "Otomobil" },
            plate = plate,
            problemType = problemType.ifBlank { if (serviceType == EmergencyServiceType.TIRE_SERVICE) "Lastik Patladı" else "Aracım Çalışmıyor" },
            tireDimension = tireDimension,
            hasSpareTire = hasSpareTire,
            description = description,
            status = EmergencyStatus.SEARCHING,
            createdAt = System.currentTimeMillis()
        )

        val created = createEmergencyRequest(request)
        saveActiveGuestRequestId(reqId)

        return@withContext created
    }

    // Send Price Offer (by provider/driver)
    fun sendPriceOffer(
        requestId: String,
        price: Double,
        driverId: String,
        driverName: String,
        driverPhone: String,
        driverPlate: String,
        note: String = "",
        estimatedMinutes: Int = 10
    ): Boolean {
        val current = _emergencyRequests.value.find { it.id == requestId } ?: return false

        // If request is already started by someone, reject
        val isStarted = (current.startedMissionAt != null && current.startedMissionAt > 0)
        val isOngoing = current.status == EmergencyStatus.ARRIVING ||
                current.status == EmergencyStatus.ARRIVED ||
                current.status == EmergencyStatus.IN_SERVICE ||
                current.status == EmergencyStatus.COMPLETED ||
                current.status == EmergencyStatus.CANCELLED ||
                (current.status == EmergencyStatus.ACCEPTED && isStarted)

        if (isOngoing) {
            Log.w(TAG, "Request $requestId is already ongoing (${current.status}), cannot send offer.")
            return false
        }

        val existingOffer = current.offers.find { it.driverId == driverId }
        val newOffer = com.example.data.model.EmergencyDriverOffer(
            id = existingOffer?.id?.ifBlank { "off_${System.currentTimeMillis()}_$driverId" } ?: "off_${System.currentTimeMillis()}_$driverId",
            driverId = driverId,
            driverName = driverName,
            driverPhone = driverPhone,
            driverPlate = driverPlate,
            price = price,
            note = note,
            estimatedMinutes = estimatedMinutes,
            offeredAt = System.currentTimeMillis(),
            isAcceptedByCustomer = false
        )

        val updatedOffers = current.offers.filter { it.driverId != driverId } + newOffer

        val updated = current.copy(
            status = EmergencyStatus.OFFERED,
            offers = updatedOffers
        )
        _emergencyRequests.value = _emergencyRequests.value.map {
            if (it.id == requestId) updated else it
        }
        syncEmergencyRequestToFirestore(updated)

        // Trigger FCM Push Notification to Customer
        FirebaseManager.sendPushNotification(
            title = "🚚 Çekici / Lastikçi Fiyat Teklifi Sunuldu!",
            body = "$driverName usta $price ₺ tutarında teklif verdi. İncelemek ve kabul etmek için dokunun.",
            type = "EMERGENCY_OFFER",
            recipientUserId = current.customerId,
            extraData = mapOf("requestId" to requestId, "price" to price.toString(), "driverId" to driverId)
        )

        return true
    }

    // Customer accepts one specific driver's price offer
    fun acceptOfferByCustomer(requestId: String, driverId: String) {
        val current = _emergencyRequests.value.find { it.id == requestId } ?: return
        val chosenOffer = current.offers.find { it.driverId == driverId } ?: return

        val updatedOffers = current.offers.map {
            if (it.driverId == driverId) it.copy(isAcceptedByCustomer = true) else it.copy(isAcceptedByCustomer = false)
        }

        val updated = current.copy(
            status = EmergencyStatus.OFFERED,
            offers = updatedOffers,
            assignedDriverId = driverId,
            assignedDriverName = chosenOffer.driverName,
            assignedDriverPhone = chosenOffer.driverPhone,
            assignedDriverPlate = chosenOffer.driverPlate,
            agreedPrice = chosenOffer.price,
            priceStatus = "CUSTOMER_ACCEPTED"
        )

        _emergencyRequests.value = _emergencyRequests.value.map {
            if (it.id == requestId) updated else it
        }
        syncEmergencyRequestToFirestore(updated)

        // Trigger FCM Push Notification to Driver
        FirebaseManager.sendPushNotification(
            title = "🎉 Müşteri Teklifinizi Onayladı!",
            body = "${current.customerName} ${chosenOffer.price} ₺ tutarındaki teklifinizi seçti. Görevi başlatmak ve yola çıkmak için dokunun!",
            type = "EMERGENCY_OFFER_ACCEPTED",
            recipientUserId = driverId,
            extraData = mapOf("requestId" to requestId, "driverId" to driverId)
        )
    }

    // Customer responds to single active price offer (backwards compatibility)
    fun respondToPriceOffer(requestId: String, accept: Boolean) {
        val current = _emergencyRequests.value.find { it.id == requestId } ?: return
        val driverId = current.assignedDriverId ?: current.offers.firstOrNull()?.driverId
        if (accept && !driverId.isNullOrBlank()) {
            acceptOfferByCustomer(requestId, driverId)
        } else {
            val updated = current.copy(
                status = EmergencyStatus.SEARCHING,
                priceStatus = "REJECTED"
            )
            _emergencyRequests.value = _emergencyRequests.value.map {
                if (it.id == requestId) updated else it
            }
            syncEmergencyRequestToFirestore(updated)
        }
    }

    // Driver confirms & starts mission (At this moment it disappears from all other drivers)
    @Synchronized
    fun startMissionByDriver(
        requestId: String,
        driverId: String,
        driverName: String = "",
        driverPhone: String = "",
        driverPlate: String = ""
    ): Boolean {
        val current = _emergencyRequests.value.find { it.id == requestId } ?: return false

        // If already started by someone else
        val isStartedByOther = (current.startedMissionAt != null && current.startedMissionAt > 0 && current.assignedDriverId != driverId)
        if (isStartedByOther) {
            Log.w(TAG, "Request $requestId is already started by another driver ${current.assignedDriverId}")
            return false
        }

        val now = System.currentTimeMillis()
        val finalDriverName = driverName.ifBlank { current.assignedDriverName ?: "Çekici Ustası" }
        val finalDriverPhone = driverPhone.ifBlank { current.assignedDriverPhone ?: "" }
        val finalDriverPlate = driverPlate.ifBlank { current.assignedDriverPlate ?: "" }

        // Çekicinin başlangıç konumu: kayıtlı dükkan adresinin koordinatı
        val provider = _activeTowDrivers.value.find { it.id == driverId }
        val hasShopLocation = provider != null && provider.latitude != 0.0 && provider.longitude != 0.0
        val startLat = if (hasShopLocation) provider!!.latitude else current.driverLat
        val startLng = if (hasShopLocation) provider!!.longitude else current.driverLng
        val distKm = calculateDistanceKm(current.customerLat, current.customerLng, startLat, startLng)

        val updated = current.copy(
            status = EmergencyStatus.ARRIVING,
            assignedDriverId = driverId,
            assignedDriverName = finalDriverName,
            assignedDriverPhone = finalDriverPhone,
            assignedDriverPlate = finalDriverPlate,
            driverLat = startLat,
            driverLng = startLng,
            estimatedDistanceKm = distKm,
            estimatedTimeMinutes = (distKm * 2.5).toInt().coerceAtLeast(1),
            acceptedAt = now,
            startedMissionAt = now,
            priceStatus = "ACCEPTED"
        )

        _emergencyRequests.value = _emergencyRequests.value.map {
            if (it.id == requestId) updated else it
        }
        syncEmergencyRequestToFirestore(updated)

        // Real-time Push Notification to Customer that driver is on the road
        FirebaseManager.sendPushNotification(
            title = "🚗 Çekici Yola Çıktı!",
            body = "$finalDriverName görevi başlattı ve konumunuza doğru yola çıktı. Tahmini varış: ${updated.estimatedTimeMinutes} dk.",
            type = "MISSION_ARRIVING",
            recipientUserId = updated.customerId,
            extraData = mapOf("requestId" to requestId)
        )

        startLiveDriverProgression(requestId)
        return true
    }

    // Transaction-safe call acceptance
    @Synchronized
    fun acceptRequest(
        requestId: String,
        driverId: String,
        driverName: String,
        driverPhone: String,
        driverPlate: String
    ): Boolean {
        return startMissionByDriver(requestId, driverId, driverName, driverPhone, driverPlate)
    }

    fun updateRequestStatus(requestId: String, newStatus: EmergencyStatus) {
        val currentReq = _emergencyRequests.value.find { it.id == requestId }
        val compTime = if (newStatus == EmergencyStatus.COMPLETED) System.currentTimeMillis() else currentReq?.completedAt
        val updated = currentReq?.copy(status = newStatus, completedAt = compTime) ?: return

        _emergencyRequests.value = _emergencyRequests.value.map {
            if (it.id == requestId) updated else it
        }
        syncEmergencyRequestToFirestore(updated)

        // Trigger real-time notifications for customer
        when (newStatus) {
            EmergencyStatus.ARRIVING -> {
                FirebaseManager.sendPushNotification(
                    title = "🚗 Çekici / Lastikçi Yola Çıktı!",
                    body = "${updated.assignedDriverName ?: "Çekici ustası"} yola çıktı, konumunuza doğru ilerliyor. Tahmini varış: ${updated.estimatedTimeMinutes} dk.",
                    type = "MISSION_ARRIVING",
                    recipientUserId = updated.customerId,
                    extraData = mapOf("requestId" to requestId)
                )
                startLiveDriverProgression(requestId)
            }
            EmergencyStatus.ARRIVED -> {
                FirebaseManager.sendPushNotification(
                    title = "📍 Çekici / Servis Konumunuza Ulaştı!",
                    body = "${updated.assignedDriverName ?: "Çekici"} adresinize vardı. Lütfen aracınızın başında bulunun.",
                    type = "MISSION_ARRIVED",
                    recipientUserId = updated.customerId,
                    extraData = mapOf("requestId" to requestId)
                )
            }
            EmergencyStatus.IN_SERVICE -> {
                FirebaseManager.sendPushNotification(
                    title = "🔧 Hizmet Başladı",
                    body = "Oto kurtarma / lastik onarım hizmeti başlatıldı.",
                    type = "MISSION_IN_SERVICE",
                    recipientUserId = updated.customerId,
                    extraData = mapOf("requestId" to requestId)
                )
            }
            EmergencyStatus.COMPLETED -> {
                FirebaseManager.sendPushNotification(
                    title = "✅ Hizmet Tamamlandı!",
                    body = "Acil çekici/lastik hizmeti başarıyla tamamlandı. Hizmeti puanlayabilirsiniz.",
                    type = "MISSION_COMPLETED",
                    recipientUserId = updated.customerId,
                    extraData = mapOf("requestId" to requestId)
                )
            }
            else -> {}
        }
    }

    private fun startLiveDriverProgression(requestId: String) {
        scope.launch {
            val req = _emergencyRequests.value.find { it.id == requestId } ?: return@launch
            val startLat = req.driverLat
            val startLng = req.driverLng
            val targetLat = req.customerLat
            val targetLng = req.customerLng
            val steps = 6

            for (i in 1..steps) {
                delay(2000)
                val current = _emergencyRequests.value.find { it.id == requestId } ?: break
                if (current.status != EmergencyStatus.ARRIVING) break

                val fraction = i.toDouble() / steps
                val curLat = startLat + (targetLat - startLat) * fraction
                val curLng = startLng + (targetLng - startLng) * fraction
                updateDriverLocation(requestId, curLat, curLng)
            }
        }
    }

    fun updateDriverLocation(requestId: String, lat: Double, lng: Double) {
        _emergencyRequests.value = _emergencyRequests.value.map { req ->
            if (req.id == requestId) {
                val dist = calculateDistanceKm(req.customerLat, req.customerLng, lat, lng)
                val eta = (dist * 2.5).toInt().coerceAtLeast(1)
                req.copy(
                    driverLat = lat,
                    driverLng = lng,
                    estimatedDistanceKm = dist,
                    estimatedTimeMinutes = eta
                )
            } else req
        }
    }

    fun rateService(requestId: String, rating: Int, comment: String) {
        _emergencyRequests.value = _emergencyRequests.value.map { req ->
            if (req.id == requestId) {
                req.copy(userRating = rating, userComment = comment)
            } else req
        }
    }

    fun cancelRequest(requestId: String) {
        updateRequestStatus(requestId, EmergencyStatus.CANCELLED)
    }

    fun toggleDriverDuty(driverId: String, isOnDuty: Boolean) {
        _activeTowDrivers.value = _activeTowDrivers.value.map {
            if (it.id == driverId) it.copy(isOnDuty = isOnDuty, isOnline = isOnDuty) else it
        }
        updateDriverOnlineStatusInFirestore(driverId, isOnDuty, isOnDuty)
    }

    fun toggleDriverActive(driverId: String, isActive: Boolean) {
        _activeTowDrivers.value = _activeTowDrivers.value.map {
            if (it.id == driverId) it.copy(isActive = isActive, isOnline = isActive, lastLocationUpdate = System.currentTimeMillis()) else it
        }
        updateDriverOnlineStatusInFirestore(driverId, isActive, isActive)
    }

    private fun updateDriverOnlineStatusInFirestore(driverId: String, isOnline: Boolean, isOnDuty: Boolean) {
        try {
            val db = FirebaseManager.getFirestore() ?: return
            val updates = hashMapOf<String, Any>(
                "isOnline" to isOnline,
                "isOnDuty" to isOnDuty,
                "isActive" to isOnline,
                "lastActive" to System.currentTimeMillis()
            )
            db.collection("kullanıcılar").document(driverId).update(updates)
            db.collection("users").document(driverId).update(updates)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to update driver online status in Firestore: ${e.localizedMessage}")
        }
    }

    // Simulation tool for live tracking demo
    fun simulateDriverProgress(requestId: String) {
        scope.launch {
            val req = _emergencyRequests.value.find { it.id == requestId } ?: return@launch

            // Step 1: Auto accept if still searching/offered
            if (req.status == EmergencyStatus.SEARCHING || req.status == EmergencyStatus.OFFERED) {
                val matchingProvider = _activeTowDrivers.value.find { it.serviceTypes.contains(req.serviceType) && it.isActive }
                    ?: _activeTowDrivers.value.first()

                acceptRequest(
                    requestId = requestId,
                    driverId = matchingProvider.id,
                    driverName = matchingProvider.name,
                    driverPhone = matchingProvider.phone,
                    driverPlate = matchingProvider.plate
                )
                delay(2000)
            }

            // Step 2: Arriving status & movement
            updateRequestStatus(requestId, EmergencyStatus.ARRIVING)

            val startLat = req.driverLat
            val startLng = req.driverLng
            val targetLat = req.customerLat
            val targetLng = req.customerLng
            val steps = 8

            for (i in 1..steps) {
                delay(1500)
                val currentReq = _emergencyRequests.value.find { it.id == requestId } ?: break
                if (currentReq.status == EmergencyStatus.CANCELLED) break

                val fraction = i.toDouble() / steps
                val curLat = startLat + (targetLat - startLat) * fraction
                val curLng = startLng + (targetLng - startLng) * fraction
                updateDriverLocation(requestId, curLat, curLng)
            }

            // Step 3: Arrived
            val currentReq = _emergencyRequests.value.find { it.id == requestId }
            if (currentReq?.status != EmergencyStatus.CANCELLED) {
                updateRequestStatus(requestId, EmergencyStatus.ARRIVED)
                delay(3000)
                updateRequestStatus(requestId, EmergencyStatus.IN_SERVICE)
                delay(4000)
                updateRequestStatus(requestId, EmergencyStatus.COMPLETED)
            }
        }
    }

    private fun syncEmergencyRequestToFirestore(request: EmergencyRequest) {
        try {
            val db = FirebaseManager.getFirestore()
            if (db == null) {
                Log.w(TAG, "Firestore instance is null. Cannot save emergency request ${request.id}")
                return
            }
            val reqMap = hashMapOf(
                "id" to request.id,
                "customerId" to request.customerId,
                "customerName" to request.customerName,
                "customerPhone" to request.customerPhone,
                "customerLat" to request.customerLat,
                "customerLng" to request.customerLng,
                "customerLocationName" to request.customerLocationName,
                "destinationLocationName" to request.destinationLocationName,
                "destinationLat" to request.destinationLat,
                "destinationLng" to request.destinationLng,
                "plate" to request.plate,
                "problemType" to request.problemType,
                "tireDimension" to request.tireDimension,
                "hasSpareTire" to request.hasSpareTire,
                "description" to request.description,
                "vehicleType" to request.vehicleType,
                "serviceType" to request.serviceType.name,
                "status" to request.status.name,
                "offers" to request.offers.map { off ->
                    hashMapOf(
                        "id" to off.id,
                        "driverId" to off.driverId,
                        "driverName" to off.driverName,
                        "driverPhone" to off.driverPhone,
                        "driverPlate" to off.driverPlate,
                        "price" to off.price,
                        "note" to off.note,
                        "estimatedMinutes" to off.estimatedMinutes,
                        "rating" to off.rating,
                        "completedJobs" to off.completedJobs,
                        "offeredAt" to off.offeredAt,
                        "isAcceptedByCustomer" to off.isAcceptedByCustomer
                    )
                },
                "assignedDriverId" to request.assignedDriverId,
                "assignedDriverName" to request.assignedDriverName,
                "assignedDriverPhone" to request.assignedDriverPhone,
                "assignedDriverPlate" to request.assignedDriverPlate,
                "driverLat" to request.driverLat,
                "driverLng" to request.driverLng,
                "estimatedDistanceKm" to request.estimatedDistanceKm,
                "estimatedTimeMinutes" to request.estimatedTimeMinutes,
                "agreedPrice" to request.agreedPrice,
                "priceStatus" to request.priceStatus,
                "createdAt" to request.createdAt,
                "acceptedAt" to request.acceptedAt,
                "startedMissionAt" to request.startedMissionAt,
                "completedAt" to request.completedAt,
                "userRating" to request.userRating,
                "userComment" to request.userComment,

                // Turkish aliases for backwards compatibility
                "musteriId" to request.customerId,
                "musteriAdSoyad" to request.customerName,
                "musteriTelefon" to request.customerPhone,
                "varisYeri" to request.destinationLocationName,
                "plaka" to request.plate,
                "arizaTipi" to request.problemType,
                "lastikEbadi" to request.tireDimension,
                "stepneVar" to request.hasSpareTire,
                "hizmetTipi" to request.serviceType.name,
                "durum" to request.status.name,
                "olusturmaTarihi" to request.createdAt
            )
            Log.d(TAG, "Writing emergency request to Firestore 'emergencyRequests' collection: ${request.id}")
            db.collection("emergencyRequests").document(request.id).set(reqMap)
                .addOnSuccessListener {
                    Log.d(TAG, "FIREBASE EMERGENCY WRITE SUCCESS: ${request.id}")
                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "Write emergency request to Firestore failed: ${e.localizedMessage}")
                }
        } catch (e: Exception) {
            Log.w(TAG, "Exception syncing emergency request to Firestore: ${e.localizedMessage}")
        }
    }

    // Safe Firestore field parsing helpers
    private fun getString(doc: DocumentSnapshot, vararg keys: String): String {
        for (key in keys) {
            val valStr = doc.getString(key)
            if (!valStr.isNullOrBlank()) return valStr
            val rawObj = doc.get(key)
            if (rawObj != null && rawObj.toString().isNotBlank()) return rawObj.toString()
        }
        return ""
    }

    private fun getDouble(doc: DocumentSnapshot, defaultValue: Double, vararg keys: String): Double {
        for (key in keys) {
            val obj = doc.get(key)
            if (obj is Number) return obj.toDouble()
            if (obj is String) {
                val parsed = obj.toDoubleOrNull()
                if (parsed != null) return parsed
            }
        }
        return defaultValue
    }

    private fun getInt(doc: DocumentSnapshot, defaultValue: Int, vararg keys: String): Int {
        for (key in keys) {
            val obj = doc.get(key)
            if (obj is Number) return obj.toInt()
            if (obj is String) {
                val parsed = obj.toIntOrNull()
                if (parsed != null) return parsed
            }
        }
        return defaultValue
    }

    private fun getLong(doc: DocumentSnapshot, defaultValue: Long, vararg keys: String): Long {
        for (key in keys) {
            val obj = doc.get(key)
            if (obj is Number) return obj.toLong()
            if (obj is String) {
                val parsed = obj.toLongOrNull()
                if (parsed != null) return parsed
            }
        }
        return defaultValue
    }
}
