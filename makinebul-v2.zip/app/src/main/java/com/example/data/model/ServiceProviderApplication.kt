package com.example.data.model

data class ServiceProviderApplication(
    val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val userPhone: String = "",
    val userEmail: String = "",
    val requestedRole: String = "OWNER", // "OWNER", "TOW_TRUCK", "TIRE_SERVICE"
    val companyName: String = "",
    val taxNumber: String = "",
    val city: String = "İstanbul",
    val district: String = "Ümraniye",
    val note: String = "",
    val status: String = "PENDING", // "PENDING", "APPROVED", "REJECTED"
    val createdAt: Long = System.currentTimeMillis()
)
