package com.example.data.model

data class Machine(
    val id: String = "",
    val ownerId: String = "",
    val ownerName: String = "",
    val ownerPhone: String = "",
    val title: String = "",
    val category: String = "",
    val brand: String = "",
    val model: String = "",
    val year: Int = 2022,
    val description: String = "",
    val hourlyPrice: Double = 0.0,
    val dailyPrice: Double = 0.0,
    val minWorkingHours: Int = 2,
    val city: String = "",
    val district: String = "",
    val address: String = "",
    val latitude: Double = 41.0082,
    val longitude: Double = 28.9784,
    val distanceKm: Double = 0.0,
    val isAvailable: Boolean = true,
    val hasOperator: Boolean = true,
    val fuelIncluded: Boolean = false,
    val isLowbedTransport: Boolean = false,
    val blockedDates: List<String> = emptyList(), // "YYYY-MM-DD" e.g. ["2026-08-20", "2026-08-21"]
    val rating: Double = 0.0,
    val reviewCount: Int = 0,
    val photos: List<String> = emptyList(),
    /** İlan onay durumu: "pending" (Onay Bekliyor), "approved" (Onaylandı), "rejected" (Reddedildi). Eski kayıtlarda alan yoksa onaylı sayılır. */
    val status: String = "approved",
    /** Onaylanan tekliflerle otomatik dolan günler ("YYYY-MM-DD"). */
    val reservedDates: List<String> = emptyList(),
    /** Reddedilen ilanlarda yöneticinin yazdığı sebep. */
    val rejectionReason: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
