package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.Review
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ReviewRepository {

    private val scope = CoroutineScope(Dispatchers.IO)
    private val _reviews = MutableStateFlow<List<Review>>(emptyList())
    val reviews: StateFlow<List<Review>> = _reviews.asStateFlow()

    init {
        FirebaseManager.runWhenAuthenticated { listenToFirestoreReviews() }
    }

    private fun listenToFirestoreReviews() {
        if (!FirebaseManager.isAvailable) return

        scope.launch {
            try {
                FirebaseManager.db?.collection("reviews")
                    ?.addSnapshotListener { snapshot, error ->
                        if (error != null || snapshot == null) return@addSnapshotListener
                        val list = snapshot.documents.mapNotNull { docToReview(it) }
                        _reviews.value = list
                    }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun addReview(review: Review): Review {
        val newRev = if (review.id.isBlank()) review.copy(id = "rev_${System.currentTimeMillis()}") else review
        _reviews.value = listOf(newRev) + _reviews.value

        if (FirebaseManager.isAvailable) {
            scope.launch {
                try {
                    val map = hashMapOf<String, Any>(
                        "id" to newRev.id,
                        "targetType" to newRev.targetType,
                        "targetId" to newRev.targetId,
                        "reviewerId" to newRev.reviewerId,
                        "reviewerName" to newRev.reviewerName,
                        "rating" to newRev.rating,
                        "comment" to newRev.comment,
                        "tags" to newRev.tags,
                        "createdAt" to newRev.createdAt
                    )
                    FirebaseManager.db?.collection("reviews")?.document(newRev.id)?.set(map)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
        return newRev
    }

    fun addReview(
        targetType: String,
        targetId: String,
        reviewerId: String,
        reviewerName: String,
        rating: Double,
        comment: String,
        tags: List<String>
    ): Review {
        val newRev = Review(
            id = "rev_${System.currentTimeMillis()}",
            targetType = targetType,
            targetId = targetId,
            reviewerId = reviewerId,
            reviewerName = reviewerName,
            rating = rating,
            comment = comment,
            tags = tags,
            createdAt = System.currentTimeMillis()
        )
        return addReview(newRev)
    }

    fun getReviewsForTarget(targetId: String): List<Review> {
        return _reviews.value.filter { it.targetId == targetId }
    }

    fun getReviewsForMachine(machineId: String): List<Review> {
        return _reviews.value.filter { it.targetId == machineId }
    }

    private fun docToReview(doc: DocumentSnapshot): Review? {
        return try {
            Review(
                id = doc.getString("id") ?: doc.id,
                targetType = doc.getString("targetType") ?: "MACHINE",
                targetId = doc.getString("targetId") ?: "",
                reviewerId = doc.getString("reviewerId") ?: "",
                reviewerName = doc.getString("reviewerName") ?: "Anonim",
                rating = (doc.getDouble("rating") ?: 5.0),
                comment = doc.getString("comment") ?: "",
                tags = (doc.get("tags") as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList(),
                createdAt = (doc.getLong("createdAt") ?: System.currentTimeMillis())
            )
        } catch (e: Exception) {
            null
        }
    }
}
