package com.example.data.model

data class Category(
    val id: String,
    val name: String,
    val iconName: String,
    val description: String = ""
)

object MachineCategories {
    val ALL = listOf(
        "Tümü",
        "Boyacı & Badana",
        "İnşaat Ustası & İşçilik",
        "Sıva & Alçı & Alçıpan",
        "Elektrik & Aydınlatma",
        "Sıhhi Tesisat & Doğalgaz",
        "Çatı & İzolasyon & Yalıtım",
        "Fayans & Seramik & Mermer",
        "Zemin & Şap & Epoksi",
        "Hafriyat & Yıkım & Moloz",
        "Mobil Vinç",
        "Ekskavatör",
        "JCB & Kazıcı Yükleyici",
        "Forklift",
        "Sepetli Platform",
        "Manitou & Telehandler",
        "Loder & Yükleyici",
        "Dozer",
        "Silindir",
        "Çekici & Kurtarıcı",
        "Acil Çekici & Lastikçi",
        "Lowbed Taşıma",
        "Diğer İnşaat & Ekipman"
    )

    val CATEGORIES = listOf(
        Category("boyaci", "Boyacı & Badana", "ic_painter", "İç/Dış cephe boya, badana ve dekorasyon ustaları"),
        Category("insaat_ustasi", "İnşaat Ustası & İşçilik", "ic_builder", "Kalıp, demir, duvar ve kaba inşaat ustaları"),
        Category("siva_alcipan", "Sıva & Alçı & Alçıpan", "ic_plaster", "Alçı sıva, kara sıva, asma tavan ve bölme duvar"),
        Category("elektrik", "Elektrik & Aydınlatma", "ic_electric", "Şantiye, bina ve pano elektrik tesisat işleri"),
        Category("tesisat", "Sıhhi Tesisat & Doğalgaz", "ic_plumbing", "Temiz su, pis su, doğalgaz ve yangın tesisatı"),
        Category("cati_izolasyon", "Çatı & İzolasyon", "ic_roofing", "Çatı aktarma, membran, su ve ısı yalıtımı"),
        Category("fayans_seramik", "Fayans & Seramik", "ic_tiling", "Banyo, zemin, granit ve seramik döşeme"),
        Category("zemin_sap", "Zemin & Şap & Epoksi", "ic_flooring", "Helikopter şap, epoksi ve zemin kaplama"),
        Category("hafriyat_yikim", "Hafriyat & Yıkım", "ic_excavation", "Bina yıkımı, kırım, moloz atımı ve temel kazısı"),
        Category("mobil_vinc", "Mobil Vinç", "ic_crane", "Yüksek tonajlı kaldırma ve taşıma"),
        Category("ekskavator", "Ekskavatör", "ic_excavator", "Ağır hafriyat ve kazı işleri"),
        Category("jcb", "JCB & Kazıcı Yükleyici", "ic_loader_backhoe", "Kanal, kazı ve yükleme işleri"),
        Category("forklift", "Forklift", "ic_forklift", "Depo ve şantiye yük istifleme"),
        Category("sepetli_platform", "Sepetli Platform", "ic_platform", "Dış cephe ve yüksek alan çalışmaları"),
        Category("manitou", "Manitou & Telehandler", "ic_telehandler", "Teleskobik yükleyici ve istifleme"),
        Category("loder", "Loder", "ic_wheel_loader", "Toprak, kum ve moloz yükleme"),
        Category("dozer", "Dozer", "ic_dozer", "Arazi düzleme ve yol açma"),
        Category("silindir", "Silindir", "ic_roller", "Toprak ve asfalt sıkıştırma"),
        Category("cekici", "Çekici & Kurtarıcı", "ic_tow", "Araç ve makine transferi"),
        Category("acil_cekici", "Acil Çekici & Lastikçi", "ic_emergency_tow", "7/24 Acil yol yardım ve kurtarma"),
        Category("lowbed", "Lowbed Taşıma", "ic_lowbed", "Ağır iş makinesi şehirler arası nakliye"),
        Category("diger", "Diğer İnşaat & Ekipman", "ic_other", "Diğer özel inşaat araç ve hizmetleri")
    )
}
