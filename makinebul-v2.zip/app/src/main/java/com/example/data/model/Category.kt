package com.example.data.model

data class Category(
    val id: String,
    val name: String,
    val iconName: String,
    val description: String = ""
)

object MachineCategories {
    val ALL = listOf(
        "Tümü",
        "Mobil Vinç",
        "Ekskavatör",
        "JCB & Kazıcı Yükleyici",
        "Forklift",
        "Sepetli Platform",
        "Manitou & Telehandler",
        "Loder & Yükleyici",
        "Dozer",
        "Silindir",
        "Çekici & Kurtarıcı",
        "Lowbed Taşıma",
        "Diğer İnşaat & Ekipman"
    )

    val CATEGORIES = listOf(
        Category("mobil_vinc", "Mobil Vinç", "ic_crane", "Yüksek tonajlı kaldırma ve taşıma"),
        Category("ekskavator", "Ekskavatör", "ic_excavator", "Ağır hafriyat ve kazı işleri"),
        Category("jcb", "JCB & Kazıcı Yükleyici", "ic_loader_backhoe", "Kanal, kazı ve yükleme işleri"),
        Category("forklift", "Forklift", "ic_forklift", "Depo ve şantiye yük istifleme"),
        Category("sepetli_platform", "Sepetli Platform", "ic_platform", "Dış cephe ve yüksek alan çalışmaları"),
        Category("manitou", "Manitou & Telehandler", "ic_telehandler", "Teleskobik yükleyici ve istifleme"),
        Category("loder", "Loder", "ic_wheel_loader", "Toprak, kum ve moloz yükleme"),
        Category("dozer", "Dozer", "ic_dozer", "Arazi düzleme ve yol açma"),
        Category("silindir", "Silindir", "ic_roller", "Toprak ve asfalt sıkıştırma"),
        Category("cekici", "Çekici & Kurtarıcı", "ic_tow", "Araç ve makine transferi"),
        Category("lowbed", "Lowbed Taşıma", "ic_lowbed", "Ağır iş makinesi şehirler arası nakliye"),
        Category("diger", "Diğer İnşaat & Ekipman", "ic_other", "Diğer özel inşaat araç ve hizmetleri")
    )
}
