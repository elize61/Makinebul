package com.example.data.model

data class Report(
    val reportId: String = "",
    val reportedBy: String = "",
    val reportedByName: String = "",
    val targetId: String = "",
    val targetType: String = "", // "USER", "MACHINE", "MESSAGE", "PROVIDER"
    val reason: String = "",
    val description: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val status: String = "PENDING" // "PENDING", "RESOLVED", "DISMISSED"
)
