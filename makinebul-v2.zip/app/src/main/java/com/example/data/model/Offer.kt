package com.example.data.model

enum class OfferStatus(val labelTr: String) {
    BEKLENIYOR("Bekliyor"),
    KABUL_EDILDI("Kabul Edildi"),
    REDDEDILDI("Reddedildi"),
    TAMAMLANDI("Tamamlandı"),
    IPTAL_EDILDI("İptal Edildi")
}

data class Offer(
    val id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val customerCompany: String = "Şantiye & Proje Sahibi",
    val customerRating: Double = 0.0,
    val customerCompletedJobs: Int = 0,
    val customerCity: String = "",
    val customerDistrict: String = "",
    val ownerId: String = "",
    val machineId: String = "",
    val machineTitle: String = "",
    val machineCategory: String = "",
    val startDate: String = "",
    val endDate: String = "",
    val workingHours: Int = 8,
    val location: String = "",
    val description: String = "",
    val offeredPrice: Double = 0.0,
    val status: OfferStatus = OfferStatus.BEKLENIYOR,
    val createdAt: Long = System.currentTimeMillis()
)
