package com.example.ui.screens.machine

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import com.example.util.GeocodeUtils
import com.example.util.ImageUtils
import kotlinx.coroutines.launch
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Machine
import com.example.data.model.MachineCategories
import com.example.data.model.User
import com.example.ui.components.AvailabilityCalendar
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusError

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditMachineScreen(
    editingMachine: Machine? = null,
    currentUser: User?,
    onNavigateBack: () -> Unit,
    onSaveMachine: (Machine) -> Unit
) {
    var title by remember { mutableStateOf(editingMachine?.title ?: "") }
    var selectedCategory by remember { mutableStateOf(editingMachine?.category ?: "Mobil Vinç") }
    var brand by remember { mutableStateOf(editingMachine?.brand ?: "") }
    var model by remember { mutableStateOf(editingMachine?.model ?: "") }
    var year by remember { mutableStateOf(editingMachine?.year?.toString() ?: "2023") }
    var description by remember { mutableStateOf(editingMachine?.description ?: "") }
    var hourlyPrice by remember { mutableStateOf(editingMachine?.hourlyPrice?.toString() ?: "") }
    var dailyPrice by remember { mutableStateOf(editingMachine?.dailyPrice?.toString() ?: "") }
    var minWorkingHours by remember { mutableStateOf(editingMachine?.minWorkingHours?.toString() ?: "2") }
    var city by remember { mutableStateOf(editingMachine?.city ?: currentUser?.city ?: "İstanbul") }
    var district by remember { mutableStateOf(editingMachine?.district ?: currentUser?.district ?: "Ümraniye") }
    var address by remember { mutableStateOf(editingMachine?.address ?: "") }
    var phone by remember { mutableStateOf(editingMachine?.ownerPhone ?: currentUser?.phone ?: "") }
    var hasOperator by remember { mutableStateOf(editingMachine?.hasOperator ?: true) }
    var fuelIncluded by remember { mutableStateOf(editingMachine?.fuelIncluded ?: false) }
    var isLowbedTransport by remember { mutableStateOf(editingMachine?.isLowbedTransport ?: false) }
    val blockedDates = remember { mutableStateListOf<String>().apply { addAll(editingMachine?.blockedDates ?: emptyList()) } }

    // Fotoğraflar: kayıtlı https adresleri veya galeriden seçilen yeni content:// adresleri (en fazla 3)
    var photos by remember { mutableStateOf((editingMachine?.photos ?: emptyList()).take(MAX_PHOTOS)) }
    var categoryMenuOpen by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(MAX_PHOTOS)
    ) { uris ->
        val room = MAX_PHOTOS - photos.size
        if (uris.isNotEmpty()) {
            if (uris.size > room) {
                Toast.makeText(context, "En fazla $MAX_PHOTOS fotoğraf eklenebilir.", Toast.LENGTH_SHORT).show()
            }
            photos = photos + uris.take(room.coerceAtLeast(0)).map { it.toString() }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (editingMachine != null) "İlanı Düzenle" else "Yeni Makine İlanı Ekle",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Geri", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (errorMessage != null) {
                Surface(
                    color = StatusError.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = errorMessage!!,
                        color = StatusError,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Photos Card (en fazla 3 fotoğraf)
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Makine Fotoğrafları (${photos.size}/$MAX_PHOTOS)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(photos) { url ->
                            Box(modifier = Modifier.size(90.dp)) {
                                AsyncImage(
                                    model = url,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(RoundedCornerShape(8.dp))
                                )
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .padding(3.dp)
                                        .size(22.dp)
                                        .clip(RoundedCornerShape(11.dp))
                                        .background(Color.Black.copy(alpha = 0.6f))
                                        .clickable { photos = photos.filter { it != url } },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Filled.Close, contentDescription = "Fotoğrafı kaldır", tint = Color.White, modifier = Modifier.size(14.dp))
                                }
                            }
                        }

                        if (photos.size < MAX_PHOTOS) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .size(90.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(NavyLight)
                                        .clickable {
                                            photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Filled.AddPhotoAlternate, contentDescription = null, tint = BlueAccent)
                                        Text("Foto Ekle", color = BlueAccent, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Kategori seçimi: sade açılır liste
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Kategori *", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { categoryMenuOpen = true },
                            modifier = Modifier.fillMaxWidth().testTag("category_dropdown"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                selectedCategory,
                                modifier = Modifier.weight(1f),
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.SemiBold
                            )
                            Icon(Icons.Filled.KeyboardArrowDown, contentDescription = null)
                        }
                        DropdownMenu(
                            expanded = categoryMenuOpen,
                            onDismissRequest = { categoryMenuOpen = false }
                        ) {
                            MachineCategories.ALL.filter { it != "Tümü" }.forEach { cat ->
                                DropdownMenuItem(
                                    text = { Text(cat, fontWeight = if (cat == selectedCategory) FontWeight.Bold else FontWeight.Normal) },
                                    onClick = {
                                        selectedCategory = cat
                                        if (cat == "Lowbed Taşıma") isLowbedTransport = true
                                        categoryMenuOpen = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Specs Form Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Makine Bilgileri", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Makine İlan Başlığı (Örn: Liebherr 100 Ton Vinç)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("add_title_input")
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = brand,
                            onValueChange = { brand = it },
                            label = { Text("Marka (Örn: Liebherr)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = model,
                            onValueChange = { model = it },
                            label = { Text("Model") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = year,
                        onValueChange = { year = it },
                        label = { Text("Model Yılı") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Açıklama & Özellikler") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Pricing & Features Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Fiyatlandırma & Hizmet Koşulları", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = hourlyPrice,
                            onValueChange = { hourlyPrice = it },
                            label = { Text("Saatlik Ücret (₺)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("add_hourly_input")
                        )

                        OutlinedTextField(
                            value = dailyPrice,
                            onValueChange = { dailyPrice = it },
                            label = { Text("Günlük Ücret (₺)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("add_daily_input")
                        )
                    }

                    OutlinedTextField(
                        value = minWorkingHours,
                        onValueChange = { minWorkingHours = it },
                        label = { Text("Minimum Çalışma Süresi (Saat)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Feature Toggles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = hasOperator, onCheckedChange = { hasOperator = it })
                        Text(text = "Operatörlü Hizmet Sağlanıyor", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = fuelIncluded, onCheckedChange = { fuelIncluded = it })
                        Text(text = "Yakıt Fiyata Dahil", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = isLowbedTransport, onCheckedChange = { isLowbedTransport = it })
                        Text(text = "Lowbed Ağır Nakliye Aracı / Hizmeti", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }

            // Availability Calendar Block Tool for Owner
            AvailabilityCalendar(
                blockedDates = blockedDates,
                dailyPrice = dailyPrice.toDoubleOrNull() ?: 0.0,
                hourlyPrice = hourlyPrice.toDoubleOrNull() ?: 0.0,
                isOwnerMode = true,
                onToggleBlockDate = { dateStr ->
                    if (blockedDates.contains(dateStr)) {
                        blockedDates.remove(dateStr)
                    } else {
                        blockedDates.add(dateStr)
                    }
                }
            )

            // Location Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Konum & İletişim Bilgileri", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = city,
                            onValueChange = { city = it },
                            label = { Text("İl") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = district,
                            onValueChange = { district = it },
                            label = { Text("İlçe") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("Açık Adres / Garaj Adresi") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("İletişim Telefonu") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            if (editingMachine == null) {
                Text(
                    "ℹ️ Yeni ilanınız yönetici onayından sonra müşterilere görünür.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = {
                    if (isSaving) return@Button
                    if (title.isBlank() || hourlyPrice.isBlank() || dailyPrice.isBlank() || city.isBlank()) {
                        errorMessage = "Lütfen başlık, fiyatlandırma ve konum bilgilerini eksiksiz giriniz."
                        return@Button
                    }
                    if (photos.size > MAX_PHOTOS) {
                        photos = photos.take(MAX_PHOTOS)
                    }
                    errorMessage = null
                    isSaving = true
                    scope.launch {
                        val machineId = editingMachine?.id ?: "mach_${System.currentTimeMillis()}"
                        val ownerId = currentUser?.id ?: ""

                        // 1) Yeni seçilen fotoğrafları küçültüp Storage'a yükle
                        val finalPhotos = mutableListOf<String>()
                        var uploadError: String? = null
                        photos.take(MAX_PHOTOS).forEachIndexed { index, item ->
                            if (uploadError != null) return@forEachIndexed
                            if (item.startsWith("http")) {
                                finalPhotos.add(item)
                            } else {
                                val local = ImageUtils.compressToCacheJpeg(context, android.net.Uri.parse(item))
                                if (local == null) {
                                    uploadError = "Fotoğraf okunamadı. Lütfen başka bir fotoğraf deneyin."
                                } else {
                                    val res = ImageUtils.uploadToStorage(
                                        "machines/$ownerId/${machineId}_${index}_${System.currentTimeMillis()}.jpg",
                                        local
                                    )
                                    res.fold(
                                        onSuccess = { finalPhotos.add(it) },
                                        onFailure = { uploadError = it.message ?: "Fotoğraf yüklenemedi." }
                                    )
                                }
                            }
                        }
                        if (uploadError != null) {
                            errorMessage = uploadError
                            isSaving = false
                            return@launch
                        }

                        // 2) Adresi koordinata çevir (Haritada Gör bu konuma odaklanır)
                        val addressChanged = editingMachine == null ||
                            editingMachine.address != address || editingMachine.district != district || editingMachine.city != city
                        var lat = editingMachine?.latitude ?: 0.0
                        var lng = editingMachine?.longitude ?: 0.0
                        if (addressChanged || lat == 0.0) {
                            val full = listOf(address, district, city).filter { it.isNotBlank() }.joinToString(", ")
                            val geo = GeocodeUtils.geocode(full)
                                ?: GeocodeUtils.geocode(listOf(district, city).filter { it.isNotBlank() }.joinToString(", "))
                            if (geo != null) {
                                lat = geo.latitude
                                lng = geo.longitude
                            } else if (lat == 0.0) {
                                lat = 41.0082
                                lng = 28.9784
                            }
                        }

                        val machineObj = (editingMachine ?: Machine()).copy(
                            id = machineId,
                            ownerId = ownerId,
                            ownerName = currentUser?.fullName ?: "",
                            ownerPhone = phone,
                            title = title,
                            category = selectedCategory,
                            brand = brand,
                            model = model,
                            year = year.toIntOrNull() ?: 2022,
                            description = description,
                            hourlyPrice = hourlyPrice.toDoubleOrNull() ?: 0.0,
                            dailyPrice = dailyPrice.toDoubleOrNull() ?: 0.0,
                            minWorkingHours = minWorkingHours.toIntOrNull() ?: 2,
                            city = city,
                            district = district,
                            address = address,
                            latitude = lat,
                            longitude = lng,
                            hasOperator = hasOperator,
                            fuelIncluded = fuelIncluded,
                            isLowbedTransport = isLowbedTransport,
                            blockedDates = blockedDates.toList(),
                            photos = finalPhotos
                        )

                        isSaving = false
                        onSaveMachine(machineObj)
                    }
                },
                enabled = !isSaving,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_machine_btn"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
            ) {
                if (isSaving) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Kaydediliyor...", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                } else {
                    Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        if (editingMachine == null) "İlanı Onaya Gönder" else "Değişiklikleri Kaydet",
                        fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White
                    )
                }
            }
        }
    }
}

private const val MAX_PHOTOS = 3
