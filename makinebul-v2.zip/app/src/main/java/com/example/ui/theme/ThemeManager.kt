package com.example.ui.theme

import android.content.Context
import androidx.compose.ui.graphics.Color

enum class AppTheme(val label: String, val desc: String) {
    DARK("Koyu Tema", "Modern, güçlü ve profesyonel (varsayılan)"),
    LIGHT("Açık Tema", "Temiz ve sade kullanım"),
    BLUE("Mavi Tema", "Daha sakin ve modern"),
    GREEN("Yeşil Tema", "Doğaya ve güvene yakın"),
    PURPLE("Mor Tema", "Farklı ve dikkat çekici")
}

class Palette(
    val bg: Color,        // sayfa arka planı / koyu yüzey
    val surface: Color,   // kart yüzeyi
    val accent: Color,    // ana vurgu
    val accentLight: Color
)

object ThemeManager {
    private const val PREFS = "makinebul_theme"
    private const val KEY = "theme"

    @Volatile
    var current: AppTheme = AppTheme.DARK
        private set

    fun init(context: Context) {
        val name = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
        current = AppTheme.values().firstOrNull { it.name == name } ?: AppTheme.DARK
    }

    fun set(context: Context, theme: AppTheme) {
        current = theme
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, theme.name).apply()
    }

    val isLight: Boolean get() = current == AppTheme.LIGHT

    fun paletteOf(theme: AppTheme): Palette = when (theme) {
        AppTheme.DARK -> Palette(Color(0xFF0E1621), Color(0xFF182231), Color(0xFFF97316), Color(0xFFFB923C))
        AppTheme.LIGHT -> Palette(Color(0xFF0E1621), Color(0xFF182231), Color(0xFFF97316), Color(0xFFFB923C))
        AppTheme.BLUE -> Palette(Color(0xFF0A2540), Color(0xFF123A63), Color(0xFF2F80ED), Color(0xFF56CCF2))
        AppTheme.GREEN -> Palette(Color(0xFF0B2A22), Color(0xFF124037), Color(0xFF10B981), Color(0xFF34D399))
        AppTheme.PURPLE -> Palette(Color(0xFF1A1236), Color(0xFF2A1E55), Color(0xFF8B5CF6), Color(0xFFA78BFA))
    }

    val palette: Palette get() = paletteOf(current)

    /** Tema seçim önizlemesi için nokta rengi */
    fun swatch(theme: AppTheme): Color = when (theme) {
        AppTheme.DARK -> Color(0xFF0E1621)
        AppTheme.LIGHT -> Color(0xFFF8FAFC)
        AppTheme.BLUE -> Color(0xFF2F80ED)
        AppTheme.GREEN -> Color(0xFF10B981)
        AppTheme.PURPLE -> Color(0xFF8B5CF6)
    }
}
