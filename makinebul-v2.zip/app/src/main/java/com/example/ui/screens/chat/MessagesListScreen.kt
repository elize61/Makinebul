package com.example.ui.screens.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Conversation
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusError
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessagesListScreen(
    conversations: List<Conversation>,
    onSelectConversation: (Conversation) -> Unit,
    onDeleteConversation: (String) -> Unit = {},
    onDeleteConversations: (List<String>) -> Unit = {},
    onDeleteAllConversations: () -> Unit = {}
) {
    var isSelectionMode by remember { mutableStateOf(false) }
    var selectedConvIds by remember { mutableStateOf(setOf<String>()) }
    var showDeleteAllDialog by remember { mutableStateOf(false) }
    var showDeleteSelectedDialog by remember { mutableStateOf(false) }
    var convToDeleteIndividually by remember { mutableStateOf<Conversation?>(null) }

    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    // Dialog for single conversation delete
    convToDeleteIndividually?.let { conv ->
        AlertDialog(
            onDismissRequest = { convToDeleteIndividually = null },
            title = { Text("Konuşmayı Sil", fontWeight = FontWeight.Bold) },
            text = { Text("\"${conv.participantName}\" ile olan tüm mesajlaşma geçmişini silmek istediğinize emin misiniz?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteConversation(conv.id)
                        convToDeleteIndividually = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) {
                    Text("Sil", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { convToDeleteIndividually = null }) {
                    Text("Vazgeç")
                }
            }
        )
    }

    // Dialog for delete all conversations
    if (showDeleteAllDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAllDialog = false },
            title = { Text("Tüm Mesajları Sil", fontWeight = FontWeight.Bold) },
            text = { Text("Mevcut tüm konuşmaları (${conversations.size} adet) ve mesaj geçmişini silmek istediğinize emin misiniz? Bu işlem geri alınamaz.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteAllConversations()
                        showDeleteAllDialog = false
                        isSelectionMode = false
                        selectedConvIds = emptySet()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) {
                    Text("Tümünü Sil", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllDialog = false }) {
                    Text("Vazgeç")
                }
            }
        )
    }

    // Dialog for delete selected conversations
    if (showDeleteSelectedDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteSelectedDialog = false },
            title = { Text("Seçilenleri Sil", fontWeight = FontWeight.Bold) },
            text = { Text("Seçilen ${selectedConvIds.size} adet konuşmayı silmek istediğinize emin misiniz?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteConversations(selectedConvIds.toList())
                        selectedConvIds = emptySet()
                        isSelectionMode = false
                        showDeleteSelectedDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) {
                    Text("Sil (${selectedConvIds.size})", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteSelectedDialog = false }) {
                    Text("Vazgeç")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (isSelectionMode) {
                        Text(
                            text = "${selectedConvIds.size} / ${conversations.size} Seçildi",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                    } else {
                        Text("Mesajlar", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                navigationIcon = {
                    if (isSelectionMode) {
                        IconButton(onClick = {
                            isSelectionMode = false
                            selectedConvIds = emptySet()
                        }) {
                            Icon(Icons.Filled.Close, contentDescription = "Kapat", tint = Color.White)
                        }
                    }
                },
                actions = {
                    if (isSelectionMode) {
                        TextButton(onClick = {
                            selectedConvIds = if (selectedConvIds.size == conversations.size) {
                                emptySet()
                            } else {
                                conversations.map { it.id }.toSet()
                            }
                        }) {
                            Text(
                                text = if (selectedConvIds.size == conversations.size) "Bırak" else "Tümü",
                                color = BlueAccent,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (selectedConvIds.isNotEmpty()) {
                            IconButton(onClick = { showDeleteSelectedDialog = true }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Seçilenleri Sil", tint = StatusError)
                            }
                        }
                    } else if (conversations.isNotEmpty()) {
                        IconButton(onClick = { isSelectionMode = true }) {
                            Icon(Icons.Filled.Checklist, contentDescription = "Toplu Seç", tint = Color.White)
                        }
                        IconButton(onClick = { showDeleteAllDialog = true }) {
                            Icon(Icons.Filled.DeleteSweep, contentDescription = "Tümünü Sil", tint = Color(0xFFFF7B7B))
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        if (conversations.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Filled.Chat, contentDescription = null, tint = TextMuted, modifier = Modifier.size(56.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text("Henüz bir mesajlaşmanız bulunmuyor.", color = TextSecondary, fontSize = 15.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(conversations) { conv ->
                    val isSelected = conv.id in selectedConvIds
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (isSelectionMode) {
                                    selectedConvIds = if (isSelected) selectedConvIds - conv.id else selectedConvIds + conv.id
                                } else {
                                    onSelectConversation(conv)
                                }
                            }
                            .testTag("conv_card_${conv.id}"),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) BluePrimary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                        ),
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, BluePrimary) else null
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isSelectionMode) {
                                Checkbox(
                                    checked = isSelected,
                                    onCheckedChange = {
                                        selectedConvIds = if (isSelected) selectedConvIds - conv.id else selectedConvIds + conv.id
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = BluePrimary)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                            }

                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(NavyDark, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = conv.participantName.take(1).uppercase(),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = conv.participantName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    val formattedTime = if (conv.lastTimestamp > 0) timeFormat.format(Date(conv.lastTimestamp)) else ""
                                    Text(formattedTime, fontSize = 11.sp, color = TextMuted)
                                }

                                if (conv.machineTitle.isNotBlank()) {
                                    Text(
                                        text = conv.machineTitle,
                                        fontSize = 12.sp,
                                        color = BluePrimary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                Text(
                                    text = conv.lastMessage.ifBlank { "Mesaj içeriği..." },
                                    fontSize = 13.sp,
                                    color = TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            if (!isSelectionMode) {
                                Spacer(modifier = Modifier.width(6.dp))
                                IconButton(
                                    onClick = { convToDeleteIndividually = conv },
                                    modifier = Modifier.size(34.dp).testTag("btn_delete_conv_${conv.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.DeleteOutline,
                                        contentDescription = "Konuşmayı Sil",
                                        tint = StatusError.copy(alpha = 0.8f),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
