package com.example.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Report
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Machine
import com.example.data.model.Report
import com.example.data.model.ServiceProviderApplication
import com.example.data.model.User
import com.example.data.model.UserType
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusWarning

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    currentUser: User?,
    usersList: List<User>,
    machinesList: List<Machine>,
    applicationsList: List<ServiceProviderApplication>,
    reportsList: List<Report>,
    onBackClick: () -> Unit,
    onToggleUserActive: (userId: String, active: Boolean) -> Unit,
    onDeleteMachine: (machineId: String) -> Unit,
    onProcessApplication: (appId: String, approve: Boolean, userId: String, role: String) -> Unit,
    onResolveReport: (reportId: String) -> Unit,
    onSendNotification: (title: String, body: String) -> Unit
) {
    var selectedTabIndex by remember { mutableStateOf(0) }
    val tabs = listOf("İstatistikler", "Kullanıcılar", "İlanlar", "Başvurular", "Şikayetler", "Bildirim")

    var showNotifDialog by remember { mutableStateOf(false) }
    var notifTitle by remember { mutableStateOf("") }
    var notifBody by remember { mutableStateOf("") }

    if (showNotifDialog) {
        AlertDialog(
            onDismissRequest = { showNotifDialog = false },
            title = { Text("Toplu Bildirim Gönder") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Tüm platform kullanıcılarına duyuru bildirimi gönderin:")
                    OutlinedTextField(
                        value = notifTitle,
                        onValueChange = { notifTitle = it },
                        label = { Text("Başlık") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = notifBody,
                        onValueChange = { notifBody = it },
                        label = { Text("Mesaj İçeriği") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (notifTitle.isNotBlank()) {
                            onSendNotification(notifTitle, notifBody)
                            showNotifDialog = false
                            notifTitle = ""
                            notifBody = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                ) {
                    Text("Gönder", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showNotifDialog = false }) {
                    Text("İptal")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, tint = StatusWarning)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("MakineBul Yönetim Paneli", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("Sistem Yönetimi & Moderasyon", color = BlueAccent, fontSize = 11.sp)
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Geri", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Tab Row
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = NavyDark,
                contentColor = Color.White,
                edgePadding = 12.dp
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == index) BlueAccent else Color.LightGray,
                                fontSize = 13.sp
                            )
                        }
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (selectedTabIndex) {
                    0 -> {
                        // DASHBOARD STATS
                        Text("Sistem İstatistikleri Overview", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            StatCard("Toplam Kullanıcı", "${usersList.size}", "👥", Modifier.weight(1f))
                            StatCard("Aktif İlanlar", "${machinesList.size}", "🚜", Modifier.weight(1f))
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            StatCard("Bekleyen Başvuru", "${applicationsList.count { it.status == "PENDING" }}", "📝", Modifier.weight(1f))
                            StatCard("Açık Şikayetler", "${reportsList.count { it.status == "PENDING" }}", "⚠️", Modifier.weight(1f))
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { showNotifDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("btn_broadcast_notification"),
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Filled.Notifications, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Toplu Duyuru / Push Bildirimi Gönder", fontWeight = FontWeight.Bold)
                        }
                    }

                    1 -> {
                        // USERS MANAGEMENT
                        Text("Kullanıcı Yönetimi (${usersList.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        usersList.forEach { user ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(12.dp),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(user.fullName.ifEmpty { "Kullanıcı" }, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                        Text("${user.email} • ${user.phone}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            modifier = Modifier.padding(top = 4.dp)
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = BluePrimary.copy(alpha = 0.15f)
                                            ) {
                                                Text(
                                                    user.userType.labelTr,
                                                    fontSize = 11.sp,
                                                    color = BluePrimary,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = if (user.isActive) StatusAvailable.copy(alpha = 0.15f) else StatusError.copy(alpha = 0.15f)
                                            ) {
                                                Text(
                                                    if (user.isActive) "Aktif" else "Pasif",
                                                    fontSize = 11.sp,
                                                    color = if (user.isActive) StatusAvailable else StatusError,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                    }

                                    OutlinedButton(
                                        onClick = { onToggleUserActive(user.id, !user.isActive) },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            contentColor = if (user.isActive) StatusError else StatusAvailable
                                        )
                                    ) {
                                        Text(if (user.isActive) "Pasifleştir" else "Aktifleştir", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        // MACHINE LISTINGS MANAGEMENT
                        Text("Makine İlanı Moderasyonu (${machinesList.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        machinesList.forEach { machine ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(12.dp),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(machine.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                        Text("${machine.brand} ${machine.model} • ${machine.city}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${machine.dailyPrice.toInt()} TL / gün", fontSize = 13.sp, color = BluePrimary, fontWeight = FontWeight.Bold)
                                    }

                                    IconButton(
                                        onClick = { onDeleteMachine(machine.id) }
                                    ) {
                                        Icon(Icons.Filled.Delete, contentDescription = "İlanı Sil", tint = StatusError)
                                    }
                                }
                            }
                        }
                    }

                    3 -> {
                        // SERVICE PROVIDER APPLICATIONS
                        Text("Hizmet Sağlayıcı Başvuruları (${applicationsList.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        if (applicationsList.isEmpty()) {
                            Text("Bekleyen başvuru bulunmuyor.", color = Color.Gray)
                        } else {
                            applicationsList.forEach { app ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(12.dp),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(app.userName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = StatusWarning.copy(alpha = 0.2f)
                                            ) {
                                                Text(app.requestedRole, fontSize = 11.sp, color = StatusWarning, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                            }
                                        }
                                        Text("Firma: ${app.companyName.ifEmpty { "-" }} • Vergi No: ${app.taxNumber.ifEmpty { "-" }}", fontSize = 12.sp)
                                        Text("Konum: ${app.district}, ${app.city} • İletişim: ${app.userPhone}", fontSize = 12.sp)

                                        if (app.status == "PENDING") {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Button(
                                                    onClick = { onProcessApplication(app.id, true, app.userId, app.requestedRole) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable),
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("ONAYLA", fontSize = 11.sp)
                                                }
                                                OutlinedButton(
                                                    onClick = { onProcessApplication(app.id, false, app.userId, app.requestedRole) },
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(8.dp),
                                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusError)
                                                ) {
                                                    Icon(Icons.Filled.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("REDDET", fontSize = 11.sp)
                                                }
                                            }
                                        } else {
                                            Text("Durum: ${app.status}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    4 -> {
                        // REPORTS & COMPLAINTS
                        Text("Şikayet & Bildirim Yönetimi (${reportsList.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        if (reportsList.isEmpty()) {
                            Text("İncelenecek şikayet bulunmamaktadır.", color = Color.Gray)
                        } else {
                            reportsList.forEach { rep ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Text("Nedeni: ${rep.reason}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(rep.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("Şikayet Eden: ${rep.reportedByName}", fontSize = 11.sp, color = Color.Gray)

                                        if (rep.status == "PENDING") {
                                            Button(
                                                onClick = { onResolveReport(rep.reportId) },
                                                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                                                modifier = Modifier.align(Alignment.End),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text("Çözüldü Olarak İşaretle", fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    5 -> {
                        // PUSH BROADCAST
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = NavyDark),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text("📢 Toplu Bildirim / Duyuru Sistemi", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("Tüm MakineBul kullanıcılarına anlık mobil uygulama duyurusu gönderin.", color = Color.LightGray, fontSize = 12.sp)

                                Button(
                                    onClick = { showNotifDialog = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusWarning),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text("Duyuru Mesajı Oluştur", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, iconEmoji: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = NavyDark),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(iconEmoji, fontSize = 20.sp)
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text(title, fontSize = 11.sp, color = Color.LightGray)
        }
    }
}
