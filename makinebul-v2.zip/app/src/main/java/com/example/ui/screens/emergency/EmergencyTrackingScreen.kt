package com.example.ui.screens.emergency

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EmergencyDriverOffer
import com.example.data.model.EmergencyRequest
import com.example.data.model.EmergencyServiceType
import com.example.data.model.EmergencyStatus
import com.example.ui.components.OsmMapView
import com.example.ui.components.OsmMarkerItem
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusWarning
import com.example.util.LocationUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmergencyTrackingScreen(
    request: EmergencyRequest?,
    onBackClick: () -> Unit,
    onCancelClick: () -> Unit,
    onStartSimulationClick: () -> Unit,
    onNavigateToChat: (driverId: String, driverName: String) -> Unit,
    onRespondToOffer: ((Boolean) -> Unit)? = null,
    onAcceptOffer: ((driverId: String) -> Unit)? = null
) {
    val context = LocalContext.current
    var showCancelDialog by remember { mutableStateOf(false) }

    var currentCustomerLat by remember(request?.id, request?.customerLat) {
        mutableDoubleStateOf(request?.customerLat ?: 41.0082)
    }
    var currentCustomerLng by remember(request?.id, request?.customerLng) {
        mutableDoubleStateOf(request?.customerLng ?: 28.9784)
    }
    var isFetchingGps by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false

        if (fineGranted || coarseGranted) {
            isFetchingGps = true
            LocationUtils.getCurrentLocation(
                context = context,
                onSuccess = { lat, lng ->
                    isFetchingGps = false
                    currentCustomerLat = lat
                    currentCustomerLng = lng
                    Toast.makeText(context, "📍 Anlık GPS Konumunuz bağlandı: %.4f, %.4f".format(lat, lng), Toast.LENGTH_LONG).show()
                },
                onError = { errorMsg ->
                    isFetchingGps = false
                    Toast.makeText(context, "⚠️ $errorMsg", Toast.LENGTH_LONG).show()
                }
            )
        } else {
            Toast.makeText(context, "⚠️ Konum izni reddedildi. GPS takibi için izin veriniz.", Toast.LENGTH_LONG).show()
        }
    }

    if (request == null) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Çağrı Bulunamadı", color = Color.White) },
                    navigationIcon = {
                        IconButton(onClick = onBackClick) {
                            Icon(Icons.Filled.ArrowBack, contentDescription = "Geri", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
                )
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(NavyDark)
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("Aktif çağrı bulunamadı.", color = Color.White)
            }
        }
        return
    }

    val isTire = request.serviceType == EmergencyServiceType.TIRE_SERVICE

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (isTire) "🛞 ACİL LASTİKÇİ ÇAĞRISI" else "🚛 ACİL ÇEKİCİ ÇAĞRISI",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = "Talep ID: #${request.id.takeLast(6).uppercase()} • Canlı Takip",
                            color = BlueAccent,
                            fontSize = 11.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Geri",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    if (request.status != EmergencyStatus.COMPLETED && request.status != EmergencyStatus.CANCELLED) {
                        TextButton(onClick = { showCancelDialog = true }) {
                            Text("İptal Et", color = StatusError, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(NavyDark)
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. Live Status & Radar Animation Banner (Harmonized)
                LiveTrackingStatusCard(request = request)

                // 2. Active Mission Assigned Driver Card (If accepted or mission active)
                val isAssigned = !request.assignedDriverId.isNullOrBlank() &&
                        (request.status == EmergencyStatus.ARRIVING ||
                         request.status == EmergencyStatus.ARRIVED ||
                         request.status == EmergencyStatus.IN_SERVICE ||
                         request.status == EmergencyStatus.COMPLETED ||
                         request.priceStatus == "CUSTOMER_ACCEPTED" ||
                         request.priceStatus == "ACCEPTED")

                if (isAssigned) {
                    ActiveDriverMissionCard(
                        request = request,
                        onCallDriver = { phoneNum ->
                            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNum"))
                            context.startActivity(dialIntent)
                        },
                        onChatWithDriver = { driverId, driverName ->
                            onNavigateToChat(driverId, driverName)
                        }
                    )
                }

                // 3. OpenStreetMap (OSM) Live Map View
                OsmTrackingMapCard(
                    request = request,
                    currentCustomerLat = currentCustomerLat,
                    currentCustomerLng = currentCustomerLng,
                    isFetchingGps = isFetchingGps,
                    onRefreshGps = {
                        if (LocationUtils.hasLocationPermission(context)) {
                            isFetchingGps = true
                            LocationUtils.getCurrentLocation(
                                context = context,
                                onSuccess = { lat, lng ->
                                    isFetchingGps = false
                                    currentCustomerLat = lat
                                    currentCustomerLng = lng
                                    Toast.makeText(context, "📍 GPS Koordinatları güncellendi", Toast.LENGTH_SHORT).show()
                                },
                                onError = { msg ->
                                    isFetchingGps = false
                                    Toast.makeText(context, "Hata: $msg", Toast.LENGTH_SHORT).show()
                                }
                            )
                        } else {
                            permissionLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                )
                            )
                        }
                    },
                    onOpenExternalMap = {
                        com.example.util.MapLauncher.openDirections(
                            context,
                            request.driverLat, request.driverLng,
                            currentCustomerLat, currentCustomerLng
                        )
                    }
                )

                // 4. Incoming Price Offers Section (Harmonized with Fast Emergency Screen)
                TrackingOffersSection(
                    request = request,
                    onAcceptOffer = { driverId ->
                        onAcceptOffer?.invoke(driverId) ?: onRespondToOffer?.invoke(true)
                        Toast.makeText(context, "Teklifi onayladınız! Usta yola çıkıyor.", Toast.LENGTH_SHORT).show()
                    },
                    onCallDriver = { phoneNum ->
                        val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNum"))
                        context.startActivity(dialIntent)
                    },
                    onChatDriver = { driverId, driverName ->
                        onNavigateToChat(driverId, driverName)
                    }
                )

                // 5. Request Details Summary Card
                TrackingSummaryCard(request = request)


                // Safety Tip Banner
                Surface(
                    color = NavyLight,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🛡️", fontSize = 20.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Güvenliğiniz için dörtlülerinizi yakın ve emniyet şeridinde veya bariyer arkasında bekleyin.",
                            color = Color.LightGray,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    // Cancel Dialog
    if (showCancelDialog) {
        AlertDialog(
            onDismissRequest = { showCancelDialog = false },
            title = {
                Text(
                    text = "Acil Çağrıyı İptal Et",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "Acil çağrınızı iptal etmek istediğinizden emin misiniz? Nöbetçi ustalara iptal bilgisi iletilecektir.",
                    color = Color.LightGray,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showCancelDialog = false
                        onCancelClick()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) {
                    Text("Evet, İptal Et", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCancelDialog = false }) {
                    Text("Vazgeç", color = Color.White)
                }
            },
            containerColor = NavyDark
        )
    }
}

/**
 * Live Status & 4-step Progress Card
 */
@Composable
private fun LiveTrackingStatusCard(request: EmergencyRequest) {
    val isSearching = request.status == EmergencyStatus.SEARCHING
    val isOffered = request.status == EmergencyStatus.OFFERED
    val isArriving = request.status == EmergencyStatus.ARRIVING
    val isArrived = request.status == EmergencyStatus.ARRIVED
    val isInService = request.status == EmergencyStatus.IN_SERVICE
    val isCompleted = request.status == EmergencyStatus.COMPLETED
    val isCancelled = request.status == EmergencyStatus.CANCELLED

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = when {
                isCompleted -> StatusAvailable.copy(alpha = 0.15f)
                isCancelled -> StatusError.copy(alpha = 0.15f)
                isArriving || isArrived -> BluePrimary.copy(alpha = 0.18f)
                else -> NavyLight
            }
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp,
            when {
                isCompleted -> StatusAvailable
                isCancelled -> StatusError
                isArriving || isArrived -> BlueAccent
                isOffered -> StatusWarning
                else -> StatusError
            }
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .scale(if (isSearching) pulseScale else 1f)
                        .clip(CircleShape)
                        .background(
                            when {
                                isCompleted -> StatusAvailable.copy(alpha = 0.25f)
                                isCancelled -> StatusError.copy(alpha = 0.25f)
                                isArriving || isArrived -> BlueAccent.copy(alpha = 0.25f)
                                isOffered -> StatusWarning.copy(alpha = 0.25f)
                                else -> StatusError.copy(alpha = 0.25f)
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = when {
                            isCompleted -> "✅"
                            isCancelled -> "❌"
                            isArriving -> "🚗"
                            isArrived -> "📍"
                            isInService -> "🔧"
                            isOffered -> "📬"
                            else -> "📡"
                        },
                        fontSize = 22.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = when {
                            isCompleted -> "HİZMET TAMAMLANDI"
                            isCancelled -> "ÇAĞRI İPTAL EDİLDİ"
                            isArrived -> "USTA KONUMUNUZA ULAŞTI"
                            isArriving -> "USTA YOLA ÇIKTI — SİZE GELİYOR"
                            isInService -> "HİZMET BAŞLATILDI"
                            isOffered -> "${request.offers.size} FİYAT TEKLİFİ GELDİ!"
                            else -> "NÖBETÇİ USTALAR ARANIYOR..."
                        },
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = when {
                            isCompleted -> "İşlem başarıyla tamamlandı. Geçmiş olsun dileriz."
                            isCancelled -> "Talebiniz iptal edildi."
                            isArrived -> "Lütfen aracınızın başında bekleyin."
                            isArriving -> "Tahmini Varış: ${request.estimatedTimeMinutes} dakika (${String.format("%.1f", request.estimatedDistanceKm)} km)"
                            isInService -> "Olay yerinde tamir / çekici yükleme yapılıyor."
                            isOffered -> "Gelen teklifleri inceleyip onaylayabilirsiniz."
                            else -> "Bölgenizdeki nöbetçi çekicilere ve mobil lastikçilere bildirim iletildi..."
                        },
                        color = Color.LightGray,
                        fontSize = 11.sp
                    )
                }
            }

            // 4-step Progress bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val step = when {
                    isCompleted -> 4
                    isInService -> 3
                    isArrived -> 3
                    isArriving -> 2
                    isOffered -> 1
                    else -> 1
                }

                listOf("1. Bildirildi", "2. Yola Çıktı", "3. Konumda", "4. Tamamlandı").forEachIndexed { index, label ->
                    val isActive = (index + 1) <= step
                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (isActive) StatusAvailable else Color.Gray.copy(alpha = 0.3f))
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = label,
                            color = if (isActive) Color.White else Color.Gray,
                            fontSize = 9.sp,
                            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}

/**
 * Active Assigned Driver Mission Card
 */
@Composable
private fun ActiveDriverMissionCard(
    request: EmergencyRequest,
    onCallDriver: (phoneNum: String) -> Unit,
    onChatWithDriver: (driverId: String, driverName: String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NavyLight),
        border = androidx.compose.foundation.BorderStroke(2.dp, StatusAvailable)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🚗", fontSize = 22.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Size Gelen Usta",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "Görevi kabul etti ve yola çıktı",
                            color = StatusAvailable,
                            fontSize = 11.sp
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = StatusAvailable.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = "YOLDA",
                        color = StatusAvailable,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Surface(
                color = NavyDark,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = request.assignedDriverName ?: "Çekici Ustası",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "Plaka: ${request.assignedDriverPlate ?: "34 ABC 100"}",
                                color = BlueAccent,
                                fontSize = 12.sp
                            )
                            if (request.agreedPrice != null) {
                                Text(
                                    text = "Anlaşılan Tutar: %.0f ₺".format(request.agreedPrice),
                                    color = StatusAvailable,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        // Call button
                        Button(
                            onClick = {
                                val phone = request.assignedDriverPhone ?: ""
                                if (phone.isNotBlank()) onCallDriver(phone)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Filled.Call, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Ustayı Ara", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Chat action
                    OutlinedButton(
                        onClick = {
                            val driverId = request.assignedDriverId ?: "driver_1"
                            val driverName = request.assignedDriverName ?: "Usta"
                            onChatWithDriver(driverId, driverName)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BlueAccent)
                    ) {
                        Icon(Icons.Filled.Chat, contentDescription = null, tint = BlueAccent, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Ustayla Mesajlaş", color = Color.White, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

/**
 * OpenStreetMap Live Tracking Card (Replaces old Canvas map)
 */
@Composable
private fun OsmTrackingMapCard(
    request: EmergencyRequest,
    currentCustomerLat: Double,
    currentCustomerLng: Double,
    isFetchingGps: Boolean,
    onRefreshGps: () -> Unit,
    onOpenExternalMap: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NavyLight)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.LocationOn, contentDescription = null, tint = StatusError, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Canlı Harita Konumu (OpenStreetMap)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = BluePrimary.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = "ÜCRETSİZ / OSM",
                        color = BlueAccent,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Create markers for customer and driver
            val markers = mutableListOf<OsmMarkerItem>()
            markers.add(
                OsmMarkerItem(
                    id = "customer_pin",
                    title = "Konumunuz",
                    snippet = request.customerLocationName,
                    latitude = currentCustomerLat,
                    longitude = currentCustomerLng,
                    isDemand = true
                )
            )

            if (!request.assignedDriverId.isNullOrBlank()) {
                markers.add(
                    OsmMarkerItem(
                        id = "driver_pin",
                        title = request.assignedDriverName ?: "Çekici",
                        snippet = "Tahmini ${request.estimatedTimeMinutes} dk mesafede",
                        latitude = request.driverLat,
                        longitude = request.driverLng,
                        isDemand = false
                    )
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
                    .clip(RoundedCornerShape(12.dp))
            ) {
                OsmMapView(
                    modifier = Modifier.fillMaxSize(),
                    markers = markers,
                    centerLatitude = currentCustomerLat,
                    centerLongitude = currentCustomerLng,
                    zoomLevel = 13.5,
                    userLatitude = currentCustomerLat,
                    userLongitude = currentCustomerLng,
                    showZoomControls = false
                )
            }

            // Map action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onRefreshGps,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable)
                ) {
                    if (isFetchingGps) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Filled.GpsFixed, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("GPS Yenile", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }

                OutlinedButton(
                    onClick = onOpenExternalMap,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BlueAccent)
                ) {
                    Icon(Icons.Filled.Map, contentDescription = null, tint = BlueAccent, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Haritada Aç", fontSize = 12.sp, color = Color.White)
                }
            }
        }
    }
}

/**
 * Incoming Price Offers Section for Logged-in Users (Harmonized)
 */
@Composable
private fun TrackingOffersSection(
    request: EmergencyRequest,
    onAcceptOffer: (driverId: String) -> Unit,
    onCallDriver: (phoneNum: String) -> Unit,
    onChatDriver: (driverId: String, driverName: String) -> Unit
) {
    val allOffers = request.offers.ifEmpty {
        if (request.agreedPrice != null && request.assignedDriverName != null) {
            listOf(
                EmergencyDriverOffer(
                    id = "default_offer",
                    driverId = request.assignedDriverId ?: "driver_1",
                    driverName = request.assignedDriverName ?: "Çekici Ustası",
                    driverPhone = request.assignedDriverPhone ?: "+90 532 111 22 33",
                    driverPlate = request.assignedDriverPlate ?: "34 ABC 123",
                    price = request.agreedPrice ?: 0.0,
                    isAcceptedByCustomer = request.priceStatus == "CUSTOMER_ACCEPTED" || request.priceStatus == "ACCEPTED"
                )
            )
        } else emptyList()
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NavyLight)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🏷️", fontSize = 20.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Gelen Fiyat Teklifleri",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (allOffers.isNotEmpty()) StatusAvailable.copy(alpha = 0.2f) else Color.Gray.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = "${allOffers.size} Teklif",
                        color = if (allOffers.isNotEmpty()) StatusAvailable else Color.LightGray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            if (allOffers.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(32.dp),
                        color = BlueAccent,
                        strokeWidth = 3.dp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Yakındaki nöbetçi ustalar teklif hazırlıyor...",
                        color = Color.White,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Teklifler geldiğinde anında bu listede belirecektir.",
                        color = Color.LightGray,
                        fontSize = 11.sp
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    allOffers.forEach { offer ->
                        val isThisOfferAccepted = offer.isAcceptedByCustomer ||
                                (request.assignedDriverId == offer.driverId && (request.priceStatus == "CUSTOMER_ACCEPTED" || request.priceStatus == "ACCEPTED"))

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isThisOfferAccepted) StatusAvailable.copy(alpha = 0.15f) else NavyDark
                            ),
                            border = androidx.compose.foundation.BorderStroke(
                                1.5.dp,
                                if (isThisOfferAccepted) StatusAvailable else BluePrimary.copy(alpha = 0.4f)
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = offer.driverName,
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = StatusAvailable.copy(alpha = 0.2f)
                                            ) {
                                                Text(
                                                    text = "NÖBETÇİ",
                                                    color = StatusAvailable,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Filled.Star, contentDescription = null, tint = StatusWarning, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text(
                                                text = "${offer.rating} (${offer.completedJobs} görev)",
                                                color = Color.LightGray,
                                                fontSize = 11.sp
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("•", color = Color.Gray, fontSize = 11.sp)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "Plaka: ${offer.driverPlate.ifBlank { "34 ABC 100" }}",
                                                color = BlueAccent,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "⏱️ Tahmini Varış: ${offer.estimatedMinutes} dakika",
                                            color = Color.LightGray,
                                            fontSize = 11.sp
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "%.0f ₺".format(offer.price),
                                            color = StatusAvailable,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 20.sp
                                        )
                                        Text("Sabit Fiyat", color = Color.Gray, fontSize = 10.sp)
                                    }
                                }

                                if (offer.note.isNotBlank()) {
                                    Surface(
                                        color = NavyLight.copy(alpha = 0.6f),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "💬 \"${offer.note}\"",
                                            color = Color.LightGray,
                                            fontSize = 11.sp,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                        )
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Call button
                                    OutlinedButton(
                                        onClick = {
                                            val phone = offer.driverPhone.ifBlank { "+90 532 111 22 33" }
                                            onCallDriver(phone)
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, BlueAccent)
                                    ) {
                                        Icon(Icons.Filled.Call, contentDescription = null, tint = BlueAccent, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Ara", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }

                                    // Chat button
                                    OutlinedButton(
                                        onClick = {
                                            onChatDriver(offer.driverId, offer.driverName)
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, BluePrimary)
                                    ) {
                                        Icon(Icons.Filled.Chat, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Mesaj", color = Color.White, fontSize = 12.sp)
                                    }

                                    // Accept button
                                    if (isThisOfferAccepted) {
                                        Button(
                                            onClick = {},
                                            enabled = false,
                                            modifier = Modifier.weight(1.3f),
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable)
                                        ) {
                                            Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Kabul Edildi", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    } else {
                                        Button(
                                            onClick = { onAcceptOffer(offer.driverId) },
                                            modifier = Modifier
                                                .weight(1.3f)
                                                .testTag("btn_accept_offer_${offer.driverId}"),
                                            shape = RoundedCornerShape(10.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable)
                                        ) {
                                            Text("Kabul Et", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Request Summary Details Card
 */
@Composable
private fun TrackingSummaryCard(request: EmergencyRequest) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NavyLight)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "📋 Çağrı Özeti",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )

            Row(modifier = Modifier.fillMaxWidth()) {
                Text("Hizmet Türü:", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.width(110.dp))
                Text(request.serviceType.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Row(modifier = Modifier.fillMaxWidth()) {
                Text("İletişim No:", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.width(110.dp))
                Text(request.customerPhone, color = StatusAvailable, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Row(modifier = Modifier.fillMaxWidth()) {
                Text("Konum:", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.width(110.dp))
                Text(request.customerLocationName, color = Color.White, fontSize = 12.sp)
            }

            if (request.destinationLocationName.isNotBlank() && request.serviceType == EmergencyServiceType.TOW_TRUCK) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text("Hedef / Sanayi:", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.width(110.dp))
                    Text(request.destinationLocationName, color = Color.White, fontSize = 12.sp)
                }
            }

            Row(modifier = Modifier.fillMaxWidth()) {
                Text("Araç & Arıza:", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.width(110.dp))
                Text("${request.vehicleType} • ${request.problemType}", color = Color.White, fontSize = 12.sp)
            }
        }
    }
}
