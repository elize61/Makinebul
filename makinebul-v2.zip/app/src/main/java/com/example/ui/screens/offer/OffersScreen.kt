package com.example.ui.screens.offer

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.activity.compose.BackHandler
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RequestQuote
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Offer
import com.example.data.model.OfferStatus
import com.example.data.model.User
import com.example.data.model.UserType
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusBusy
import com.example.ui.theme.StatusError
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OffersScreen(
    currentUser: User?,
    offers: List<Offer>,
    onUpdateOfferStatus: (String, OfferStatus) -> Unit,
    onNavigateBack: (() -> Unit)? = null,
    onNavigateToChat: ((String, String) -> Unit)? = null,
    onDeleteOffer: (String) -> Unit = {},
    onDeleteOffers: (List<String>) -> Unit = {},
    onDeleteAllOffers: () -> Unit = {}
) {
    val isOwner = currentUser?.userType == UserType.OWNER
    var isSelectionMode by remember { mutableStateOf(false) }
    var selectedOfferIds by remember { mutableStateOf(setOf<String>()) }
    var showDeleteAllDialog by remember { mutableStateOf(false) }
    var showDeleteSelectedDialog by remember { mutableStateOf(false) }
    var offerToDeleteIndividually by remember { mutableStateOf<Offer?>(null) }

    if (onNavigateBack != null) {
        BackHandler {
            if (isSelectionMode) {
                isSelectionMode = false
                selectedOfferIds = emptySet()
            } else {
                onNavigateBack()
            }
        }
    }

    // Confirmation Dialog for Single Offer Deletion
    offerToDeleteIndividually?.let { offer ->
        AlertDialog(
            onDismissRequest = { offerToDeleteIndividually = null },
            title = { Text("Teklifi Sil", fontWeight = FontWeight.Bold) },
            text = { Text("\"${offer.machineTitle}\" için teklif kaydını silmek istediğinize emin misiniz?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteOffer(offer.id)
                        offerToDeleteIndividually = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) {
                    Text("Sil", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { offerToDeleteIndividually = null }) {
                    Text("Vazgeç")
                }
            }
        )
    }

    // Confirmation Dialog for Bulk / Delete All
    if (showDeleteAllDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAllDialog = false },
            title = { Text("Tüm Teklifleri Sil", fontWeight = FontWeight.Bold) },
            text = { Text("Mevcut tüm teklifleri (${offers.size} adet) silmek istediğinize emin misiniz? Bu işlem geri alınamaz.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteAllOffers()
                        showDeleteAllDialog = false
                        isSelectionMode = false
                        selectedOfferIds = emptySet()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) {
                    Text("Tümünü Sil", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllDialog = false }) {
                    Text("Vazgeç")
                }
            }
        )
    }

    // Confirmation Dialog for Selected Offers Deletion
    if (showDeleteSelectedDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteSelectedDialog = false },
            title = { Text("Seçilenleri Sil", fontWeight = FontWeight.Bold) },
            text = { Text("Seçilen ${selectedOfferIds.size} adet teklifi silmek istediğinize emin misiniz?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteOffers(selectedOfferIds.toList())
                        selectedOfferIds = emptySet()
                        isSelectionMode = false
                        showDeleteSelectedDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) {
                    Text("Seçilenleri Sil (${selectedOfferIds.size})", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteSelectedDialog = false }) {
                    Text("Vazgeç")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (isSelectionMode) {
                        Text(
                            text = "${selectedOfferIds.size} / ${offers.size} Seçildi",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                    } else {
                        Text(
                            if (isOwner) "Gelen Fiyat Teklifleri" else "Tekliflerim",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                navigationIcon = {
                    if (isSelectionMode) {
                        IconButton(onClick = {
                            isSelectionMode = false
                            selectedOfferIds = emptySet()
                        }) {
                            Icon(Icons.Filled.Close, contentDescription = "Kapat", tint = Color.White)
                        }
                    } else if (onNavigateBack != null) {
                        IconButton(onClick = onNavigateBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Geri",
                                tint = Color.White
                            )
                        }
                    }
                },
                actions = {
                    if (isSelectionMode) {
                        TextButton(onClick = {
                            selectedOfferIds = if (selectedOfferIds.size == offers.size) {
                                emptySet()
                            } else {
                                offers.map { it.id }.toSet()
                            }
                        }) {
                            Text(
                                text = if (selectedOfferIds.size == offers.size) "Bırak" else "Tümü",
                                color = BlueAccent,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        if (selectedOfferIds.isNotEmpty()) {
                            IconButton(onClick = { showDeleteSelectedDialog = true }) {
                                Icon(Icons.Filled.Delete, contentDescription = "Seçilenleri Sil", tint = StatusError)
                            }
                        }
                    } else {
                        if (offers.isNotEmpty()) {
                            IconButton(onClick = { isSelectionMode = true }) {
                                Icon(Icons.Filled.Checklist, contentDescription = "Toplu Seç", tint = Color.White)
                            }
                            IconButton(onClick = { showDeleteAllDialog = true }) {
                                Icon(Icons.Filled.DeleteSweep, contentDescription = "Tümünü Sil", tint = Color(0xFFFF7B7B))
                            }
                        }
                        if (onNavigateBack != null) {
                            IconButton(
                                onClick = onNavigateBack,
                                modifier = Modifier.testTag("offers_profile_btn")
                            ) {
                                Icon(Icons.Filled.Person, contentDescription = "Profil", tint = Color.White)
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        if (offers.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.RequestQuote,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.padding(16.dp).size(64.dp)
                )
                Text(
                    text = if (isOwner) "Henüz hiç gelen teklif yok." else "Henüz hiç teklif vermediniz.",
                    fontSize = 16.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Medium
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(offers) { offer ->
                    val isSelected = offer.id in selectedOfferIds
                    OfferItemCard(
                        offer = offer,
                        isOwnerView = isOwner,
                        isSelected = isSelected,
                        isSelectionMode = isSelectionMode,
                        onToggleSelect = {
                            selectedOfferIds = if (isSelected) selectedOfferIds - offer.id else selectedOfferIds + offer.id
                        },
                        onDelete = { offerToDeleteIndividually = offer },
                        onAccept = { onUpdateOfferStatus(offer.id, OfferStatus.KABUL_EDILDI) },
                        onReject = { onUpdateOfferStatus(offer.id, OfferStatus.REDDEDILDI) },
                        onCancel = { onUpdateOfferStatus(offer.id, OfferStatus.IPTAL_EDILDI) },
                        onNavigateToChat = onNavigateToChat
                    )
                }
            }
        }
    }
}

@Composable
fun OfferItemCard(
    offer: Offer,
    isOwnerView: Boolean,
    isSelected: Boolean = false,
    isSelectionMode: Boolean = false,
    onToggleSelect: () -> Unit = {},
    onDelete: () -> Unit = {},
    onAccept: () -> Unit,
    onReject: () -> Unit,
    onCancel: () -> Unit,
    onNavigateToChat: ((String, String) -> Unit)? = null
) {
    val context = LocalContext.current
    val statusBg = when (offer.status) {
        OfferStatus.BEKLENIYOR -> StatusBusy
        OfferStatus.KABUL_EDILDI -> StatusAvailable
        OfferStatus.REDDEDILDI -> StatusError
        OfferStatus.TAMAMLANDI -> BluePrimary
        OfferStatus.IPTAL_EDILDI -> TextMuted
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("offer_card_${offer.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) BluePrimary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
        ),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, BluePrimary) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header: Machine Title & Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isSelectionMode) {
                    Checkbox(
                        checked = isSelected,
                        onCheckedChange = { onToggleSelect() },
                        colors = CheckboxDefaults.colors(checkedColor = BluePrimary)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = offer.machineTitle,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = offer.machineCategory,
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = statusBg,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = offer.status.labelTr,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }

                    if (!isSelectionMode) {
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = onDelete,
                            modifier = Modifier.size(34.dp).testTag("btn_delete_offer_${offer.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.DeleteOutline,
                                contentDescription = "Teklifi Sil",
                                tint = StatusError.copy(alpha = 0.85f),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // TEKLİF VEREN DETAYLARI (Machine Owner View: Full Details of the Offerer/Bidder)
            if (isOwnerView) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = NavyDark.copy(alpha = 0.05f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BluePrimary.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "👤 TEKLİF VEREN MÜŞTERİ BİLGİLERİ",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = BluePrimary
                            )

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = StatusAvailable, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(3.dp))
                                Text("Doğrulanmış Profil", fontSize = 10.sp, color = StatusAvailable, fontWeight = FontWeight.Bold)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = NavyDark,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = offer.customerName.take(1).uppercase(),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                }
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = offer.customerName,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = offer.customerCompany,
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Star, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(
                                        text = "${offer.customerRating} (${offer.customerCompletedJobs} Tamamlanan İş)",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("• ${offer.customerCity}, ${offer.customerDistrict}", fontSize = 11.sp, color = TextMuted)
                                }
                            }
                        }

                        // Offerer Contact Buttons (Call & Message)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${offer.customerPhone}"))
                                    context.startActivity(dialIntent)
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = NavyDark),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Müşteriyi Ara", fontSize = 12.sp)
                            }

                            if (true) {
                                OutlinedButton(
                                    onClick = {
                                        com.example.util.WhatsAppLauncher.open(
                                            context,
                                            offer.customerPhone,
                                            "Merhaba, MakineBul'daki \"${offer.machineTitle}\" teklifiniz hakkında yazıyorum."
                                        )
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Filled.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("WhatsApp", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Details: Dates, Hours, Location
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.CalendarToday, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Tarih: ${offer.startDate} - ${offer.endDate}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Schedule, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Çalışma: ${offer.workingHours} Saat/Gün",
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.LocationOn, contentDescription = null, tint = StatusError, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Şantiye: ${offer.location}",
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                }

                if (offer.description.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.background,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "📝 Talep Notu: ${offer.description}",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }

            // Price & Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Teklif Edilen Bedel", fontSize = 11.sp, color = TextMuted)
                    Text(
                        text = "₺${offer.offeredPrice.toInt()}",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = BluePrimary
                    )
                }

                if (offer.status == OfferStatus.BEKLENIYOR) {
                    if (isOwnerView) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = onReject,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(imageVector = Icons.Filled.Close, contentDescription = null, modifier = Modifier.size(16.dp), tint = StatusError)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Reddet", color = StatusError, fontSize = 12.sp)
                            }

                            Button(
                                onClick = onAccept,
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable)
                            ) {
                                Icon(imageVector = Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Kabul Et", color = Color.White, fontSize = 12.sp)
                            }
                        }
                    } else {
                        OutlinedButton(
                            onClick = onCancel,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Teklifi İptal Et", color = StatusError, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

