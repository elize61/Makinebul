package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import java.util.Calendar
import java.util.Locale

@Composable
fun AvailabilityCalendar(
    blockedDates: List<String>,
    dailyPrice: Double,
    hourlyPrice: Double,
    isOwnerMode: Boolean = false,
    /** Onaylanan tekliflerle otomatik dolan günler (kırmızı, seçilemez). */
    reservedDates: List<String> = emptyList(),
    /** false ise (pasif ilan) takvimden tarih seçilemez. */
    selectionEnabled: Boolean = true,
    onDateRangeSelected: (startDate: String, endDate: String, daysCount: Int, calculatedPrice: Double) -> Unit = { _, _, _, _ -> },
    onToggleBlockDate: (String) -> Unit = {}
) {
    // Current month offset: 0 = current month (Ağustos 2026), 1 = next month (Eylül 2026)
    var monthOffset by remember { mutableIntStateOf(0) }
    
    val baseCal = remember { Calendar.getInstance() }
    val displayCal = remember(monthOffset) {
        val c = Calendar.getInstance()
        c.add(Calendar.MONTH, monthOffset)
        c
    }

    val year = displayCal.get(Calendar.YEAR)
    val month = displayCal.get(Calendar.MONTH)
    val monthName = displayCal.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale("tr", "TR")) ?: "Ay"

    val daysInMonth = displayCal.getActualMaximum(Calendar.DAY_OF_MONTH)
    
    // First day of week (1 = Sunday in Java Calendar, convert to Monday = 0)
    val firstDayCal = Calendar.getInstance().apply {
        set(Calendar.YEAR, year)
        set(Calendar.MONTH, month)
        set(Calendar.DAY_OF_MONTH, 1)
    }
    val javaFirstDay = firstDayCal.get(Calendar.DAY_OF_WEEK) // 1=Sun, 2=Mon...
    val leadingEmptyDays = (javaFirstDay + 5) % 7 // Monday = 0

    val todayKey = remember {
        val t = Calendar.getInstance()
        String.format(Locale.ROOT, "%04d-%02d-%02d", t.get(Calendar.YEAR), t.get(Calendar.MONTH) + 1, t.get(Calendar.DAY_OF_MONTH))
    }
    var selectedStartDay by remember { mutableStateOf<Int?>(null) }
    var selectedEndDay by remember { mutableStateOf<Int?>(null) }

    val daysCount = remember(selectedStartDay, selectedEndDay) {
        if (selectedStartDay != null && selectedEndDay != null) {
            (selectedEndDay!! - selectedStartDay!! + 1).coerceAtLeast(1)
        } else if (selectedStartDay != null) {
            1
        } else {
            0
        }
    }

    val estimatedPrice = remember(daysCount, dailyPrice) {
        if (daysCount > 0) daysCount * (if (dailyPrice > 0) dailyPrice else hourlyPrice * 8) else 0.0
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("availability_calendar_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header: Title & Month navigation
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        tint = BluePrimary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isOwnerMode) "Müsaitlik & Doluluk Takvimi" else "Rezervasyon & Müsaitlik",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyDark
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { if (monthOffset > 0) monthOffset-- },
                        enabled = monthOffset > 0,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Önceki Ay",
                            tint = if (monthOffset > 0) NavyDark else TextMuted
                        )
                    }

                    Text(
                        text = "$monthName $year",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        color = NavyDark,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )

                    IconButton(
                        onClick = { if (monthOffset < 3) monthOffset++ },
                        enabled = monthOffset < 3,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Sonraki Ay",
                            tint = if (monthOffset < 3) NavyDark else TextMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Legend / Açıklama & Counts
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF8FAFC), RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val blockedInMonth = (1..daysInMonth).count { d ->
                    val k = String.format(Locale.ROOT, "%04d-%02d-%02d", year, month + 1, d)
                    blockedDates.contains(k) || reservedDates.contains(k)
                }
                val availableInMonth = daysInMonth - blockedInMonth

                Row(verticalAlignment = Alignment.CenterVertically) {
                    LegendBadge(color = Color(0xFF16A34A), label = if (isOwnerMode) "Müsait ($availableInMonth gün)" else "Müsait")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LegendBadge(color = Color(0xFFDC2626), label = if (isOwnerMode) "Dolu/Kapalı ($blockedInMonth gün)" else "Rezerve / Dolu")
                }
                if (!isOwnerMode) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LegendBadge(color = BluePrimary, label = "Seçili")
                    }
                }
            }

            if (isOwnerMode) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFDCFCE7),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF22C55E)),
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                // Clear blocked dates for this month
                                for (d in 1..daysInMonth) {
                                    val key = String.format(Locale.ROOT, "%04d-%02d-%02d", year, month + 1, d)
                                    if (blockedDates.contains(key)) {
                                        onToggleBlockDate(key)
                                    }
                                }
                            }
                    ) {
                        Text(
                            text = "🟢 Tüm Ayı Müsait Yap",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF15803D),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFEE2E2),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444)),
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                // Block weekends for this month
                                for (d in 1..daysInMonth) {
                                    val dayCal = Calendar.getInstance().apply {
                                        set(Calendar.YEAR, year)
                                        set(Calendar.MONTH, month)
                                        set(Calendar.DAY_OF_MONTH, d)
                                    }
                                    val dayOfWeek = dayCal.get(Calendar.DAY_OF_WEEK)
                                    if (dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY) {
                                        val key = String.format(Locale.ROOT, "%04d-%02d-%02d", year, month + 1, d)
                                        if (!blockedDates.contains(key)) {
                                            onToggleBlockDate(key)
                                        }
                                    }
                                }
                            }
                    ) {
                        Text(
                            text = "🔴 Hafta Sonlarını Kapat",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB91C1C),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Weekday Headers (Pzt, Sal, Çar, Per, Cum, Cmt, Paz)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("Pt", "Sa", "Ça", "Pe", "Cu", "Ct", "Pz").forEach { dayLabel ->
                    Text(
                        text = dayLabel,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = TextMuted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.width(36.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Days Grid
            val totalSlots = leadingEmptyDays + daysInMonth
            val totalRows = (totalSlots + 6) / 7

            for (row in 0 until totalRows) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    for (col in 0 until 7) {
                        val slotIndex = row * 7 + col
                        val dayNumber = slotIndex - leadingEmptyDays + 1

                        if (dayNumber in 1..daysInMonth) {
                            val dateKey = String.format(Locale.ROOT, "%04d-%02d-%02d", year, month + 1, dayNumber)
                            val isReserved = reservedDates.contains(dateKey)
                            val isPast = !isOwnerMode && dateKey < todayKey
                            val isBlocked = blockedDates.contains(dateKey) || isReserved || isPast
                            val isSelectedStart = selectedStartDay == dayNumber
                            val isSelectedEnd = selectedEndDay == dayNumber
                            val isInRange = selectedStartDay != null && selectedEndDay != null &&
                                    dayNumber > selectedStartDay!! && dayNumber < selectedEndDay!!

                            val isSelected = isSelectedStart || isSelectedEnd || isInRange

                            val cellBgColor = when {
                                isSelectedStart || isSelectedEnd -> BluePrimary
                                isInRange -> Color(0xFFDBEAFE)
                                isBlocked -> Color(0xFFFEE2E2) // RED when blocked/closed
                                else -> Color(0xFFDCFCE7) // GREEN when available (MÜSAİT)!
                            }

                            val cellBorderColor = when {
                                isSelectedStart || isSelectedEnd -> BluePrimary
                                isInRange -> BlueAccent
                                isBlocked -> Color(0xFFEF4444) // Crisp red border
                                else -> Color(0xFF22C55E) // Crisp green border!
                            }

                            val cellTextColor = when {
                                isSelectedStart || isSelectedEnd -> Color.White
                                isInRange -> BluePrimary
                                isBlocked -> Color(0xFFB91C1C) // Deep dark red
                                else -> Color(0xFF15803D) // Deep rich green!
                            }

                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(cellBgColor)
                                    .border(
                                        width = if (isSelectedStart || isSelectedEnd) 2.dp else 1.5.dp,
                                        color = cellBorderColor,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        if (isOwnerMode) {
                                            if (!isReserved) onToggleBlockDate(dateKey)
                                        } else {
                                            if (!isBlocked && selectionEnabled) {
                                                if (selectedStartDay == null || (selectedStartDay != null && selectedEndDay != null)) {
                                                    selectedStartDay = dayNumber
                                                    selectedEndDay = null
                                                } else if (selectedStartDay != null && selectedEndDay == null) {
                                                    if (dayNumber >= selectedStartDay!!) {
                                                        // Aralıkta dolu/rezerve gün varsa yeni başlangıç seç
                                                        val hasBlockedInside = (selectedStartDay!!..dayNumber).any { dd ->
                                                            val kk = String.format(Locale.ROOT, "%04d-%02d-%02d", year, month + 1, dd)
                                                            blockedDates.contains(kk) || reservedDates.contains(kk)
                                                        }
                                                        if (hasBlockedInside) {
                                                            selectedStartDay = dayNumber
                                                        } else {
                                                            selectedEndDay = dayNumber
                                                        }
                                                    } else {
                                                        selectedStartDay = dayNumber
                                                    }
                                                }
                                            }
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$dayNumber",
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected || isBlocked || !isBlocked) FontWeight.Bold else FontWeight.Medium,
                                    color = cellTextColor
                                )
                            }
                        } else {
                            Spacer(modifier = Modifier.size(36.dp))
                        }
                    }
                }
            }

            // Calculation & Action Banner
            if (!isOwnerMode && daysCount > 0) {
                Spacer(modifier = Modifier.height(14.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFEFF6FF),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Seçilen Süre: $daysCount Gün",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NavyDark
                                )
                                val startStr = "$selectedStartDay $monthName $year"
                                val endStr = if (selectedEndDay != null) "$selectedEndDay $monthName $year" else startStr
                                Text(
                                    text = "$startStr - $endStr",
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Tahmini Tutar",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                                Text(
                                    text = "₺${"%,.0f".format(Locale("tr", "TR"), estimatedPrice)}",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = BluePrimary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = {
                                val startStr = "$selectedStartDay $monthName $year"
                                val endStr = if (selectedEndDay != null) "$selectedEndDay $monthName $year" else startStr
                                onDateRangeSelected(startStr, endStr, daysCount, estimatedPrice)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("book_selected_dates_button"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Bu Tarihler İçin Teklif Ver",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            } else if (isOwnerMode) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "💡 Tarihlere dokunarak dilediğiniz günleri kiralamaya kapatabilir veya açabilirsiniz.",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
private fun LegendBadge(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            color = TextSecondary,
            fontWeight = FontWeight.Medium
        )
    }
}
