package com.example.ui.screens.handover

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.HandoverProtocol
import com.example.data.model.Machine
import com.example.data.model.User
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HandoverScreen(
    currentUser: User?,
    protocols: List<HandoverProtocol>,
    machines: List<Machine>,
    onBackClick: () -> Unit,
    onCreateProtocol: (HandoverProtocol) -> Unit,
    onCompleteProtocol: (protocolId: String, finalHours: Double, finalFuel: Int, returnNotes: String) -> Unit
) {
    var showCreateDialog by remember { mutableStateOf(false) }
    var protocolToComplete by remember { mutableStateOf<HandoverProtocol?>(null) }
    var selectedProtocolDetail by remember { mutableStateOf<HandoverProtocol?>(null) }

    Scaffold(
        topBar = {
            Surface(color = NavyDark, shadowElevation = 4.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Geri",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Dijital Teslim & Saat Tutanağı",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "İş Makinesi Teslimat ve Çalışma Saat Kayıtları",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                    }

                    Button(
                        onClick = { showCreateDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = BlueAccent),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("new_protocol_button")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Yeni Tutanak", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = BluePrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("create_protocol_fab")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Description, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Tutanak Oluştur", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF3F4F6)),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Legal & Security info card
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFEFF6FF),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BluePrimary.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(BluePrimary.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Şantiye Güvencesi & Saat Takibi",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = NavyDark
                            )
                            Text(
                                text = "Teslim saat sayacı, yakıt seviyesi ve hasar kontrolleri kayıt altına alınır.",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            if (protocols.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Henüz kayıtlı teslim tutanağı bulunmuyor.",
                            color = TextMuted,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                items(protocols) { proto ->
                    HandoverCard(
                        protocol = proto,
                        onCardClick = { selectedProtocolDetail = proto },
                        onCompleteClick = { protocolToComplete = proto }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }

    // Create Protocol Dialog
    if (showCreateDialog) {
        CreateProtocolDialog(
            currentUser = currentUser,
            machines = machines,
            onDismiss = { showCreateDialog = false },
            onSubmit = { newProto ->
                onCreateProtocol(newProto)
                showCreateDialog = false
            }
        )
    }

    // Complete Protocol Dialog
    protocolToComplete?.let { proto ->
        CompleteProtocolDialog(
            protocol = proto,
            onDismiss = { protocolToComplete = null },
            onSubmit = { finalHours, finalFuel, notes ->
                onCompleteProtocol(proto.id, finalHours, finalFuel, notes)
                protocolToComplete = null
            }
        )
    }

    // Detail Dialog
    selectedProtocolDetail?.let { proto ->
        ProtocolDetailDialog(
            protocol = proto,
            onDismiss = { selectedProtocolDetail = null }
        )
    }
}

@Composable
fun HandoverCard(
    protocol: HandoverProtocol,
    onCardClick: () -> Unit,
    onCompleteClick: () -> Unit
) {
    val isCompleted = protocol.status == "COMPLETED"

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCardClick() }
            .testTag("protocol_card_${protocol.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isCompleted) StatusSuccess.copy(alpha = 0.15f) else StatusWarning.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = if (isCompleted) "✓ İADE EDİLDİ & KAPANDI" else "⚡ AKTİF ÇALIŞMADA",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isCompleted) StatusSuccess else StatusWarning,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                val dateStr = SimpleDateFormat("dd.MM.yyyy", Locale("tr", "TR")).format(Date(protocol.createdAt))
                Text(
                    text = dateStr,
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = protocol.machineTitle,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = NavyDark
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Müşteri: ${protocol.customerName} | Makine Sahibi: ${protocol.ownerName}",
                fontSize = 12.sp,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Saat Sayacı & Yakıt Barı
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFFF9FAFB),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Speed, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Teslim Saati", fontSize = 10.sp, color = TextMuted)
                        }
                        Text(
                            text = "${protocol.initialHoursCounter} sa",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = NavyDark
                        )
                    }

                    if (isCompleted) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.HourglassBottom, contentDescription = null, tint = StatusSuccess, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = "İade Saati", fontSize = 10.sp, color = TextMuted)
                            }
                            Text(
                                text = "${protocol.finalHoursCounter} sa",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = StatusSuccess
                            )
                        }

                        val diff = (protocol.finalHoursCounter - protocol.initialHoursCounter).coerceAtLeast(0.0)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "Toplam Çalışma", fontSize = 10.sp, color = TextMuted)
                            Text(
                                text = "+${"%.1f".format(Locale.ROOT, diff)} sa",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp,
                                color = BluePrimary
                            )
                        }
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocalGasStation, contentDescription = null, tint = BlueAccent, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = "Teslim Yakıtı", fontSize = 10.sp, color = TextMuted)
                            }
                            Text(
                                text = "%${protocol.initialFuelPercent}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = NavyDark
                            )
                        }
                    }
                }
            }

            if (!isCompleted) {
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onCompleteClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .testTag("complete_protocol_button_${protocol.id}"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                ) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("İade Sayacını Gir & Tutanak Kapat", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun CreateProtocolDialog(
    currentUser: User?,
    machines: List<Machine>,
    onDismiss: () -> Unit,
    onSubmit: (HandoverProtocol) -> Unit
) {
    var selectedMachineTitle by remember { mutableStateOf(machines.firstOrNull()?.title ?: "") }
    var selectedMachineId by remember { mutableStateOf(machines.firstOrNull()?.id ?: "") }
    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var hoursCounterStr by remember { mutableStateOf("1250.0") }
    var fuelPercentStr by remember { mutableStateOf("100") }
    var notes by remember { mutableStateOf("") }
    var licenseChecked by remember { mutableStateOf(true) }
    var insuranceChecked by remember { mutableStateOf(true) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        text = "Yeni Teslim Tutanağı",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyDark
                    )
                    Text(
                        text = "Makine şantiyeye teslim edilirken çalışma saatini ve yakıtı kaydedin.",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }

                item {
                    OutlinedTextField(
                        value = selectedMachineTitle,
                        onValueChange = { selectedMachineTitle = it },
                        label = { Text("İş Makinesi Adı / Plaka *") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = customerName,
                            onValueChange = { customerName = it },
                            label = { Text("Teslim Alan (Müşteri) *") },
                            placeholder = { Text("Ad Soyad / Firma") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = customerPhone,
                            onValueChange = { customerPhone = it },
                            label = { Text("Telefon") },
                            placeholder = { Text("+90 532...") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = hoursCounterStr,
                            onValueChange = { hoursCounterStr = it },
                            label = { Text("Başlangıç Çalışma Saati *") },
                            placeholder = { Text("Örn: 2450.5") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = fuelPercentStr,
                            onValueChange = { fuelPercentStr = it },
                            label = { Text("Yakıt (%)") },
                            placeholder = { Text("%100") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Gözle Muayene / Hasar Notları") },
                        placeholder = { Text("Hortumlar, gövde, yağ kaçakları kontrol edildi...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(80.dp),
                        shape = RoundedCornerShape(10.dp),
                        maxLines = 3
                    )
                }

                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = licenseChecked, onCheckedChange = { licenseChecked = it })
                        Text(text = "Operatör G Sınıfı Ehliyeti Teyit Edildi", fontSize = 12.sp, color = NavyDark)
                    }
                }

                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = insuranceChecked, onCheckedChange = { insuranceChecked = it })
                        Text(text = "Makine Kasko / Sigorta Poliçesi Aktif", fontSize = 12.sp, color = NavyDark)
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Vazgeç")
                        }

                        Button(
                            onClick = {
                                val newProto = HandoverProtocol(
                                    id = "proto_${System.currentTimeMillis()}",
                                    machineId = selectedMachineId,
                                    machineTitle = selectedMachineTitle,
                                    ownerId = currentUser?.id ?: "",
                                    ownerName = currentUser?.fullName ?: "Makine Sahibi",
                                    customerId = "cust_${System.currentTimeMillis()}",
                                    customerName = customerName.ifBlank { "Şantiye Yetkilisi" },
                                    customerPhone = customerPhone,
                                    initialHoursCounter = hoursCounterStr.toDoubleOrNull() ?: 0.0,
                                    initialFuelPercent = fuelPercentStr.toIntOrNull() ?: 100,
                                    deliveryDate = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr", "TR")).format(Date()),
                                    conditionNotes = notes,
                                    hasOperatorLicenseChecked = licenseChecked,
                                    hasInsuranceVerified = insuranceChecked,
                                    status = "ACTIVE"
                                )
                                onSubmit(newProto)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("submit_create_protocol_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                        ) {
                            Text("Kaydet & Onayla", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CompleteProtocolDialog(
    protocol: HandoverProtocol,
    onDismiss: () -> Unit,
    onSubmit: (finalHours: Double, finalFuel: Int, returnNotes: String) -> Unit
) {
    var finalHoursStr by remember { mutableStateOf("${protocol.initialHoursCounter + 16.5}") }
    var finalFuelStr by remember { mutableStateOf("90") }
    var returnNotes by remember { mutableStateOf("") }

    val initialHours = protocol.initialHoursCounter
    val finalHours = finalHoursStr.toDoubleOrNull() ?: initialHours
    val totalWorkHours = (finalHours - initialHours).coerceAtLeast(0.0)

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Teslimatı Tamamla (İade)",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyDark
                )

                Text(
                    text = "${protocol.machineTitle} için son çalışma saati ve durumu kaydedin.",
                    fontSize = 12.sp,
                    color = TextSecondary
                )

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF9FAFB),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Başlangıç Saati: ${protocol.initialHoursCounter} sa", fontSize = 12.sp, color = TextSecondary)
                        Text(
                            text = "Fark: +${"%.1f".format(Locale.ROOT, totalWorkHours)} Saat",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = BluePrimary
                        )
                    }
                }

                OutlinedTextField(
                    value = finalHoursStr,
                    onValueChange = { finalHoursStr = it },
                    label = { Text("İade Çalışma Saati Sayacı *") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = finalFuelStr,
                    onValueChange = { finalFuelStr = it },
                    label = { Text("İade Yakıt Seviyesi (%)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = returnNotes,
                    onValueChange = { returnNotes = it },
                    label = { Text("İade Notu / Şantiye Çıkış Durumu") },
                    placeholder = { Text("Makine hasarsız ve temiz teslim alındı.") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("İptal")
                    }

                    Button(
                        onClick = {
                            onSubmit(
                                finalHoursStr.toDoubleOrNull() ?: protocol.initialHoursCounter,
                                finalFuelStr.toIntOrNull() ?: 100,
                                returnNotes
                            )
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess)
                    ) {
                        Text("Tutanağı Kapat", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ProtocolDetailDialog(
    protocol: HandoverProtocol,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Dijital Teslim Belgesi",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyDark
                    )
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = if (protocol.status == "COMPLETED") StatusSuccess.copy(alpha = 0.2f) else StatusWarning.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = protocol.status,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (protocol.status == "COMPLETED") StatusSuccess else StatusWarning,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Text(
                    text = protocol.machineTitle,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = BluePrimary
                )

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFFF9FAFB),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(text = "Teslim Eden: ${protocol.ownerName}", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Text(text = "Teslim Alan: ${protocol.customerName} (${protocol.customerPhone})", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Text(text = "Teslim Tarihi: ${protocol.deliveryDate.ifBlank { "14.08.2026 09:00" }}", fontSize = 12.sp, color = TextSecondary)
                        Text(text = "Başlangıç Saati: ${protocol.initialHoursCounter} sa | Yakıt: %${protocol.initialFuelPercent}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        if (protocol.status == "COMPLETED") {
                            Text(text = "İade Saati: ${protocol.finalHoursCounter} sa | Yakıt: %${protocol.finalFuelPercent}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = StatusSuccess)
                            val diff = protocol.finalHoursCounter - protocol.initialHoursCounter
                            Text(text = "Toplam Net Çalışma: +${"%.1f".format(Locale.ROOT, diff)} Saat", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = BluePrimary)
                        }
                    }
                }

                if (protocol.conditionNotes.isNotBlank()) {
                    Text(text = "Hasar / Durum Notları:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(text = protocol.conditionNotes, fontSize = 11.sp, color = Color(0xFF4B5563))
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                ) {
                    Text("Kapat", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
