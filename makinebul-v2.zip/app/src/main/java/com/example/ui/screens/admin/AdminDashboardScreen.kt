package com.example.ui.screens.admin

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Machine
import com.example.data.model.Report
import com.example.data.model.ServiceProviderApplication
import com.example.data.model.User
import com.example.data.model.UserType
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusWarning
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    currentUser: User?,
    usersList: List<User>,
    machinesList: List<Machine>,
    applicationsList: List<ServiceProviderApplication>,
    reportsList: List<Report>,
    onBackClick: () -> Unit,
    onToggleUserActive: (userId: String, active: Boolean) -> Unit,
    onDeleteMachine: (machineId: String) -> Unit,
    onProcessApplication: (appId: String, approve: Boolean, userId: String, role: String) -> Unit,
    onResolveReport: (reportId: String) -> Unit,
    onSendNotification: (title: String, body: String) -> Unit,
    onPurgeTestData: suspend () -> String = { "" },
    onCloseAllEmergencies: suspend () -> String = { "" },
    onSendDirectMessage: (userId: String, userName: String, text: String) -> Unit = { _, _, _ -> },
    onSetMachineStatus: (machineId: String, status: String, reason: String) -> Unit = { _, _, _ -> }
) {
    val isAuthorizedAdmin = currentUser?.userType == UserType.ADMIN
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // Unauthorized Access Guard Screen
    if (!isAuthorizedAdmin) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Erişim Reddedildi", color = Color.White, fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = onBackClick) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
                )
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyDark)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(StatusError.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Filled.Lock,
                                contentDescription = null,
                                tint = StatusError,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        Text(
                            text = "Yetkisiz Erişim!",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )

                        Text(
                            text = "Bu ekran sadece sistem yöneticilerine (role == 'admin') özeldir. Hesabınızın yetkisi '${currentUser?.userType?.labelTr ?: "Bilinmiyor"}' olarak görünmektedir.",
                            fontSize = 14.sp,
                            color = Color.LightGray,
                            textAlign = TextAlign.Center
                        )

                        Button(
                            onClick = onBackClick,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Ana Ekrana Dön", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        return
    }

    // Authorized Admin Dashboard UI
    var selectedTabIndex by remember { mutableStateOf(0) }
    val tabs = listOf(
        "Genel Bakış",
        "Başvurular (${applicationsList.count { it.status == "PENDING" }})",
        "İlanlar (${machinesList.size})",
        "Kullanıcılar (${usersList.size})",
        "Şikayetler & Talepler (${reportsList.count { it.status == "PENDING" }})",
        "Duyuru Gönder",
        "Veritabanı & Arşiv",
        "Onay Bekleyen İlanlar (${machinesList.count { it.status == "pending" }})"
    )

    var rejectTarget by remember { mutableStateOf<Machine?>(null) }
    var rejectReason by remember { mutableStateOf("") }
    var messageTarget by remember { mutableStateOf<User?>(null) }
    var directMessageText by remember { mutableStateOf("") }

    var searchQuery by remember { mutableStateOf("") }
    var applicationFilter by remember { mutableStateOf("PENDING") } // "ALL", "PENDING", "APPROVED", "REJECTED"

    var showNotifDialog by remember { mutableStateOf(false) }
    var notifTitle by remember { mutableStateOf("") }
    var notifBody by remember { mutableStateOf("") }

    var isCleaningDatabase by remember { mutableStateOf(false) }
    var lastCleanupResult by remember { mutableStateOf<String?>(null) }

    var machineToDelete by remember { mutableStateOf<Machine?>(null) }
    var pendingBulkAction by remember { mutableStateOf<String?>(null) } // "purge" | "close"
    var isBulkRunning by remember { mutableStateOf(false) }

    if (pendingBulkAction != null) {
        val isPurge = pendingBulkAction == "purge"
        AlertDialog(
            onDismissRequest = { if (!isBulkRunning) pendingBulkAction = null },
            title = { Text(if (isPurge) "Test kayıtları silinsin mi?" else "Açık acil çağrılar kapatılsın mı?") },
            text = {
                Text(
                    if (isPurge) "Kimliği \"demo\" ile başlayan eski ilan, teklif, mesaj, acil çağrı ve yorumlar kalıcı olarak silinir. Gerçek kullanıcı kayıtlarına dokunulmaz."
                    else "Tamamlanmamış tüm acil çağrılar İPTAL durumuna alınır. Bu işlem geri alınamaz."
                )
            },
            confirmButton = {
                Button(
                    enabled = !isBulkRunning,
                    onClick = {
                        val action = pendingBulkAction
                        isBulkRunning = true
                        scope.launch {
                            val msg = if (action == "purge") onPurgeTestData() else onCloseAllEmergencies()
                            isBulkRunning = false
                            pendingBulkAction = null
                            lastCleanupResult = msg
                            snackbarHostState.showSnackbar(msg)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) { Text(if (isBulkRunning) "Çalışıyor..." else "Evet, devam et", color = Color.White) }
            },
            dismissButton = {
                TextButton(enabled = !isBulkRunning, onClick = { pendingBulkAction = null }) { Text("Vazgeç") }
            }
        )
    }

    if (machineToDelete != null) {
        AlertDialog(
            onDismissRequest = { machineToDelete = null },
            title = { Text("İlanı Silmek İstiyor musunuz?") },
            text = {
                Text("'${machineToDelete?.title}' başlıklı makine ilanı Firestore veritabanından kalıcı olarak kaldırılacaktır.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        machineToDelete?.let {
                            onDeleteMachine(it.id)
                            scope.launch { snackbarHostState.showSnackbar("İlan silindi: ${it.title}") }
                        }
                        machineToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) {
                    Text("Kalıcı Olarak Sil", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { machineToDelete = null }) {
                    Text("Vazgeç")
                }
            }
        )
    }

    if (rejectTarget != null) {
        val rt = rejectTarget
        AlertDialog(
            onDismissRequest = { rejectTarget = null },
            title = { Text("İlan reddi: ${rt?.title ?: ""}") },
            text = {
                OutlinedTextField(
                    value = rejectReason,
                    onValueChange = { rejectReason = it },
                    label = { Text("Red sebebi (ilan sahibine iletilir)") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        rt?.let {
                            onSetMachineStatus(it.id, "rejected", rejectReason.trim())
                            scope.launch { snackbarHostState.showSnackbar("İlan reddedildi: ${it.title}") }
                        }
                        rejectReason = ""
                        rejectTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) { Text("Reddet", color = Color.White) }
            },
            dismissButton = { TextButton(onClick = { rejectTarget = null }) { Text("Vazgeç") } }
        )
    }

    if (messageTarget != null) {
        val target = messageTarget
        AlertDialog(
            onDismissRequest = { messageTarget = null },
            title = { Text("Mesaj Gönder: ${target?.fullName?.ifBlank { "Kullanıcı" } ?: ""}") },
            text = {
                OutlinedTextField(
                    value = directMessageText,
                    onValueChange = { directMessageText = it },
                    label = { Text("Mesajınız") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val t = target
                        if (t != null && directMessageText.isNotBlank()) {
                            onSendDirectMessage(t.id, t.fullName, directMessageText.trim())
                            scope.launch { snackbarHostState.showSnackbar("Mesaj gönderildi: ${t.fullName}") }
                            directMessageText = ""
                            messageTarget = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                ) { Text("Gönder", color = Color.White) }
            },
            dismissButton = {
                TextButton(onClick = { messageTarget = null }) { Text("İptal") }
            }
        )
    }

    if (showNotifDialog) {
        AlertDialog(
            onDismissRequest = { showNotifDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Notifications, contentDescription = null, tint = StatusWarning)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Toplu Duyuru / Push Bildirimi")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Tüm aktif kullanıcılara ve hizmet sağlayıcılara sistem bildirimi gönderilir:")
                    OutlinedTextField(
                        value = notifTitle,
                        onValueChange = { notifTitle = it },
                        label = { Text("Başlık") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = notifBody,
                        onValueChange = { notifBody = it },
                        label = { Text("Duyuru Metni") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (notifTitle.isNotBlank()) {
                            onSendNotification(notifTitle, notifBody)
                            showNotifDialog = false
                            scope.launch { snackbarHostState.showSnackbar("Bildirim gönderildi!") }
                            notifTitle = ""
                            notifBody = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                ) {
                    Text("Gönder", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showNotifDialog = false }) {
                    Text("İptal")
                }
            }
        )
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Security, contentDescription = null, tint = StatusWarning, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("MakineBul Yönetim Paneli", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text("Rol: ${currentUser.userType.labelTr} • ${currentUser.email}", color = BlueAccent, fontSize = 11.sp)
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Tabs Bar
            ScrollableTabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = NavyDark,
                contentColor = Color.White,
                edgePadding = 12.dp
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == index) BlueAccent else Color.LightGray,
                                fontSize = 13.sp
                            )
                        }
                    )
                }
            }

            when (selectedTabIndex) {
                0 -> {
                    // TAB 0: DASHBOARD OVERVIEW & STATS
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            Text("Sistem Özeti & Canlı Metrikler", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                AdminStatCard("Kayıtlı Kullanıcı", "${usersList.size}", "👥", Modifier.weight(1f))
                                AdminStatCard("Yayındaki İlanlar", "${machinesList.count { it.status == "approved" }}", "🚜", Modifier.weight(1f))
                            }
                        }

                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                val pendingApps = applicationsList.count { it.status == "PENDING" }
                                AdminStatCard(
                                    "Bekleyen Başvuru",
                                    "$pendingApps",
                                    "📝",
                                    Modifier.weight(1f),
                                    highlight = pendingApps > 0
                                )
                                val pendingReports = reportsList.count { it.status == "PENDING" }
                                AdminStatCard(
                                    "Açık Şikayetler",
                                    "$pendingReports",
                                    "⚠️",
                                    Modifier.weight(1f),
                                    highlight = pendingReports > 0
                                )
                            }
                        }

                    }
                }

                1 -> {
                    // TAB 1: SERVICE PROVIDER & MACHINE OWNER APPLICATIONS
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Hizmet Sağlayıcı Başvuruları", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            
                            // Filter row
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                FilterChip(
                                    selected = applicationFilter == "PENDING",
                                    label = "Bekleyen",
                                    onClick = { applicationFilter = "PENDING" }
                                )
                                FilterChip(
                                    selected = applicationFilter == "ALL",
                                    label = "Tümü",
                                    onClick = { applicationFilter = "ALL" }
                                )
                            }
                        }

                        val filteredApps = applicationsList.filter {
                            if (applicationFilter == "ALL") true else it.status == applicationFilter
                        }

                        if (filteredApps.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    if (applicationFilter == "PENDING") "Onay bekleyen başvuru bulunmamaktadır." else "Başvuru kaydı bulunamadı.",
                                    color = Color.Gray,
                                    fontSize = 14.sp
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(filteredApps, key = { it.id }) { app ->
                                    ApplicationItemCard(
                                        application = app,
                                        onApprove = {
                                            onProcessApplication(app.id, true, app.userId, app.requestedRole)
                                            scope.launch { snackbarHostState.showSnackbar("${app.userName} başvurusu ONAYLANDI.") }
                                        },
                                        onReject = {
                                            onProcessApplication(app.id, false, app.userId, app.requestedRole)
                                            scope.launch { snackbarHostState.showSnackbar("${app.userName} başvurusu REDDEDİLDİ.") }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // TAB 2: ACTIVE MACHINE LISTINGS MODERATION
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("İlan başlığı, marka, sahip veya şehir ara...") },
                            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        val filteredMachines = machinesList.filter {
                            searchQuery.isBlank() ||
                            it.title.contains(searchQuery, ignoreCase = true) ||
                            it.brand.contains(searchQuery, ignoreCase = true) ||
                            it.city.contains(searchQuery, ignoreCase = true) ||
                            it.ownerName.contains(searchQuery, ignoreCase = true)
                        }

                        Text("Yayınlanan İlanlar (${filteredMachines.size})", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                        if (filteredMachines.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Görüntülenecek ilan bulunamadı.", color = Color.Gray)
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(filteredMachines, key = { it.id }) { machine ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        shape = RoundedCornerShape(12.dp),
                                        elevation = CardDefaults.cardElevation(2.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(machine.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                                Text("${machine.brand} ${machine.model} • ${machine.category}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Text("Sahip: ${machine.ownerName} • ${machine.city} / ${machine.district}", fontSize = 12.sp, color = Color.Gray)
                                                Text("${machine.dailyPrice.toInt()} TL / gün", fontSize = 13.sp, color = BluePrimary, fontWeight = FontWeight.Bold)
                                                Text(
                                                    when (machine.status) { "pending" -> "⏳ Onay Bekliyor"; "rejected" -> "❌ Reddedildi"; else -> "✅ Yayında" },
                                                    fontSize = 11.sp, fontWeight = FontWeight.Bold,
                                                    color = when (machine.status) { "pending" -> StatusWarning; "rejected" -> StatusError; else -> StatusAvailable }
                                                )
                                            }

                                            IconButton(
                                                onClick = { machineToDelete = machine }
                                            ) {
                                                Icon(Icons.Filled.Delete, contentDescription = "İlanı Kaldır", tint = StatusError)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                3 -> {
                    // TAB 3: USER MANAGEMENT & STATUS TOGGLE
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Kullanıcı Listesi & Hesap Yönetimi (${usersList.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)

                        if (usersList.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("Kayıtlı kullanıcı verisi bulunamadı.", color = Color.Gray)
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(usersList, key = { it.id }) { user ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        shape = RoundedCornerShape(12.dp),
                                        elevation = CardDefaults.cardElevation(2.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(user.fullName.ifEmpty { "Kullanıcı" }, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                                Text("${user.email} • ${user.phone.ifEmpty { "Telefon yok" }}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Text("${user.city} / ${user.district}", fontSize = 11.sp, color = Color.Gray)
                                                
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                                    modifier = Modifier.padding(top = 4.dp)
                                                ) {
                                                    Surface(
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = BluePrimary.copy(alpha = 0.15f)
                                                    ) {
                                                        Text(
                                                            user.userType.labelTr,
                                                            fontSize = 11.sp,
                                                            color = BluePrimary,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                    Surface(
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = if (user.isActive) StatusAvailable.copy(alpha = 0.15f) else StatusError.copy(alpha = 0.15f)
                                                    ) {
                                                        Text(
                                                            if (user.isActive) "Aktif" else "Askıya Alındı",
                                                            fontSize = 11.sp,
                                                            color = if (user.isActive) StatusAvailable else StatusError,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }

                                            Column(
                                                horizontalAlignment = Alignment.End,
                                                verticalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                OutlinedButton(
                                                    onClick = {
                                                        directMessageText = ""
                                                        messageTarget = user
                                                    },
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Icon(Icons.Filled.Email, contentDescription = null, modifier = Modifier.size(14.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("Mesaj Gönder", fontSize = 11.sp)
                                                }
                                                OutlinedButton(
                                                    onClick = {
                                                        onToggleUserActive(user.id, !user.isActive)
                                                        scope.launch {
                                                            snackbarHostState.showSnackbar(
                                                                if (user.isActive) "${user.fullName} askıya alındı." else "${user.fullName} aktifleştirildi."
                                                            )
                                                        }
                                                    },
                                                    shape = RoundedCornerShape(8.dp),
                                                    colors = ButtonDefaults.outlinedButtonColors(
                                                        contentColor = if (user.isActive) StatusError else StatusAvailable
                                                    )
                                                ) {
                                                    Text(if (user.isActive) "Askıya Al" else "Aktifleştir", fontSize = 11.sp)
                                                }

                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                4 -> {
                    // TAB 4: REPORTS & COMPLAINTS
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Şikayetler & Destek Talepleri (${reportsList.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)

                        if (reportsList.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("İncelenecek şikayet / talep bulunmamaktadır.", color = Color.Gray)
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(reportsList, key = { it.reportId }) { rep ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        shape = RoundedCornerShape(12.dp),
                                        elevation = CardDefaults.cardElevation(2.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text("Sebep: ${rep.reason}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = if (rep.status == "PENDING") StatusWarning.copy(alpha = 0.15f) else StatusAvailable.copy(alpha = 0.15f)
                                                ) {
                                                    Text(
                                                        if (rep.status == "PENDING") "Açık" else "Çözüldü",
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (rep.status == "PENDING") StatusWarning else StatusAvailable,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }

                                            Text(rep.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text("Gönderen: ${rep.reportedByName} • Tür: ${when (rep.targetType) { "SUPPORT" -> "Destek Talebi"; "COMPLAINT" -> "Şikayet"; "USER" -> "Kullanıcı Şikayeti"; "MACHINE" -> "İlan Şikayeti"; else -> rep.targetType }}", fontSize = 11.sp, color = Color.Gray)

                                            if (rep.status == "PENDING") {
                                                Button(
                                                    onClick = {
                                                        onResolveReport(rep.reportId)
                                                        scope.launch { snackbarHostState.showSnackbar("Şikayet çözüldü olarak işaretlendi.") }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                                                    modifier = Modifier.align(Alignment.End),
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Text("Çözüldü Olarak İşaretle", fontSize = 11.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                5 -> {
                    // TAB 5: BROADCAST NOTIFICATION
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = NavyDark),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text("📢 Toplu Bildirim / Duyuru Merkezi", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text(
                                    "MakineBul platformundaki tüm aktif kullanıcılara ve hizmet sağlayıcılara anlık duyuru veya sistem mesajı yayınlayın.",
                                    color = Color.LightGray,
                                    fontSize = 13.sp
                                )

                                OutlinedTextField(
                                    value = notifTitle,
                                    onValueChange = { notifTitle = it },
                                    label = { Text("Duyuru Başlığı", color = Color.LightGray) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedBorderColor = BlueAccent,
                                        unfocusedBorderColor = Color.Gray
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                OutlinedTextField(
                                    value = notifBody,
                                    onValueChange = { notifBody = it },
                                    label = { Text("Duyuru Detayı", color = Color.LightGray) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedBorderColor = BlueAccent,
                                        unfocusedBorderColor = Color.Gray
                                    ),
                                    modifier = Modifier.fillMaxWidth(),
                                    minLines = 3
                                )

                                Button(
                                    onClick = {
                                        if (notifTitle.isNotBlank()) {
                                            onSendNotification(notifTitle, notifBody)
                                            scope.launch { snackbarHostState.showSnackbar("Duyuru tüm kullanıcılara iletildi!") }
                                            notifTitle = ""
                                            notifBody = ""
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusWarning),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Filled.Notifications, contentDescription = null, tint = Color.Black)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Duyuruyu Yayınla", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                6 -> {
                    // TAB 6: DATABASE PRUNING & ARCHIVING
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = NavyDark),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(18.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Filled.Refresh, contentDescription = null, tint = BlueAccent, modifier = Modifier.size(24.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("🧹 Veritabanı Temizliği & Arşivleme", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    }

                                    Text(
                                        "MakineBul veritabanında yığılmayı önlemek amacıyla 24 saati geçmiş veya 'tamamlandı/iptal edildi' durumundaki acil çağrılar ve teklifler arşivlenir ve aktif gerçek zamanlı sorgulardan hariç tutulur.",
                                        color = Color.LightGray,
                                        fontSize = 13.sp,
                                        lineHeight = 18.sp
                                    )

                                    HorizontalDivider(color = Color.DarkGray)

                                    Text("⚙️ Otomatik Filtreleme Kuralları:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("• Acil Çağrılar: Yalnızca aktif durumdakiler (SEARCHING, OFFERED, ACCEPTED, ARRIVING, ARRIVED, IN_SERVICE) veya son 24 saatteki çağrılar çekilir.", color = Color.LightGray, fontSize = 12.sp)
                                    Text("• Teklifler: Reddedilen / İptal edilen 24 saatten eski kayıtlar anlık listelerden gizlenir.", color = Color.LightGray, fontSize = 12.sp)
                                    Text("• Bildirimler: 48 saatten eski bildirimler silinerek sunucu yükü hafifletilir.", color = Color.LightGray, fontSize = 12.sp)
                                    Text("• Arşivleme: Silinen kayıtlar 'archived_emergencyRequests' ve 'archived_offers' koleksiyonlarında güvenle saklanır.", color = Color.LightGray, fontSize = 12.sp)

                                    if (lastCleanupResult != null) {
                                        Surface(
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(10.dp),
                                            color = StatusAvailable.copy(alpha = 0.2f)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = StatusAvailable)
                                                Text(
                                                    lastCleanupResult ?: "",
                                                    color = Color.White,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            }
                                        }
                                    }

                                    Button(
                                        onClick = {
                                            isCleaningDatabase = true
                                            scope.launch {
                                                val stats = com.example.data.util.DataCleanupManager.performDatabaseCleanup()
                                                lastCleanupResult = stats.message
                                                isCleaningDatabase = false
                                                snackbarHostState.showSnackbar("Temizlik tamamlandı: ${stats.message}")
                                            }
                                        },
                                        enabled = !isCleaningDatabase,
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        if (isCleaningDatabase) {
                                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Arşivleniyor ve Temizleniyor...", color = Color.White)
                                        } else {
                                            Icon(Icons.Filled.Refresh, contentDescription = null, tint = Color.White)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("24 Saati Geçen Eski Kayıtları Arşivle & Temizle", color = Color.White, fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    HorizontalDivider(color = Color.DarkGray)
                                    Text("🧪 Test Verisi Temizliği", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)

                                    Button(
                                        onClick = { pendingBulkAction = "purge" },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = StatusError),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("Eski Demo/Test Kayıtlarını Sil", color = Color.White, fontWeight = FontWeight.Bold)
                                    }

                                    OutlinedButton(
                                        onClick = { pendingBulkAction = "close" },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("Tüm Açık Acil Çağrıları Kapat", color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                7 -> {
                    // TAB 7: PENDING LISTING APPROVALS
                    val pendingMachines = machinesList.filter { it.status == "pending" }
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("Onay Bekleyen İlanlar (${pendingMachines.size})", fontWeight = FontWeight.Bold, fontSize = 16.sp)

                        if (pendingMachines.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("Onay bekleyen ilan yok.", color = Color.Gray)
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(pendingMachines, key = { it.id }) { machine ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        shape = RoundedCornerShape(12.dp),
                                        elevation = CardDefaults.cardElevation(2.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(machine.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                            Text("${machine.brand} ${machine.model} • ${machine.category} • ${machine.year}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text("Sahip: ${machine.ownerName} • ${machine.ownerPhone}", fontSize = 12.sp, color = Color.Gray)
                                            Text("${machine.city} / ${machine.district} ${machine.address}", fontSize = 12.sp, color = Color.Gray)
                                            Text("${machine.hourlyPrice.toInt()} TL/saat • ${machine.dailyPrice.toInt()} TL/gün • Fotoğraf: ${machine.photos.size}", fontSize = 12.sp, color = BluePrimary, fontWeight = FontWeight.Bold)
                                            if (machine.description.isNotBlank()) {
                                                Text(machine.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Button(
                                                    onClick = {
                                                        onSetMachineStatus(machine.id, "approved", "")
                                                        scope.launch { snackbarHostState.showSnackbar("İlan onaylandı: ${machine.title}") }
                                                    },
                                                    colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable),
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(8.dp)
                                                ) {
                                                    Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("ONAYLA", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                }
                                                OutlinedButton(
                                                    onClick = {
                                                        rejectReason = ""
                                                        rejectTarget = machine
                                                    },
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(8.dp),
                                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusError)
                                                ) {
                                                    Icon(Icons.Filled.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Text("REDDET", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ApplicationItemCard(
    application: ServiceProviderApplication,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(application.userName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                val (roleColor, roleLabel) = when (application.requestedRole.uppercase()) {
                    "DUTY_TOW", "ÇEKİCİ", "TOW_TRUCK" -> StatusWarning to "Nöbetçi Çekici"
                    "DUTY_TIRE", "LASTİKÇİ", "TIRE_SERVICE" -> BluePrimary to "Nöbetçi Lastikçi"
                    else -> StatusAvailable to "Makine Sahibi"
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = roleColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        roleLabel,
                        fontSize = 11.sp,
                        color = roleColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            if (application.companyName.isNotBlank() || application.taxNumber.isNotBlank()) {
                Text("Firma: ${application.companyName.ifEmpty { "-" }} • Vergi No: ${application.taxNumber.ifEmpty { "-" }}", fontSize = 12.sp)
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Phone, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("${application.userPhone} • ${application.district}, ${application.city}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            if (application.note.isNotBlank()) {
                Text("Not: ${application.note}", fontSize = 12.sp, color = Color.Gray)
            }

            if (application.status == "PENDING") {
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ONAYLA", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = onReject,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusError)
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("REDDET", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (application.status == "APPROVED") StatusAvailable.copy(alpha = 0.15f) else StatusError.copy(alpha = 0.15f),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text(
                        if (application.status == "APPROVED") "Onaylandı" else "Reddedildi",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (application.status == "APPROVED") StatusAvailable else StatusError,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun FilterChip(
    selected: Boolean,
    label: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (selected) BluePrimary else NavyLight,
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = if (selected) Color.White else Color.LightGray,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun AdminStatCard(
    title: String,
    value: String,
    iconEmoji: String,
    modifier: Modifier = Modifier,
    highlight: Boolean = false
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = if (highlight) NavyLight else NavyDark
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(iconEmoji, fontSize = 20.sp)
            Text(
                value,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (highlight) StatusWarning else Color.White
            )
            Text(title, fontSize = 11.sp, color = Color.LightGray)
        }
    }
}
