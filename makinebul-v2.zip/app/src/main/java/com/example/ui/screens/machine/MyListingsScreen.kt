package com.example.ui.screens.machine

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.ToggleOff
import androidx.compose.material.icons.filled.ToggleOn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Machine
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusBusy
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyListingsScreen(
    ownerMachines: List<Machine>,
    onNavigateBack: () -> Unit,
    onAddNewListing: () -> Unit,
    onEditMachine: (Machine) -> Unit,
    onToggleAvailability: (String) -> Unit,
    onDeleteMachine: (String) -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("İlanlarım & Makine Yönetimi", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Geri", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddNewListing,
                containerColor = BluePrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_new_listing_fab")
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Yeni İlan Ekle")
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        if (ownerMachines.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Filled.ListAlt, contentDescription = null, tint = TextMuted, modifier = Modifier.size(56.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text("Henüz eklenmiş bir makine ilanınız yok.", color = TextSecondary, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = onAddNewListing, colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)) {
                    Text("İlk İlanınızı Oluşturun", color = Color.White)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(ownerMachines) { machine ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = machine.title,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )

                                Surface(
                                    color = if (machine.isAvailable) StatusAvailable else StatusBusy,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = if (machine.isAvailable) "Aktif (Müsait)" else "Pasif (Dolu)",
                                        color = Color.White,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            if (machine.status != "approved") {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (machine.status == "pending") "⏳ Yönetici onayı bekleniyor — müşterilere henüz görünmez"
                                           else "❌ Reddedildi" + (if (machine.rejectionReason.isNotBlank()) ": ${machine.rejectionReason}" else "") + " — düzenleyip tekrar gönderebilirsiniz",
                                    color = if (machine.status == "pending") StatusWarning else StatusError,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "${machine.category} • ${machine.brand} ${machine.model}",
                                fontSize = 13.sp,
                                color = TextSecondary
                            )

                            Text(
                                text = "Saatlik: ₺${machine.hourlyPrice.toInt()} | Günlük: ₺${machine.dailyPrice.toInt()}",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = BluePrimary
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Actions Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = { onToggleAvailability(machine.id) },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(
                                        imageVector = if (machine.isAvailable) Icons.Filled.ToggleOff else Icons.Filled.ToggleOn,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (machine.isAvailable) "Pasife Al" else "Aktif Et", fontSize = 12.sp)
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    IconButton(onClick = { onEditMachine(machine) }) {
                                        Icon(Icons.Filled.Edit, contentDescription = "Düzenle", tint = BluePrimary)
                                    }

                                    IconButton(onClick = { onDeleteMachine(machine.id) }) {
                                        Icon(Icons.Filled.Delete, contentDescription = "Sil", tint = StatusError)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
