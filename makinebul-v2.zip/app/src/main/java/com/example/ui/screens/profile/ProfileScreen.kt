package com.example.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.RequestQuote
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.User
import com.example.data.model.UserType
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

import androidx.compose.material.icons.filled.LocalShipping

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    currentUser: User?,
    onNavigateBack: () -> Unit = {},
    onSwitchUserTypeRole: () -> Unit,
    onNavigateToOffers: () -> Unit,
    onNavigateToFavorites: () -> Unit,
    onNavigateToMyListings: () -> Unit,
    onNavigateToAddListing: () -> Unit,
    onNavigateToTowDuty: () -> Unit = {},
    onNavigateToAdmin: () -> Unit = {},
    onNavigateToApplyProvider: () -> Unit = {},
    onNavigateToMap: () -> Unit = {},
    onSubmitReport: (type: String, reason: String, description: String) -> Unit = { _, _, _ -> },
    onLogout: () -> Unit
) {
    var showLogoutDialog by remember { mutableStateOf(false) }
    var showReportDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var reportType by remember { mutableStateOf("COMPLAINT") }
    var reportReason by remember { mutableStateOf("") }
    var reportText by remember { mutableStateOf("") }
    val reportContext = androidx.compose.ui.platform.LocalContext.current

    if (showThemeDialog) {
        val themeCtx = androidx.compose.ui.platform.LocalContext.current
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            title = { Text("🎨 Uygulama Teması", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    com.example.ui.theme.AppTheme.values().forEach { th ->
                        val selected = com.example.ui.theme.ThemeManager.current == th
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (selected) BluePrimary.copy(alpha = 0.15f) else Color.Transparent)
                                .clickable {
                                    com.example.ui.theme.ThemeManager.set(themeCtx, th)
                                    showThemeDialog = false
                                    (themeCtx as? android.app.Activity)?.recreate()
                                }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(com.example.ui.theme.ThemeManager.swatch(th), CircleShape)
                                    .border(2.dp, Color(0xFFF97316), CircleShape)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(th.label, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(th.desc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (selected) Text("✓", fontWeight = FontWeight.Black, color = BluePrimary)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showThemeDialog = false }) { Text("Kapat") } }
        )
    }

    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = { Text("Şikayet / Destek Bildir") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("COMPLAINT" to "Şikayet", "SUPPORT" to "Destek Talebi").forEach { (key, label) ->
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (reportType == key) BluePrimary else NavyLight,
                                modifier = Modifier.clickable { reportType = key }
                            ) {
                                Text(
                                    label,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                    androidx.compose.material3.OutlinedTextField(
                        value = reportReason,
                        onValueChange = { reportReason = it },
                        label = { Text("Konu") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    androidx.compose.material3.OutlinedTextField(
                        value = reportText,
                        onValueChange = { reportText = it },
                        label = { Text("Açıklama") },
                        minLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (reportReason.isBlank() || reportText.isBlank()) {
                            android.widget.Toast.makeText(reportContext, "Konu ve açıklama giriniz.", android.widget.Toast.LENGTH_SHORT).show()
                        } else {
                            onSubmitReport(reportType, reportReason.trim(), reportText.trim())
                            android.widget.Toast.makeText(reportContext, "Bildiriminiz yöneticiye iletildi. Teşekkürler.", android.widget.Toast.LENGTH_LONG).show()
                            reportReason = ""
                            reportText = ""
                            showReportDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                ) { Text("Gönder", color = Color.White) }
            },
            dismissButton = { TextButton(onClick = { showReportDialog = false }) { Text("Vazgeç") } }
        )
    }
    val isTowProvider = currentUser?.userType == UserType.DUTY_TOW || currentUser?.userType == UserType.DUTY_TIRE

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("Çıkış Yap") },
            text = { Text("Hesabınızdan çıkış yapmak istediğinize emin misiniz?") },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutDialog = false
                        onLogout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) {
                    Text("Çıkış Yap", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text("Vazgeç")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Profilim", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("profile_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Ana Sayfaya Dön",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("profile_home_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Home,
                            contentDescription = "Ana Sayfa",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Profile Info Header Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = NavyDark),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .background(BluePrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Person,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(48.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = currentUser?.fullName?.ifBlank { "İsimsiz Kullanıcı" } ?: "İsimsiz Kullanıcı",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Role Badge (Static, no switching)
                    Surface(
                        color = NavyLight,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Hesap Türü: ${currentUser?.userType?.labelTr ?: "Müşteri"}",
                                color = BlueAccent,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(Icons.Filled.Star, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(18.dp))
                        Text(
                            text = "${currentUser?.rating ?: 5.0} Puan",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Contact & Location Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Hesap Bilgileri", fontWeight = FontWeight.Bold, fontSize = 16.sp)

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Phone, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(currentUser?.phone?.ifBlank { "Telefon girilmedi" } ?: "Telefon girilmedi", fontSize = 14.sp)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Email, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(currentUser?.email?.ifBlank { "E-posta girilmedi" } ?: "E-posta girilmedi", fontSize = 14.sp)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.LocationCity, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("${currentUser?.city ?: "-"} / ${currentUser?.district ?: "-"}", fontSize = 14.sp)
                    }
                }
            }

            if (!isTowProvider) {
            // Seçenekler
            if (currentUser?.userType == UserType.ADMIN) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToAdmin() },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyDark)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = StatusWarning.copy(alpha = 0.2f),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.Person, contentDescription = null, tint = StatusWarning)
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("👑 Yönetim Paneli (Admin)", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
                            Text("Başvurular, ilan onayları, kullanıcı yönetimi & duyurular", fontSize = 11.sp, color = BlueAccent)
                        }
                    }
                }
            }

            if (currentUser?.userType == UserType.DUTY_TOW || currentUser?.userType == UserType.DUTY_TIRE || currentUser?.userType == UserType.ADMIN) {
                ProfileOptionRow(
                    icon = Icons.Filled.LocalShipping,
                    title = "🚨 Çekici Nöbet Sistemi & Müsaitlik",
                    onClick = onNavigateToTowDuty
                )
            }

            if (currentUser?.userType != UserType.OWNER) {
                ProfileOptionRow(
                    icon = Icons.Filled.ListAlt,
                    title = "📝 Hizmet Sağlayıcı / Makine Sahibi Başvurusu Yap",
                    onClick = onNavigateToApplyProvider
                )
            }

            if (currentUser?.userType == UserType.OWNER) {
                ProfileOptionRow(
                    icon = Icons.Filled.ListAlt,
                    title = "İlanlarım & Makine Yönetimi",
                    onClick = onNavigateToMyListings
                )

                ProfileOptionRow(
                    icon = Icons.Filled.Add,
                    title = "Yeni Makine İlanı Ver",
                    onClick = onNavigateToAddListing
                )

                ProfileOptionRow(
                    icon = Icons.Filled.RequestQuote,
                    title = "Gelen Teklifler",
                    onClick = onNavigateToOffers
                )
            } else {
                ProfileOptionRow(
                    icon = Icons.Filled.RequestQuote,
                    title = "Tekliflerim",
                    onClick = onNavigateToOffers
                )

                ProfileOptionRow(
                    icon = Icons.Filled.Favorite,
                    title = "Favorilerim",
                    onClick = onNavigateToFavorites
                )
            }

            ProfileOptionRow(
                icon = Icons.Filled.Map,
                title = "🗺️ Canlı Harita Görünümü",
                onClick = onNavigateToMap
            )
            }

            ProfileOptionRow(
                icon = Icons.Filled.Star,
                title = "🎨 Uygulama Teması",
                onClick = { showThemeDialog = true }
            )

            if (currentUser?.userType != UserType.ADMIN) {
                ProfileOptionRow(
                    icon = Icons.Filled.Email,
                    title = "📣 Şikayet / Destek Bildir",
                    onClick = { showReportDialog = true }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Logout Button
            Button(
                onClick = { showLogoutDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("logout_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = StatusError)
            ) {
                Icon(Icons.Filled.ExitToApp, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Çıkış Yap", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}

@Composable
fun ProfileOptionRow(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(BluePrimary.copy(alpha = 0.1f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(20.dp))
            }

            Spacer(modifier = Modifier.width(14.dp))

            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
        }
    }
}
