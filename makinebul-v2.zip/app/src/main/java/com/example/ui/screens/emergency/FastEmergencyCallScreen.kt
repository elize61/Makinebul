package com.example.ui.screens.emergency

import android.Manifest
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EmergencyServiceType
import com.example.data.repository.EmergencyRepository
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusWarning
import com.example.util.LocationUtils
import kotlinx.coroutines.launch

/**
 * Fast Emergency Call Screen: Allows stranded users to request tow truck or tire repair
 * immediately without registration or login, powered by Firebase Anonymous Authentication.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun FastEmergencyCallScreen(
    emergencyRepository: EmergencyRepository,
    initialServiceType: EmergencyServiceType = EmergencyServiceType.TOW_TRUCK,
    onBackClick: () -> Unit,
    onRequestCreated: (requestId: String) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedServiceType by remember { mutableStateOf(initialServiceType) }
    val isTireMode = selectedServiceType == EmergencyServiceType.TIRE_SERVICE

    // User inputs
    var phone by remember { mutableStateOf("") }
    var customerName by remember { mutableStateOf("") }
    var locationDescription by remember { mutableStateOf("") }
    var destinationLocation by remember { mutableStateOf("") }
    var selectedVehicleType by remember { mutableStateOf("Otomobil") }
    var plate by remember { mutableStateOf("") }
    var selectedProblem by remember {
        mutableStateOf(if (isTireMode) "Lastik patladı" else "Aracım çalışmıyor")
    }
    var tireDimension by remember { mutableStateOf("") }
    var hasSpareTire by remember { mutableStateOf(true) }
    var description by remember { mutableStateOf("") }

    // GPS State
    var customerLat by remember { mutableDoubleStateOf(0.0) }
    var customerLng by remember { mutableDoubleStateOf(0.0) }
    var isGpsActive by remember { mutableStateOf(false) }
    var isGpsLoading by remember { mutableStateOf(false) }
    var gpsStatusText by remember { mutableStateOf("GPS Konumu bekleniyor...") }

    // Loading & Error State
    var isSubmitting by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val vehicleTypes = listOf(
        "Otomobil", "SUV", "Hafif Ticari", "Kamyonet",
        "Kamyon", "Otobüs", "Motosiklet", "Diğer"
    )

    val towProblems = listOf(
        "Aracım çalışmıyor", "Kaza yaptım", "Akü bitti",
        "Motor arızası", "Şanzıman / Mekanik", "Yakıt bitti", "Diğer"
    )

    val tireProblems = listOf(
        "Lastik patladı", "Lastik yarıldı", "Stepne değişimi",
        "Lastik indi (Hava)", "Jant hasarlı", "Çift lastik indi", "Diğer"
    )

    val problemOptions = if (isTireMode) tireProblems else towProblems

    // Update default problem when toggling service mode
    LaunchedEffect(isTireMode) {
        if (!problemOptions.contains(selectedProblem)) {
            selectedProblem = problemOptions.first()
        }
    }

    // Auto GPS permission request on entry
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false

        if (fineGranted || coarseGranted) {
            isGpsLoading = true
            LocationUtils.getCurrentLocation(
                context = context,
                onSuccess = { lat, lng ->
                    isGpsLoading = false
                    customerLat = lat
                    customerLng = lng
                    isGpsActive = true
                    gpsStatusText = "📍 GPS Konumunuz Alındı (%.4f, %.4f)".format(lat, lng)
                    if (locationDescription.isBlank()) {
                        locationDescription = "GPS Konumu (%.4f, %.4f)".format(lat, lng)
                    }
                },
                onError = { msg ->
                    isGpsLoading = false
                    isGpsActive = false
                    gpsStatusText = "⚠️ $msg (Lütfen açık adresi yazınız)"
                }
            )
        } else {
            isGpsActive = false
            gpsStatusText = "⚠️ Konum izni verilmedi (Konumu elle girin)"
        }
    }

    LaunchedEffect(Unit) {
        if (LocationUtils.hasLocationPermission(context)) {
            isGpsLoading = true
            LocationUtils.getCurrentLocation(
                context = context,
                onSuccess = { lat, lng ->
                    isGpsLoading = false
                    customerLat = lat
                    customerLng = lng
                    isGpsActive = true
                    gpsStatusText = "📍 GPS Konumunuz Alındı (%.4f, %.4f)".format(lat, lng)
                },
                onError = { msg ->
                    isGpsLoading = false
                    isGpsActive = false
                    gpsStatusText = "⚠️ $msg"
                }
            )
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "🚨 HIZLI ACİL ÇAĞRI",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 17.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = StatusAvailable.copy(alpha = 0.25f)
                            ) {
                                Text(
                                    text = "ÜYE OLMADAN",
                                    color = StatusAvailable,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "Giriş yapmadan 30 saniyede çekici veya lastikçi çağırın",
                            color = BlueAccent,
                            fontSize = 11.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Geri",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(NavyDark)
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // High-visibility Emergency Info Banner
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyLight),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, StatusWarning)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = StatusWarning.copy(alpha = 0.2f),
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("⚡", fontSize = 22.sp)
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Üyelik veya Şifre Gerekmez!",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Telefon numaranız ve konumunuz nöbetçi ustalara iletilir. Gelen fiyat tekliflerini bu ekranda anlık görür ve seçtiğiniz ustayı tek tıkla arayabilirsiniz.",
                                color = Color.LightGray,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }

                // 1. Service Type Selector (Tow Truck vs Tire Repair)
                Text(
                    text = "1. İhtiyacınız Olan Hizmeti Seçin",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Tow Truck Card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedServiceType = EmergencyServiceType.TOW_TRUCK }
                            .testTag("select_service_tow"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (!isTireMode) StatusError.copy(alpha = 0.2f) else NavyLight
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            2.dp,
                            if (!isTireMode) StatusError else Color.Transparent
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("🚛", fontSize = 32.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Acil Çekici",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Oto Kurtarma",
                                color = if (!isTireMode) StatusError else Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Tire Service Card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedServiceType = EmergencyServiceType.TIRE_SERVICE }
                            .testTag("select_service_tire"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isTireMode) BluePrimary.copy(alpha = 0.2f) else NavyLight
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            2.dp,
                            if (isTireMode) BluePrimary else Color.Transparent
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("🛞", fontSize = 32.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Mobil Lastikçi",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Yerinde Tamir",
                                color = if (isTireMode) BlueAccent else Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                // 2. Contact & Phone Information
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyLight)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Phone, contentDescription = null, tint = StatusAvailable, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "2. İletişim Bilgileri (Zorunlu)",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("Telefon Numaranız *") },
                            placeholder = { Text("05XX XXX XX XX") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            leadingIcon = {
                                Icon(Icons.Filled.Phone, contentDescription = null, tint = BlueAccent)
                            },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_guest_phone"),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = StatusAvailable,
                                unfocusedBorderColor = Color.Gray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        OutlinedTextField(
                            value = customerName,
                            onValueChange = { customerName = it },
                            label = { Text("Adınız Soyadınız (İsteğe Bağlı)") },
                            placeholder = { Text("Örn: Murat Bey") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BluePrimary,
                                unfocusedBorderColor = Color.Gray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                    }
                }

                // 3. Location Information & GPS
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyLight)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.LocationOn, contentDescription = null, tint = StatusError, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "3. Konumunuz ve Yol Tarifi",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                            if (isGpsActive) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = StatusAvailable.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "GPS AKTİF",
                                        color = StatusAvailable,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        // GPS Trigger button
                        OutlinedButton(
                            onClick = {
                                if (LocationUtils.hasLocationPermission(context)) {
                                    isGpsLoading = true
                                    LocationUtils.getCurrentLocation(
                                        context = context,
                                        onSuccess = { lat, lng ->
                                            isGpsLoading = false
                                            customerLat = lat
                                            customerLng = lng
                                            isGpsActive = true
                                            gpsStatusText = "📍 GPS Bağlandı: %.4f, %.4f".format(lat, lng)
                                            locationDescription = "GPS Konumu (%.4f, %.4f)".format(lat, lng)
                                            Toast.makeText(context, "GPS koordinatlarınız alındı", Toast.LENGTH_SHORT).show()
                                        },
                                        onError = { err ->
                                            isGpsLoading = false
                                            Toast.makeText(context, "Hata: $err", Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                } else {
                                    permissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("btn_fast_gps"),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isGpsActive) StatusAvailable else BlueAccent
                            )
                        ) {
                            if (isGpsLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Konum Alınıyor...", color = Color.White, fontSize = 12.sp)
                            } else {
                                Icon(Icons.Filled.GpsFixed, contentDescription = null, tint = if (isGpsActive) StatusAvailable else BlueAccent, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isGpsActive) "GPS Konumu Yenile (Alındı)" else "GPS Konumumu Otomatik Al",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Text(
                            text = gpsStatusText,
                            color = if (isGpsActive) StatusAvailable else Color.LightGray,
                            fontSize = 11.sp
                        )

                        OutlinedTextField(
                            value = locationDescription,
                            onValueChange = { locationDescription = it },
                            label = { Text("Bulunduğunuz Yer / Açık Yol Tarifi *") },
                            placeholder = { Text("Örn: TEM Otoyolu Ümraniye çıkışı 200m ilerisi") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_guest_location"),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BluePrimary,
                                unfocusedBorderColor = Color.Gray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        // If tow truck, ask for target destination
                        if (!isTireMode) {
                            OutlinedTextField(
                                value = destinationLocation,
                                onValueChange = { destinationLocation = it },
                                label = { Text("Aracın Çekileceği Yer / Sanayi Sitesi") },
                                placeholder = { Text("Örn: Bostancı Oto Sanayi Sitesi") },
                                leadingIcon = {
                                    Icon(Icons.Filled.Flag, contentDescription = null, tint = StatusWarning)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BluePrimary,
                                    unfocusedBorderColor = Color.Gray,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )
                        }
                    }
                }

                // 4. Vehicle & Problem Details
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyLight)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.DirectionsCar, contentDescription = null, tint = BlueAccent, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "4. Araç ve Arıza Detayı",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        // Vehicle type chips
                        Text("Araç Tipi:", color = Color.LightGray, fontSize = 12.sp)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            vehicleTypes.forEach { vType ->
                                val isSelected = selectedVehicleType == vType
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { selectedVehicleType = vType },
                                    label = { Text(vType, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = BluePrimary,
                                        selectedLabelColor = Color.White,
                                        containerColor = NavyDark,
                                        labelColor = Color.LightGray
                                    )
                                )
                            }
                        }

                        // Plate input
                        OutlinedTextField(
                            value = plate,
                            onValueChange = { plate = it.uppercase() },
                            label = { Text("Plaka (İsteğe Bağlı)") },
                            placeholder = { Text("34 ABC 123") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BluePrimary,
                                unfocusedBorderColor = Color.Gray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        // Problem Type chips
                        Text("Karşılaştığınız Sorun:", color = Color.LightGray, fontSize = 12.sp)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            problemOptions.forEach { prob ->
                                val isSelected = selectedProblem == prob
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { selectedProblem = prob },
                                    label = { Text(prob, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = if (isTireMode) BluePrimary else StatusError,
                                        selectedLabelColor = Color.White,
                                        containerColor = NavyDark,
                                        labelColor = Color.LightGray
                                    )
                                )
                            }
                        }

                        // Specific Tire Options
                        if (isTireMode) {
                            OutlinedTextField(
                                value = tireDimension,
                                onValueChange = { tireDimension = it },
                                label = { Text("Lastik Ebadı (Biliyorsanız)") },
                                placeholder = { Text("Örn: 205/55 R16") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BluePrimary,
                                    unfocusedBorderColor = Color.Gray,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Stepneniz (Yedek Lastik) Var mı?", color = Color.White, fontSize = 13.sp)
                                    Text(
                                        text = if (hasSpareTire) "Evet, stepne araçta mevcut" else "Hayır, usta lastik getirmeli",
                                        color = if (hasSpareTire) StatusAvailable else StatusWarning,
                                        fontSize = 11.sp
                                    )
                                }
                                Switch(
                                    checked = hasSpareTire,
                                    onCheckedChange = { hasSpareTire = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = StatusAvailable)
                                )
                            }
                        }

                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("Açıklama / Ekstra Notlar") },
                            placeholder = { Text("Örn: Sağ ön lastik patlak, jant hasarlı değil") },
                            minLines = 2,
                            maxLines = 4,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BluePrimary,
                                unfocusedBorderColor = Color.Gray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                    }
                }

                // Error Message if any
                if (errorMessage != null) {
                    Surface(
                        color = StatusError.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Warning, contentDescription = null, tint = StatusError, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(errorMessage!!, color = Color.White, fontSize = 12.sp)
                        }
                    }
                }

                // Submit Button
                Button(
                    onClick = {
                        val trimmedPhone = phone.trim()
                        if (trimmedPhone.isBlank() || trimmedPhone.length < 10) {
                            errorMessage = "Lütfen geçerli bir telefon numarası giriniz (Örn: 0532 123 45 67)."
                            return@Button
                        }
                        if (locationDescription.isBlank()) {
                            errorMessage = "Lütfen bulunduğunuz konumu veya yol tarifini giriniz."
                            return@Button
                        }
                        if (!isGpsActive || customerLat == 0.0 || customerLng == 0.0) {
                            errorMessage = "Gerçek konumunuz alınamadı. Telefonunuzun konumunu (GPS) açıp 'GPS Konumumu Otomatik Al' butonuna basın; çekici/lastikçi sizi bulabilmek için gerçek konumunuza ihtiyaç duyar."
                            return@Button
                        }

                        errorMessage = null
                        isSubmitting = true

                        coroutineScope.launch {
                            try {
                                val created = emergencyRepository.createAnonymousEmergencyRequest(
                                    serviceType = selectedServiceType,
                                    customerPhone = trimmedPhone,
                                    customerName = customerName.ifBlank { "Misafir Sürücü" },
                                    customerLocationName = locationDescription,
                                    customerLat = customerLat,
                                    customerLng = customerLng,
                                    destinationLocationName = if (isTireMode) "Olay Yerinde Mobil Lastik Servisi" else destinationLocation.ifBlank { "Belirtilmedi" },
                                    vehicleType = selectedVehicleType,
                                    plate = plate,
                                    problemType = selectedProblem,
                                    tireDimension = tireDimension,
                                    hasSpareTire = hasSpareTire,
                                    description = description
                                )

                                isSubmitting = false
                                Toast.makeText(context, "Acil çağrınız oluşturuldu, teklifler alınıyor!", Toast.LENGTH_LONG).show()
                                onRequestCreated(created.id)
                            } catch (e: Exception) {
                                isSubmitting = false
                                errorMessage = "Çağrı başlatılamadı: ${e.localizedMessage}"
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("btn_submit_fast_emergency"),
                    enabled = !isSubmitting,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isTireMode) BluePrimary else StatusError
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    if (isSubmitting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = Color.White,
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Anonim Oturum Açılıyor & Bildiriliyor...",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = if (isTireMode) "🛞 ACİL LASTİKÇİ ÇAĞIR & TEKLİFLERİ GÖR" else "🚛 ACİL ÇEKİCİ ÇAĞIR & TEKLİFLERİ GÖR",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
