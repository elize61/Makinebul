package com.example.ui.screens.map

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.RequestQuote
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Machine
import com.example.ui.components.OsmMapView
import com.example.ui.components.OsmMarkerItem
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import com.example.util.LocationUtils
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

enum class MapFilterType(val label: String) {
    ALL("Tümü"),
    MACHINES("🚜 Makineler")
}

data class CityLocation(val name: String, val lat: Double, val lng: Double)

val TURKEY_CITIES = listOf(
    CityLocation("Tümü (Genel)", 40.5, 31.5),
    CityLocation("İstanbul", 41.0082, 28.9784),
    CityLocation("Ankara", 39.9334, 32.8597),
    CityLocation("İzmir", 38.4237, 27.1428),
    CityLocation("Kocaeli / Gebze", 40.8035, 29.4410),
    CityLocation("Bursa", 40.1885, 29.0610),
    CityLocation("Antalya", 36.8969, 30.7133),
    CityLocation("Adana", 37.0000, 35.3213),
    CityLocation("Gaziantep", 37.0662, 37.3833),
    CityLocation("Trabzon", 41.0027, 39.7168)
)

sealed class MapPinItem {
    data class MachinePin(val machine: Machine) : MapPinItem()

    val id: String get() = when (this) {
        is MachinePin -> machine.id
    }
    val title: String get() = when (this) {
        is MachinePin -> machine.title
    }
    val city: String get() = when (this) {
        is MachinePin -> machine.city
    }
    val district: String get() = when (this) {
        is MachinePin -> machine.district
    }
    val latitude: Double get() = when (this) {
        is MachinePin -> machine.latitude
    }
    val longitude: Double get() = when (this) {
        is MachinePin -> machine.longitude
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    machines: List<Machine>,
    onMachineClick: (Machine) -> Unit = {}
) {
    val context = LocalContext.current
    var userLocationText by remember { mutableStateOf<String?>(null) }
    var userLat by remember { mutableStateOf<Double?>(null) }
    var userLng by remember { mutableStateOf<Double?>(null) }
    var isLocating by remember { mutableStateOf(false) }
    var showInteractiveMap by remember { mutableStateOf(true) }
    var selectedFilterType by remember { mutableStateOf(MapFilterType.ALL) }
    var selectedCity by remember { mutableStateOf(TURKEY_CITIES[0]) }
    var selectedPinItem by remember { mutableStateOf<MapPinItem?>(null) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 14f,
        targetValue = 42f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseRadius"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseAlpha"
    )

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false

        if (fineGranted || coarseGranted) {
            isLocating = true
            LocationUtils.getCurrentLocation(
                context = context,
                onSuccess = { lat, lng ->
                    isLocating = false
                    userLat = lat
                    userLng = lng
                    userLocationText = "Anlık Konum: %.4f, %.4f".format(lat, lng)
                    Toast.makeText(context, "📍 GPS Konumunuz alındı!", Toast.LENGTH_SHORT).show()
                },
                onError = { msg ->
                    isLocating = false
                    Toast.makeText(context, "⚠️ $msg", Toast.LENGTH_SHORT).show()
                }
            )
        } else {
            Toast.makeText(context, "⚠️ Konum izni gereklidir.", Toast.LENGTH_SHORT).show()
        }
    }

    // Filter items based on selected filter tab and city
    val pinItems = remember(machines, selectedFilterType, selectedCity) {
        val list = mutableListOf<MapPinItem>()

        if (selectedFilterType == MapFilterType.ALL || selectedFilterType == MapFilterType.MACHINES) {
            val validMachines = machines.filter { it.latitude != 0.0 && it.longitude != 0.0 }
            val cityFilteredMachines = if (selectedCity.name.startsWith("Tümü")) validMachines else validMachines.filter { it.city.contains(selectedCity.name.split(" ")[0], ignoreCase = true) }
            list.addAll(cityFilteredMachines.map { MapPinItem.MachinePin(it) })
        }

        list
    }

    val osmMarkers = remember(pinItems) {
        pinItems.map { pin ->
            when (pin) {
                is MapPinItem.MachinePin -> OsmMarkerItem(
                    id = pin.machine.id,
                    title = pin.machine.title,
                    snippet = "${pin.machine.city} / ${pin.machine.district}",
                    latitude = pin.machine.latitude,
                    longitude = pin.machine.longitude,
                    isDemand = false,
                    priceText = "₺${pin.machine.hourlyPrice.toInt()}/saat",
                    category = pin.machine.category,
                    originalMachine = pin.machine
                )
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Harita & Canlı Radar", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("${pinItems.size} Nokta Yayında", color = BlueAccent, fontSize = 11.sp)
                    }
                },
                actions = {
                    Surface(
                        onClick = { showInteractiveMap = !showInteractiveMap },
                        shape = RoundedCornerShape(8.dp),
                        color = BluePrimary.copy(alpha = 0.2f),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (showInteractiveMap) Icons.Filled.List else Icons.Filled.Map,
                                contentDescription = null,
                                tint = BluePrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (showInteractiveMap) "Liste" else "Harita",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Filter Controls (Type & City)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NavyDark)
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                // Type Filter Tabs
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MapFilterType.values().forEach { type ->
                        val isSelected = selectedFilterType == type
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (isSelected) BluePrimary else NavyLight,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedFilterType = type }
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = type.label,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // City Selector Horizontal Bar
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(TURKEY_CITIES) { city ->
                        val isSelected = selectedCity.name == city.name
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) BlueAccent else Color(0xFF1E293B),
                            modifier = Modifier.clickable { selectedCity = city }
                        ) {
                            Text(
                                text = city.name,
                                color = if (isSelected) Color.White else Color.LightGray,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }

            // Location Bar with GPS Button
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = NavyDark)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Canlı Radar Konumu",
                            fontSize = 11.sp,
                            color = BlueAccent,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = userLocationText ?: "${selectedCity.name} merkezli radar",
                            fontSize = 12.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Button(
                        onClick = {
                            if (LocationUtils.hasLocationPermission(context)) {
                                isLocating = true
                                LocationUtils.getCurrentLocation(
                                    context = context,
                                    onSuccess = { lat, lng ->
                                        isLocating = false
                                        userLat = lat
                                        userLng = lng
                                        userLocationText = "Anlık GPS: %.4f, %.4f".format(lat, lng)
                                        Toast.makeText(context, "📍 GPS güncellendi", Toast.LENGTH_SHORT).show()
                                    },
                                    onError = { msg ->
                                        isLocating = false
                                        Toast.makeText(context, "⚠️ $msg", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            } else {
                                permissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                    )
                                )
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Icon(Icons.Filled.GpsFixed, contentDescription = null, modifier = Modifier.size(13.dp), tint = Color.Black)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isLocating) "GPS Alınıyor..." else "GPS Konumla",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                }
            }

            // Interactive OpenStreetMap (osmdroid) Pin Map Section
            if (showInteractiveMap) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .padding(horizontal = 16.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(16.dp))
                ) {
                    val targetCenterLat = selectedPinItem?.latitude ?: userLat ?: selectedCity.lat
                    val targetCenterLng = selectedPinItem?.longitude ?: userLng ?: selectedCity.lng

                    OsmMapView(
                        modifier = Modifier.fillMaxSize(),
                        markers = osmMarkers,
                        centerLatitude = targetCenterLat,
                        centerLongitude = targetCenterLng,
                        zoomLevel = if (selectedCity.name.startsWith("Tümü")) 7.5 else 12.0,
                        userLatitude = userLat,
                        userLongitude = userLng,
                        selectedMarkerId = selectedPinItem?.id,
                        onMarkerClick = { clickedMarker ->
                            val foundPin = pinItems.find { it.id == clickedMarker.id }
                            selectedPinItem = foundPin
                        },
                        showZoomControls = true
                    )

                    // Map Legend Header
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                            .background(Color(0xDD0D1B2A), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(StatusAvailable))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Makine (${pinItems.count { it is MapPinItem.MachinePin }})", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Selected Pin Popup Bottom Sheet
                    selectedPinItem?.let { selItem ->
                        Card(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .padding(8.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = NavyDark)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "🚜 MAKİNE",
                                            color = StatusAvailable,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 10.sp
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(selItem.city + " / " + selItem.district, color = Color.LightGray, fontSize = 10.sp)
                                    }
                                    Text(selItem.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
                                    when (selItem) {
                                        is MapPinItem.MachinePin -> {
                                            Text("₺${selItem.machine.dailyPrice.toInt()}/gün • ₺${selItem.machine.hourlyPrice.toInt()}/saat", color = BlueAccent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    when (selItem) {
                                        is MapPinItem.MachinePin -> {
                                            Button(
                                                onClick = { onMachineClick(selItem.machine) },
                                                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text("İncele", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }

                                    IconButton(
                                        onClick = {
                                            com.example.util.MapLauncher.openDirections(context, selItem.latitude, selItem.longitude)
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Filled.Navigation, contentDescription = "Yol Tarifi", tint = BlueAccent, modifier = Modifier.size(18.dp))
                                    }

                                    IconButton(
                                        onClick = { selectedPinItem = null },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Filled.Close, contentDescription = "Kapat", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Results List Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Konumdaki İlanlar & Talepler (${pinItems.size})",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = selectedCity.name,
                    fontSize = 12.sp,
                    color = BluePrimary,
                    fontWeight = FontWeight.Bold
                )
            }

            // List of Items
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (pinItems.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("Bu bölgede seçili filtreye uygun ilan bulunamadı.", color = TextMuted, fontSize = 13.sp)
                            }
                        }
                    }
                } else {
                    items(pinItems) { pinItem ->
                        when (pinItem) {
                            is MapPinItem.MachinePin -> {
                                val machine = pinItem.machine
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onMachineClick(machine) },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(42.dp)
                                                .background(NavyDark, RoundedCornerShape(10.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Construction,
                                                contentDescription = null,
                                                tint = StatusAvailable,
                                                modifier = Modifier.size(22.dp)
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(10.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = machine.title,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "${machine.city} / ${machine.district} • ${machine.category}",
                                                fontSize = 11.sp,
                                                color = TextSecondary
                                            )
                                            Text(
                                                text = "₺${machine.dailyPrice.toInt()}/Gün • ₺${machine.hourlyPrice.toInt()}/Saat",
                                                fontSize = 12.sp,
                                                color = BluePrimary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        Button(
                                            onClick = {
                                                com.example.util.MapLauncher.openDirections(context, machine.latitude, machine.longitude)
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Icon(Icons.Filled.Navigation, contentDescription = null, modifier = Modifier.size(13.dp))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text("Rota", fontSize = 11.sp)
                                        }
                                    }
                                }
                            }

                        }
                    }
                }
            }
        }
    }
}
