package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// MakineBul marka renkleri (koyu lacivert tema)
val NavyDark = Color(0xFF0A1628)       // sayfa arka planı
val NavyLight = Color(0xFF13263F)      // kart yüzeyi
val NavyElevated = Color(0xFF1B3556)   // yükseltilmiş yüzey / seçili alan
val BluePrimary = Color(0xFF3B82F6)    // ana vurgu
val BlueSecondary = Color(0xFF2563EB)
val BlueAccent = Color(0xFF38BDF8)     // ikincil vurgu
val OrangeCta = Color(0xFFF97316)      // acil / dikkat çeken eylemler

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEDF2F7)

// Metin renkleri (koyu zemin üzerinde okunur)
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFFCBD5E1)
val TextMuted = Color(0xFF94A3B8)

// Durum renkleri
val StatusAvailable = Color(0xFF10B981)
val StatusSuccess = Color(0xFF10B981)
val StatusBusy = Color(0xFFF59E0B)
val StatusWarning = Color(0xFFF59E0B)
val StatusError = Color(0xFFEF4444)
val StatusInfo = Color(0xFF3B82F6)
