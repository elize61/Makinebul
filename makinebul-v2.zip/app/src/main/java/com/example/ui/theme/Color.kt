package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// MakineBul Brand Colors
val NavyDark: Color get() = ThemeManager.palette.bg
val NavyLight: Color get() = ThemeManager.palette.surface
val BluePrimary: Color get() = ThemeManager.palette.accent
val BlueSecondary: Color get() = ThemeManager.palette.accent
val BlueAccent: Color get() = ThemeManager.palette.accentLight

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEDF2F7)

val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)
val TextMuted = Color(0xFF94A3B8)

// Status colors
val StatusAvailable = Color(0xFF10B981)
val StatusSuccess = Color(0xFF10B981)
val StatusBusy = Color(0xFFF59E0B)
val StatusWarning = Color(0xFFF59E0B)
val StatusError = Color(0xFFEF4444)
val StatusInfo = Color(0xFF3B82F6)
