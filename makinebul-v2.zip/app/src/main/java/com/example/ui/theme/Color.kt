package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// MakineBul Brand Colors
val NavyDark = Color(0xFF0B192C)
val NavyLight = Color(0xFF1E3E62)
val BluePrimary = Color(0xFF0066FF)
val BlueSecondary = Color(0xFF1E88E5)
val BlueAccent = Color(0xFF38BDF8)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEDF2F7)

val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF475569)
val TextMuted = Color(0xFF94A3B8)

// Status colors
val StatusAvailable = Color(0xFF10B981)
val StatusSuccess = Color(0xFF10B981)
val StatusBusy = Color(0xFFF59E0B)
val StatusWarning = Color(0xFFF59E0B)
val StatusError = Color(0xFFEF4444)
val StatusInfo = Color(0xFF3B82F6)
