package com.example.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Note
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ServiceProviderApplication
import com.example.data.model.User
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.StatusAvailable

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProviderApplicationScreen(
    currentUser: User?,
    onBackClick: () -> Unit,
    onSubmitApplication: (ServiceProviderApplication) -> Unit
) {
    var requestedRole by remember { mutableStateOf("OWNER") } // "OWNER", "DUTY_TOW", "DUTY_TIRE"
    var companyName by remember { mutableStateOf("") }
    var taxNumber by remember { mutableStateOf("") }
    var city by remember { mutableStateOf(currentUser?.city?.ifEmpty { "İstanbul" } ?: "İstanbul") }
    var district by remember { mutableStateOf(currentUser?.district?.ifEmpty { "Ümraniye" } ?: "Ümraniye") }
    var note by remember { mutableStateOf("") }
    var isSubmitted by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Hizmet Sağlayıcı Başvurusu", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Geri", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (isSubmitted) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NavyDark),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("✅", fontSize = 48.sp)
                        Text("Başvurunuz Alındı!", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text(
                            "Başvurunuz yöneticilerimiz tarafından incelendikten sonra hesabınıza ilgili rol tanımı yapılacaktır.",
                            color = Color.LightGray,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                        Button(
                            onClick = onBackClick,
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Tamam", color = Color.White)
                        }
                    }
                }
            } else {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text("Başvuru Türü Seçin", fontWeight = FontWeight.Bold, fontSize = 16.sp)

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(
                                    selected = requestedRole == "OWNER",
                                    onClick = { requestedRole = "OWNER" },
                                    colors = RadioButtonDefaults.colors(selectedColor = BluePrimary)
                                )
                                Column {
                                    Text("🚜 İş Makinesi Sahibi (İlan Veren)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Ekskavatör, kepçe vb. makinelerimi kiralamak istiyorum", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(
                                    selected = requestedRole == "DUTY_TOW",
                                    onClick = { requestedRole = "DUTY_TOW" },
                                    colors = RadioButtonDefaults.colors(selectedColor = BluePrimary)
                                )
                                Column {
                                    Text("🚛 Oto Çekici Hizmet Sağlayıcısı", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("7/24 Acil kurtarma & çekici hizmeti sunuyorum", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(
                                    selected = requestedRole == "DUTY_TIRE",
                                    onClick = { requestedRole = "DUTY_TIRE" },
                                    colors = RadioButtonDefaults.colors(selectedColor = BluePrimary)
                                )
                                Column {
                                    Text("🛞 Mobil Lastikçi Servis Sağlayıcısı", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Mobil araçla yerinde lastik tamir & sökme takma yapıyorum", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Firma / Şahıs Bilgileri", fontWeight = FontWeight.Bold, fontSize = 16.sp)

                        OutlinedTextField(
                            value = companyName,
                            onValueChange = { companyName = it },
                            label = { Text("Firma veya İşletme Adı") },
                            leadingIcon = { Icon(Icons.Filled.Business, contentDescription = null, tint = BluePrimary) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = taxNumber,
                            onValueChange = { taxNumber = it },
                            label = { Text("Vergi Numarası / T.C. Kimlik No") },
                            leadingIcon = { Icon(Icons.Filled.Receipt, contentDescription = null, tint = BluePrimary) },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = city,
                                onValueChange = { city = it },
                                label = { Text("İl") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                            OutlinedTextField(
                                value = district,
                                onValueChange = { district = it },
                                label = { Text("İlçe") },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            )
                        }

                        OutlinedTextField(
                            value = note,
                            onValueChange = { note = it },
                            label = { Text("Açıklama / Ek Notlar") },
                            leadingIcon = { Icon(Icons.Filled.Note, contentDescription = null, tint = BluePrimary) },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2,
                            shape = RoundedCornerShape(10.dp)
                        )

                        Button(
                            onClick = {
                                val app = ServiceProviderApplication(
                                    id = "app_${System.currentTimeMillis()}",
                                    userId = currentUser?.id ?: "user_1",
                                    userName = currentUser?.fullName ?: "Kullanıcı",
                                    userPhone = currentUser?.phone ?: "",
                                    userEmail = currentUser?.email ?: "",
                                    requestedRole = requestedRole,
                                    companyName = companyName,
                                    taxNumber = taxNumber,
                                    city = city,
                                    district = district,
                                    note = note
                                )
                                onSubmitApplication(app)
                                isSubmitted = true
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("btn_submit_provider_application"),
                            colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Başvuruyu Gönder", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}
