package com.example.ui.screens.emergency

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material.icons.filled.Edit
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EmergencyRequest
import com.example.data.model.EmergencyServiceType
import com.example.data.model.EmergencyStatus
import com.example.data.model.User
import com.example.data.model.UserType
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusWarning

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TowTruckDutyScreen(
    currentUser: User?,
    isOnDuty: Boolean,
    pendingRequests: List<EmergencyRequest>,
    activeMission: EmergencyRequest?,
    onBackClick: () -> Unit,
    onToggleDuty: (Boolean) -> Unit,
    onAcceptRequest: (String) -> Unit,
    onRejectRequest: (String) -> Unit,
    onUpdateMissionStatus: (requestId: String, status: EmergencyStatus) -> Unit,
    onNavigateToChat: (customerId: String, customerName: String) -> Unit,
    onSendPriceOffer: ((requestId: String, price: Double) -> Unit)? = null,
    onSaveShopAddress: suspend (String) -> String = { "" }
) {
    val context = LocalContext.current
    val isProviderRole = currentUser?.userType == UserType.DUTY_TOW || currentUser?.userType == UserType.DUTY_TIRE || currentUser?.userType == UserType.ADMIN
    val isTireRole = currentUser?.userType == UserType.DUTY_TIRE
    val isTowRole = currentUser?.userType == UserType.DUTY_TOW

    // STRICT ROLE SEPARATION: Tow truck operators only see Tow requests, Tire operators only see Tire requests
    val filteredPendingRequests = remember(pendingRequests, currentUser?.userType) {
        pendingRequests.filter { req ->
            if (isTowRole) {
                req.serviceType == EmergencyServiceType.TOW_TRUCK
            } else if (isTireRole) {
                req.serviceType == EmergencyServiceType.TIRE_SERVICE
            } else {
                true
            }
        }
    }

    val filteredActiveMission = remember(activeMission, currentUser?.userType) {
        activeMission?.takeIf { mission ->
            if (isTowRole) {
                mission.serviceType == EmergencyServiceType.TOW_TRUCK
            } else if (isTireRole) {
                mission.serviceType == EmergencyServiceType.TIRE_SERVICE
            } else {
                true
            }
        }
    }

    var isCurrentlyActive by remember(isOnDuty) { mutableStateOf(isOnDuty) } // "ŞU AN HİZMET VERİYORUM"
    val addressScope = rememberCoroutineScope()
    var showAddressDialog by remember { mutableStateOf(false) }
    var addressInput by remember(currentUser?.address) { mutableStateOf(currentUser?.address ?: "") }
    var isSavingAddress by remember { mutableStateOf(false) }
    val hasShopAddress = !currentUser?.address.isNullOrBlank()

    if (showAddressDialog) {
        AlertDialog(
            onDismissRequest = { if (!isSavingAddress) showAddressDialog = false },
            title = { Text("Dükkan / Çıkış Adresi") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Tam adresi yazın (mahalle, cadde/sokak, no, ilçe, il). Çağrılar bu adrese göre size eşleştirilir ve haritada bu konum kullanılır.",
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = addressInput,
                        onValueChange = { addressInput = it },
                        label = { Text("Açık adres") },
                        minLines = 3,
                        enabled = !isSavingAddress,
                        modifier = Modifier.fillMaxWidth().testTag("input_shop_address")
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = !isSavingAddress && addressInput.isNotBlank(),
                    onClick = {
                        isSavingAddress = true
                        addressScope.launch {
                            val msg = onSaveShopAddress(addressInput)
                            isSavingAddress = false
                            if (msg.isNotBlank()) Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            if (msg.startsWith("✅")) showAddressDialog = false
                        }
                    }
                ) { Text(if (isSavingAddress) "Konum aranıyor..." else "Kaydet") }
            },
            dismissButton = {
                TextButton(enabled = !isSavingAddress, onClick = { showAddressDialog = false }) { Text("Vazgeç") }
            }
        )
    }
    var selectedOfferRequestId by remember { mutableStateOf<String?>(null) }
    var offerPriceText by remember { mutableStateOf("1500") }

    val currentOfferRequest = filteredPendingRequests.find { it.id == selectedOfferRequestId }

    if (selectedOfferRequestId != null && currentOfferRequest != null) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { selectedOfferRequestId = null },
            title = {
                Text(
                    text = "💰 Fiyat Teklifi Gönder",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.verticalScroll(rememberScrollState())
                ) {
                    // Summary card
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = NavyDark,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("👤 Müşteri: ${currentOfferRequest.customerName}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("🚗 Araç: ${currentOfferRequest.vehicleType} • ${currentOfferRequest.plate.ifBlank { "Plakasız" }}", color = BlueAccent, fontSize = 12.sp)
                            Text("📍 Nereden: ${currentOfferRequest.customerLocationName}", color = Color.LightGray, fontSize = 12.sp)
                            if (currentOfferRequest.destinationLocationName.isNotBlank()) {
                                Text("🚩 Nereye: ${currentOfferRequest.destinationLocationName}", color = StatusWarning, fontSize = 12.sp)
                            }
                            Text("⚠️ Sorun: ${currentOfferRequest.problemType}", color = StatusError, fontSize = 12.sp)
                            if (currentOfferRequest.description.isNotBlank()) {
                                Text("📝 Not: ${currentOfferRequest.description}", color = Color.LightGray, fontSize = 11.sp)
                            }
                        }
                    }

                    Text(
                        text = "Müşteriye teklif edeceğiniz toplam hizmet tutarını girin:",
                        fontSize = 13.sp
                    )

                    androidx.compose.material3.OutlinedTextField(
                        value = offerPriceText,
                        onValueChange = { offerPriceText = it },
                        label = { Text("Teklif Edilen Fiyat (₺)") },
                        leadingIcon = { Text("₺", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(start = 12.dp)) },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val price = offerPriceText.toDoubleOrNull() ?: 1500.0
                        selectedOfferRequestId?.let { reqId ->
                            onSendPriceOffer?.invoke(reqId, price)
                        }
                        selectedOfferRequestId = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Teklifi Gönder", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { selectedOfferRequestId = null }) {
                    Text("İptal")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        val isTire = currentUser?.userType == UserType.DUTY_TIRE
                        Text(
                            text = if (isTire) "🛞 Nöbetçi Lastikçi Paneli" else "🚛 Nöbetçi Çekici Paneli",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = if (isTire) "Sadece Acil Lastik Çağrıları & Yönetimi" else "Sadece Acil Oto Çekici Çağrıları & Yönetimi",
                            color = BlueAccent,
                            fontSize = 11.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Geri", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // PROMINENT "ŞU AN HİZMET VERİYORUM" TOGGLE CARD
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isCurrentlyActive && isOnDuty) NavyDark else Color(0xFF2C3540)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    if (isCurrentlyActive && isOnDuty) StatusAvailable else Color.Gray
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (isCurrentlyActive && isOnDuty) StatusAvailable else Color.Gray,
                                    modifier = Modifier.size(12.dp)
                                ) {}
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isCurrentlyActive && isOnDuty) "🟢 ŞU AN HİZMET VERİYORUM" else "⚫ HİZMET VERMİYORUM",
                                    color = Color.White,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isCurrentlyActive && isOnDuty)
                                    "Canlı GPS aktif. Acil Çekici ve Lastikçi çağrılarını anında alabilirsiniz."
                                else
                                    "Servis kapalı. Yeni acil çağrılar ve canlı konum paylaşımı durduruldu.",
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                        }

                        Switch(
                            checked = isCurrentlyActive && isOnDuty && isProviderRole,
                            enabled = isProviderRole,
                            onCheckedChange = { active ->
                                if (isProviderRole) {
                                    if (active && !hasShopAddress) {
                                        Toast.makeText(context, "Hizmeti açmadan önce dükkan adresinizi girin.", Toast.LENGTH_LONG).show()
                                        showAddressDialog = true
                                    } else {
                                        isCurrentlyActive = active
                                        onToggleDuty(active)
                                    }
                                }
                            },
                            modifier = Modifier.testTag("switch_active_service"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = StatusAvailable,
                                uncheckedThumbColor = Color.LightGray,
                                uncheckedTrackColor = Color.DarkGray
                            )
                        )
                    }

                    if (!isProviderRole) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = StatusWarning.copy(alpha = 0.15f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "⚠️ Müşteri Hesabı: Çekici/mobil lastikçi hizmet aktifliği yalnızca yetkili çekici hizmet sağlayıcıları tarafından değiştirilebilir.",
                                color = StatusWarning,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = BluePrimary.copy(alpha = 0.2f),
                            modifier = Modifier.padding(vertical = 2.dp)
                        ) {
                            Text(
                                text = "🚛 Acil Çekici",
                                color = BlueAccent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = StatusAvailable.copy(alpha = 0.2f),
                            modifier = Modifier.padding(vertical = 2.dp)
                        ) {
                            Text(
                                text = "🛞 Mobil Lastikçi",
                                color = StatusAvailable,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = (if (hasShopAddress) StatusAvailable else StatusWarning).copy(alpha = 0.15f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showAddressDialog = true }
                            .testTag("card_shop_address")
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.LocationOn,
                                contentDescription = null,
                                tint = if (hasShopAddress) StatusAvailable else StatusWarning,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Dükkan Adresi",
                                    color = Color.LightGray,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = if (hasShopAddress) currentUser?.address.orEmpty() else "Adres girilmedi. Eklemek için dokunun",
                                    color = if (hasShopAddress) Color.White else StatusWarning,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Filled.Edit,
                                contentDescription = "Adresi düzenle",
                                tint = Color.LightGray,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // ACTIVE MISSION SECTION ("AKTİF GÖREV")
            if (filteredActiveMission != null) {
                val activeMission = filteredActiveMission
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(2.dp, BluePrimary),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (activeMission.serviceType == EmergencyServiceType.TIRE_SERVICE) "🛞 AKTİF LASTİKÇİ GÖREVİ" else "🚨 AKTİF ÇEKİCİ GÖREVİ",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = StatusError
                            )

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = BluePrimary
                            ) {
                                Text(
                                    text = activeMission.status.labelTr,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        // Customer Details
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Müşteri: ${activeMission.customerName}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "📍 Konum: ${activeMission.customerLocationName}",
                                fontSize = 13.sp
                            )
                            if (activeMission.serviceType == EmergencyServiceType.TIRE_SERVICE) {
                                Text(
                                    text = "🛞 Sorun: ${activeMission.problemType} ${if (activeMission.tireDimension.isNotBlank()) "(${activeMission.tireDimension})" else ""}",
                                    fontSize = 13.sp,
                                    color = StatusError,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "⚙️ Stepne: ${if (activeMission.hasSpareTire) "Var (Değişim isteniyor)" else "Yok (Mobil tamir isteniyor)"}",
                                    fontSize = 12.sp
                                )
                            } else {
                                Text(
                                    text = "🚩 Hedef: ${activeMission.destinationLocationName}",
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "⚠️ Sorun: ${activeMission.problemType}",
                                    fontSize = 12.sp
                                )
                            }
                            Text(
                                text = "🚗 Araç: ${activeMission.vehicleType} • Plaka: ${activeMission.plate}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Navigation to Customer Button
                        Button(
                            onClick = {
                                com.example.util.MapLauncher.openDirections(context, activeMission.customerLat, activeMission.customerLng)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("btn_navigate_to_customer"),
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Filled.Navigation, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "🗺️ MÜŞTERİ KONUMUNA GİT (NAVİGASYON)",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 13.sp,
                                    color = Color.White
                                )
                            }
                        }

                        // Call & Chat with Customer
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    val intent = Intent(Intent.ACTION_DIAL).apply {
                                        data = Uri.parse("tel:${activeMission.customerPhone}")
                                    }
                                    context.startActivity(intent)
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable)
                            ) {
                                Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Müşteriyi Ara", fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = {
                                    onNavigateToChat(activeMission.customerId, activeMission.customerName)
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Filled.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Mesaj At", fontSize = 12.sp)
                            }
                        }

                        // Step Buttons
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = when (activeMission.status) {
                                EmergencyStatus.ARRIVING -> BluePrimary.copy(alpha = 0.15f)
                                EmergencyStatus.ARRIVED -> StatusWarning.copy(alpha = 0.15f)
                                EmergencyStatus.IN_SERVICE -> Color(0xFFF97316).copy(alpha = 0.15f)
                                EmergencyStatus.COMPLETED -> StatusAvailable.copy(alpha = 0.15f)
                                else -> BluePrimary.copy(alpha = 0.1f)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = when (activeMission.status) {
                                    EmergencyStatus.ARRIVING -> "🚗 Müşteriye Doğru Yoldasınız (Tahmini: ${activeMission.estimatedTimeMinutes} dk)"
                                    EmergencyStatus.ARRIVED -> "📍 Olay Yerine Vardınız (Müşteriyle buluşun)"
                                    EmergencyStatus.IN_SERVICE -> "🔧 Çekme / Lastik Onarımı Devam Ediyor"
                                    EmergencyStatus.COMPLETED -> "✅ Görev Başarıyla Tamamlandı"
                                    else -> "Durum: ${activeMission.status.labelTr}"
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = when (activeMission.status) {
                                    EmergencyStatus.ARRIVING -> BluePrimary
                                    EmergencyStatus.ARRIVED -> StatusWarning
                                    EmergencyStatus.IN_SERVICE -> Color(0xFFC2410C)
                                    EmergencyStatus.COMPLETED -> StatusAvailable
                                    else -> BluePrimary
                                },
                                modifier = Modifier.padding(8.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }

                        Text(
                            text = "Görev Durumunu Değiştir / İlerlet:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    onUpdateMissionStatus(activeMission.id, EmergencyStatus.ARRIVING)
                                    Toast.makeText(context, "🚗 Durum 'Yola Çıktım' olarak güncellendi ve müşteriye bildirildi.", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (activeMission.status == EmergencyStatus.ARRIVING) BluePrimary else Color.DarkGray
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("1. YOLA ÇIKTIM", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }

                            Button(
                                onClick = {
                                    onUpdateMissionStatus(activeMission.id, EmergencyStatus.ARRIVED)
                                    Toast.makeText(context, "📍 Olay yerine varışınız kaydedildi.", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (activeMission.status == EmergencyStatus.ARRIVED) StatusWarning else Color.DarkGray
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("2. VARDIM", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    onUpdateMissionStatus(activeMission.id, EmergencyStatus.IN_SERVICE)
                                    Toast.makeText(context, "🔧 Hizmet/Çekim işlemi başlatıldı.", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (activeMission.status == EmergencyStatus.IN_SERVICE) Color(0xFFEA580C) else Color.DarkGray
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("3. HİZMET BAŞLADI", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }

                            Button(
                                onClick = {
                                    onUpdateMissionStatus(activeMission.id, EmergencyStatus.COMPLETED)
                                    Toast.makeText(context, "✅ Hizmet tamamlandı olarak işaretlendi.", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (activeMission.status == EmergencyStatus.COMPLETED) StatusAvailable else StatusAvailable.copy(alpha = 0.8f)
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("4. TAMAMLANDI ✅", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }

            // PENDING EMERGENCY CALLS LIST
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Gelen Acil Çağrılar (${if (!isOnDuty || !isCurrentlyActive) 0 else pendingRequests.size})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )

                if (!isOnDuty || !isCurrentlyActive) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = StatusError.copy(alpha = 0.15f)
                    ) {
                        Text(
                            text = "🔴 ÇAĞRI ALIMI KAPALI",
                            color = StatusError,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            if (!isOnDuty || !isCurrentlyActive) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, StatusError.copy(alpha = 0.6f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("⛔", fontSize = 36.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Hizmet Verme Durumunuz Kapalı",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = StatusError
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isTowRole) {
                                "Şu anda müşterilerden gelen acil oto çekici çağrılarını almıyorsunuz. Çağrıları kabul etmek için yukarıdaki anahtardan hizmeti aktif edin."
                            } else if (isTireRole) {
                                "Şu anda müşterilerden gelen acil mobil lastikçi çağrılarını almıyorsunuz. Çağrıları kabul etmek için yukarıdaki anahtardan hizmeti aktif edin."
                            } else {
                                "Şu anda müşterilerden gelen acil çağrıları almıyorsunuz. Çağrıları kabul etmek için yukarıdaki anahtardan hizmeti aktif edin."
                            },
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else if (filteredPendingRequests.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("📬", fontSize = 36.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (isTowRole) "Şu anda bekleyen acil çekici çağrısı yok." else if (isTireRole) "Şu anda bekleyen acil lastik çağrısı yok." else "Şu anda bekleyen acil çağrı yok.",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = if (isTowRole) "Sistem sadece oto çekici çağrılarını dinliyor." else if (isTireRole) "Sistem sadece mobil lastik çağrılarını dinliyor." else "Sistem arka planda bölgenizdeki çağrıları dinliyor.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp
                        )
                    }
                }
            } else {
                filteredPendingRequests.forEach { req ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StatusError.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Header badge and distance
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = StatusError.copy(alpha = 0.15f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = if (req.serviceType == EmergencyServiceType.TIRE_SERVICE) "🛞 ACİL LASTİK" else "🚛 ACİL ÇEKİCİ",
                                            color = StatusError,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = BluePrimary.copy(alpha = 0.12f)
                                ) {
                                    Text(
                                        text = "📍 Yaklaşık ${req.estimatedDistanceKm} km",
                                        color = BluePrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            // Customer & Phone
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = req.customerName,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 16.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = req.customerPhone,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${req.customerPhone}"))
                                        context.startActivity(intent)
                                    },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(StatusAvailable.copy(alpha = 0.15f), CircleShape)
                                ) {
                                    Icon(Icons.Filled.Call, contentDescription = "Ara", tint = StatusAvailable, modifier = Modifier.size(18.dp))
                                }
                            }

                            // Vehicle & Plate Card
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("🚗", fontSize = 16.sp)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Araç Tipi: ${req.vehicleType}",
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp
                                        )
                                    }

                                    if (req.plate.isNotBlank()) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = Color.White,
                                            border = androidx.compose.foundation.BorderStroke(1.dp, Color.Black)
                                        ) {
                                            Text(
                                                text = req.plate.uppercase(),
                                                color = Color.Black,
                                                fontWeight = FontWeight.ExtraBold,
                                                fontSize = 11.sp,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            // Pickup Location (Nereden)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "📍 Alınacak Konum (Mevcut Yer):",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = BluePrimary
                                    )
                                    Text(
                                        text = req.customerLocationName,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                OutlinedButton(
                                    onClick = {
                                        com.example.util.MapLauncher.openLocation(context, req.customerLat, req.customerLng, "Müşteri")
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(32.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Icon(Icons.Filled.Map, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Harita", fontSize = 11.sp, color = BluePrimary)
                                }
                            }

                            // Destination (Varış/Çekilecek Yer)
                            if (req.destinationLocationName.isNotBlank()) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = StatusWarning.copy(alpha = 0.12f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("🚩", fontSize = 14.sp)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Column {
                                            Text(
                                                text = "Varış / Çekilecek Yer:",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                color = Color(0xFFB45309)
                                            )
                                            Text(
                                                text = req.destinationLocationName,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                    }
                                }
                            }

                            // Problem & Tire Info
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = StatusError.copy(alpha = 0.08f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("⚠️", fontSize = 13.sp)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Sorun / Arıza: ${req.problemType}",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = StatusError
                                        )
                                    }

                                    if (req.serviceType == EmergencyServiceType.TIRE_SERVICE) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        if (req.tireDimension.isNotBlank()) {
                                            Text("• Lastik Ebadı: ${req.tireDimension}", fontSize = 12.sp)
                                        }
                                        Text(
                                            text = if (req.hasSpareTire) "• Stepne: Var (Değişim Yapılacak)" else "• Stepne: Yok (Yerinde Tamir / Yama Gerekli)",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (req.hasSpareTire) StatusAvailable else StatusError
                                        )
                                    }
                                }
                            }

                            // Customer Description
                            if (req.description.isNotBlank()) {
                                Text(
                                    text = "💬 Açıklama: ${req.description}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                )
                            }

                            val myDriverId = currentUser?.id?.takeIf { it.isNotBlank() } ?: "tow_driver_1"
                            val myOffer = req.offers.find { it.driverId == myDriverId } ?: if (req.assignedDriverId == myDriverId && req.agreedPrice != null) {
                                com.example.data.model.EmergencyDriverOffer(
                                    driverId = myDriverId,
                                    price = req.agreedPrice ?: 0.0,
                                    isAcceptedByCustomer = req.priceStatus == "CUSTOMER_ACCEPTED" || req.priceStatus == "ACCEPTED"
                                )
                            } else null

                            val isMyOfferAccepted = myOffer?.isAcceptedByCustomer == true ||
                                    (req.assignedDriverId == myDriverId && (req.priceStatus == "CUSTOMER_ACCEPTED" || req.priceStatus == "ACCEPTED"))

                            // Status Banner based on state
                            if (isMyOfferAccepted) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color(0xFF064E3B),
                                    modifier = Modifier.fillMaxWidth(),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, StatusAvailable)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(
                                            text = "🎉 MÜŞTERİ TEKLİFİNİZİ ONAYLADI (${myOffer?.price?.toInt() ?: req.agreedPrice?.toInt()} ₺)",
                                            color = StatusAvailable,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "Müşteri teklifinizi seçti. Göreve başlamak ve müşteriye doğru yola çıkmak için aşağıdaki butona dokunun.",
                                            color = Color.White,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            } else if (myOffer != null) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = StatusWarning.copy(alpha = 0.2f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "⏳ ${myOffer.price.toInt()} ₺ Teklifiniz Müşteriye İletildi (Müşteri Onayı Bekleniyor)",
                                        color = Color(0xFFB45309),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(8.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            } else {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = BluePrimary.copy(alpha = 0.1f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "📬 Müşteri fiyat teklifi bekliyor. Teklifinizi iletin.",
                                        color = BluePrimary,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(6.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }

                            // Action buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (isMyOfferAccepted) {
                                    Button(
                                        onClick = { onAcceptRequest(req.id) },
                                        modifier = Modifier
                                            .weight(1.5f)
                                            .testTag("btn_start_mission_${req.id}"),
                                        colors = ButtonDefaults.buttonColors(containerColor = StatusAvailable),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("🚀 GÖREVE BAŞLA & YOLA ÇIK", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.White)
                                    }

                                    OutlinedButton(
                                        onClick = { onNavigateToChat(req.customerId, req.customerName) },
                                        modifier = Modifier.weight(0.8f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("💬 MESAJ", fontSize = 11.sp)
                                    }
                                } else {
                                    Button(
                                        onClick = {
                                            offerPriceText = myOffer?.price?.toInt()?.toString() ?: "1500"
                                            selectedOfferRequestId = req.id
                                        },
                                        modifier = Modifier
                                            .weight(1.2f)
                                            .testTag("btn_offer_call_${req.id}"),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (myOffer != null) Color(0xFFF59E0B) else StatusWarning
                                        ),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text(
                                            text = if (myOffer != null) "✏️ TEKLİFİ GÜNCELLE" else "💰 FİYAT TEKLİFİ VER",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = Color.Black
                                        )
                                    }

                                    OutlinedButton(
                                        onClick = { onNavigateToChat(req.customerId, req.customerName) },
                                        modifier = Modifier.weight(0.7f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("💬 MESAJ", fontSize = 11.sp)
                                    }

                                    OutlinedButton(
                                        onClick = { onRejectRequest(req.id) },
                                        modifier = Modifier.weight(0.6f),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Gray)
                                    ) {
                                        Text("PAS GEÇ", fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
