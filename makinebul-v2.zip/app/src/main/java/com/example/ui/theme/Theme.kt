package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private fun buildScheme(theme: AppTheme) = if (theme == AppTheme.LIGHT) {
    val p = ThemeManager.paletteOf(theme)
    lightColorScheme(
        primary = p.accent,
        onPrimary = Color.White,
        primaryContainer = Color(0xFFFFEDD5),
        onPrimaryContainer = Color(0xFF7C2D12),
        secondary = p.accentLight,
        onSecondary = Color.White,
        background = BackgroundLight,
        onBackground = TextPrimary,
        surface = SurfaceLight,
        onSurface = TextPrimary,
        surfaceVariant = SurfaceVariantLight,
        onSurfaceVariant = TextSecondary
    )
} else {
    val p = ThemeManager.paletteOf(theme)
    darkColorScheme(
        primary = p.accent,
        onPrimary = Color.White,
        primaryContainer = p.surface,
        onPrimaryContainer = Color.White,
        secondary = p.accentLight,
        onSecondary = p.bg,
        background = p.bg,
        onBackground = Color.White,
        surface = p.surface,
        onSurface = Color.White,
        surfaceVariant = p.bg,
        onSurfaceVariant = TextMuted
    )
}

@Composable
fun MakineBulTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use intentional MakineBul brand theme by default
    content: @Composable () -> Unit
) {
    val appTheme = ThemeManager.current
    val isLightTheme = appTheme == AppTheme.LIGHT
    val colorScheme = buildScheme(appTheme)

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = (if (isLightTheme) Color(0xFFF8FAFC) else ThemeManager.palette.bg).toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = isLightTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MakineBulTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}

