# v3.8 - Google girişi düzeltmesi

- Google ile giriş "yapılandırılmamış" hatası veriyordu. Kaynak paketi (namespace com.example) ile uygulama kimliği (com.reisgamestudio.makinebul) farklı olduğu için web client id bulunamıyordu. Artık her iki paket adıyla da aranıyor.

