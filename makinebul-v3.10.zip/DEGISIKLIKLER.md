# v3.10 - Play sürümünde Google girişi düzeltmesi

- Play'den yüklenen (release) sürümde Google ile giriş "yapılandırılmamış" hatası veriyordu. Release derlemesi kaynak küçültme yaptığı için Google girişinin okuduğu `default_web_client_id` kaynağı APK'dan siliniyordu. `res/raw/keep.xml` ile bu kaynaklar korunuyor.
- Sürüm: 3.10

