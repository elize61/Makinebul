package com.example.ui.screens.auth

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NavyLight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

private val AmberCta = Color(0xFFFBA81F)
private val EmergencyRed = Color(0xFF7F1D2D)
private val EmergencyBorder = Color(0xFFEF4444)

private fun Context.findActivity(): Context {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return this
}

/**
 * İlk açılış ekranı. Girişe zorlamaz.
 * Google modu: 0 = yalnızca giriş (müşteri), 1 = ilan veren olarak, 2 = çekici/lastikçi başvurusu için.
 */
@Composable
fun WelcomeScreen(
    onQuickRegister: suspend (fullName: String, phone: String, email: String, pass: String, role: String) -> Result<Unit>,
    onGoogleSignIn: suspend (activityContext: Context, role: String?) -> Result<Unit>,
    onOwnerReady: () -> Unit,
    onProviderReady: () -> Unit,
    onSignedIn: () -> Unit,
    onBrowseAsGuest: () -> Unit,
    onEmergency: () -> Unit,
    onLogin: () -> Unit,
    onOpenPrivacy: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showOwnerDialog by remember { mutableStateOf(false) }
    var googleBusy by remember { mutableStateOf(false) }
    var showGoogleRoleDialog by remember { mutableStateOf(false) }

    fun startGoogle(role: String?) {
        if (googleBusy) return
        googleBusy = true
        scope.launch {
            val r = onGoogleSignIn(context.findActivity(), role)
            googleBusy = false
            r.fold(
                onSuccess = {
                    when (role) {
                        null, "CUSTOMER" -> onSignedIn()
                        "OWNER" -> onOwnerReady()
                        else -> onProviderReady()
                    }
                },
                onFailure = { Toast.makeText(context, it.message ?: "Google girişi yapılamadı.", Toast.LENGTH_LONG).show() }
            )
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0E1D38), NavyDark)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Filled.Construction, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(56.dp))
            Text("MakineBul", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
            Text("İş Makinesi & Özel Araç Platformu", color = BlueAccent, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(96.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF1B3556), Color(0xFF3A2A12), Color(0xFF1B3556)))),
                contentAlignment = Alignment.Center
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(22.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Engineering, null, tint = AmberCta, modifier = Modifier.size(40.dp))
                    Icon(Icons.Filled.Construction, null, tint = AmberCta, modifier = Modifier.size(52.dp))
                    Icon(Icons.Filled.LocalShipping, null, tint = AmberCta, modifier = Modifier.size(48.dp))
                    Icon(Icons.Filled.DirectionsCar, null, tint = AmberCta, modifier = Modifier.size(40.dp))
                }
            }

            Spacer(Modifier.height(14.dp))
            Text("Makinen veya Hizmet Aracın mı Var?", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text(
                "Ücretsiz ilanını ekle, bölgedeki müşterilere anında ulaş, işini büyüt!",
                color = TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(14.dp))

            Button(
                onClick = { showOwnerDialog = true },
                modifier = Modifier.fillMaxWidth().height(62.dp).testTag("welcome_add_machine"),
                shape = RoundedCornerShape(32.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AmberCta, contentColor = Color(0xFF111827))
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("MAKİNENİ VEYA ARACINI EKLE", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    Text("Ücretsiz Esnaf / Sahip Kaydı", fontSize = 12.sp, maxLines = 1)
                }
            }
            Spacer(Modifier.height(10.dp))

            Button(
                onClick = onBrowseAsGuest,
                modifier = Modifier.fillMaxWidth().height(62.dp).testTag("welcome_browse"),
                shape = RoundedCornerShape(32.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NavyElevated, contentColor = Color.White)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("ÜYE OLMADAN İLANLARA GÖZ AT", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    Text("Makine ve Hizmet Ara", fontSize = 12.sp, maxLines = 1, color = TextSecondary)
                }
            }
            Spacer(Modifier.height(18.dp))

            Surface(
                onClick = onEmergency,
                modifier = Modifier.fillMaxWidth().testTag("welcome_emergency"),
                shape = RoundedCornerShape(14.dp),
                color = EmergencyRed,
                border = BorderStroke(1.5.dp, EmergencyBorder)
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🚨", fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Text("YOLDA MI KALDINIZ?", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "ÜYE OLMADAN",
                            modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(AmberCta).padding(horizontal = 6.dp, vertical = 2.dp),
                            color = Color(0xFF111827), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Hemen Çekici veya Lastikçi çağırın  →", color = Color.White, fontSize = 15.sp)
                }
            }
            Spacer(Modifier.height(12.dp))

            if (showGoogleRoleDialog) {
                AlertDialog(
                    onDismissRequest = { showGoogleRoleDialog = false },
                    containerColor = NavyLight,
                    title = { Text("Hesap türünü seçin", color = Color.White, fontWeight = FontWeight.Bold) },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Google ile hangi hesap türünde devam etmek istersiniz?", color = TextSecondary, fontSize = 13.sp)
                            listOf(
                                "CUSTOMER" to "Müşteri (hizmet alan)",
                                "OWNER" to "Makine / Araç Sahibi",
                                "DUTY_TOW" to "Çekici",
                                "DUTY_TIRE" to "Lastikçi"
                            ).forEach { (role, label) ->
                                RoleOption(label, false, Modifier.fillMaxWidth()) {
                                    showGoogleRoleDialog = false
                                    startGoogle(role)
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { showGoogleRoleDialog = false }) {
                            Text("Vazgeç", color = TextSecondary)
                        }
                    }
                )
            }

            Button(
                onClick = { showGoogleRoleDialog = true },
                enabled = !googleBusy,
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("welcome_google"),
                shape = RoundedCornerShape(32.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF111827), disabledContainerColor = Color(0xFFE5E7EB))
            ) {
                if (googleBusy) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color(0xFF111827))
                } else {
                    GoogleG()
                    Spacer(Modifier.width(10.dp))
                    Text("Google ile Tek Tıkla Devam Et", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
            Spacer(Modifier.height(14.dp))

            TextButton(onClick = onOpenPrivacy) {
                Text("Devam ederek Aydınlatma Metni'ni kabul etmiş olursunuz", color = TextMuted, fontSize = 11.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Text("Zaten hesabın var mı? ", color = TextMuted, fontSize = 14.sp)
                Text(
                    "Giriş Yap",
                    color = Color.White,
                    fontSize = 14.sp,
                    textDecoration = TextDecoration.Underline,
                    modifier = Modifier.clickable(onClick = onLogin).padding(vertical = 8.dp).testTag("welcome_login")
                )
            }
        }
    }

    if (showOwnerDialog) {
        QuickOwnerDialog(
            googleBusy = googleBusy,
            onDismiss = { showOwnerDialog = false },
            onSubmit = onQuickRegister,
            onSuccess = { r ->
                showOwnerDialog = false
                if (r == "OWNER") onOwnerReady() else onProviderReady()
            },
            onGoogle = { r ->
                showOwnerDialog = false
                startGoogle(r)
            },
            onOpenPrivacy = onOpenPrivacy
        )
    }
}

@Composable
private fun GoogleG() {
    Box(
        modifier = Modifier.size(24.dp).clip(CircleShape).background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Text("G", color = Color(0xFF4285F4), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun RoleOption(label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = if (selected) AmberCta else NavyElevated
    ) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp),
            color = if (selected) Color(0xFF111827) else Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Hızlı kayıt penceresi. Rol doğrudan seçilir:
 * - Makine / Araç Sahibi: ilan ekleme ekranına geçilir.
 * - Çekici: çekici paneline geçilir.
 * - Lastikçi: lastikçi paneline geçilir.
 */
@Composable
private fun QuickOwnerDialog(
    googleBusy: Boolean,
    onDismiss: () -> Unit,
    onSubmit: suspend (String, String, String, String, String) -> Result<Unit>,
    onSuccess: (role: String) -> Unit,
    onGoogle: (role: String) -> Unit,
    onOpenPrivacy: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var passVisible by remember { mutableStateOf(false) }
    var role by remember { mutableStateOf("OWNER") }
    var consent by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
        focusedBorderColor = AmberCta, unfocusedBorderColor = TextMuted,
        focusedLabelColor = AmberCta, unfocusedLabelColor = TextMuted, cursorColor = AmberCta
    )

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        containerColor = NavyLight,
        title = { Text("Hızlı Kayıt", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Hesabın türünü seç:", color = TextSecondary, fontSize = 13.sp)
                RoleOption("Makine / Araç Sahibi", role == "OWNER", Modifier.fillMaxWidth().testTag("role_owner")) { role = "OWNER" }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RoleOption("Çekici", role == "DUTY_TOW", Modifier.weight(1f).testTag("role_tow")) { role = "DUTY_TOW" }
                    RoleOption("Lastikçi", role == "DUTY_TIRE", Modifier.weight(1f).testTag("role_tire")) { role = "DUTY_TIRE" }
                }
                Text(
                    when (role) {
                        "DUTY_TOW" -> "Hesap açılır ve doğrudan çekici paneline geçersiniz. Acil çekici taleplerini bu panelden alırsınız."
                        "DUTY_TIRE" -> "Hesap açılır ve doğrudan lastikçi paneline geçersiniz. Acil lastik taleplerini bu panelden alırsınız."
                        else -> "Hesap hemen açılır ve ilan ekleme ekranına geçersiniz."
                    },
                    color = TextMuted, fontSize = 12.sp
                )
                OutlinedTextField(
                    value = name, onValueChange = { name = it; error = null },
                    label = { Text("Ad Soyad") }, singleLine = true, colors = fieldColors,
                    modifier = Modifier.fillMaxWidth().testTag("quick_name")
                )
                OutlinedTextField(
                    value = phone, onValueChange = { phone = it; error = null },
                    label = { Text("Telefon (05xx xxx xx xx)") }, singleLine = true, colors = fieldColors,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth().testTag("quick_phone")
                )
                OutlinedTextField(
                    value = email, onValueChange = { email = it; error = null },
                    label = { Text("E-posta") }, singleLine = true, colors = fieldColors,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth().testTag("quick_email")
                )
                OutlinedTextField(
                    value = pass, onValueChange = { pass = it; error = null },
                    label = { Text("Şifre (en az 6 karakter)") }, singleLine = true, colors = fieldColors,
                    visualTransformation = if (passVisible) androidx.compose.ui.text.input.VisualTransformation.None
                        else androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        TextButton(onClick = { passVisible = !passVisible }) {
                            Text(if (passVisible) "Gizle" else "Göster", color = BlueAccent, fontSize = 12.sp)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().testTag("quick_pass")
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.material3.Checkbox(
                        checked = consent,
                        onCheckedChange = { consent = it },
                        modifier = Modifier.testTag("quick_consent")
                    )
                    Text("Aydınlatma metnini okudum, kabul ediyorum", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                }
                TextButton(onClick = onOpenPrivacy) { Text("Aydınlatma metnini oku", color = BlueAccent, fontSize = 12.sp) }
                error?.let { Text(it, color = Color(0xFFFCA5A5), fontSize = 12.sp) }
                TextButton(
                    onClick = { onGoogle(role) },
                    enabled = !busy && !googleBusy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("veya Google ile devam et", color = BlueAccent)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    busy = true
                    scope.launch {
                        onSubmit(name, phone, email, pass, role).fold(
                            onSuccess = { busy = false; onSuccess(role) },
                            onFailure = { busy = false; error = it.message ?: "Kayıt yapılamadı." }
                        )
                    }
                },
                enabled = !busy && consent,
                colors = ButtonDefaults.buttonColors(containerColor = AmberCta, contentColor = Color(0xFF111827)),
                modifier = Modifier.testTag("quick_submit")
            ) {
                if (busy) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color(0xFF111827))
                else Text(if (role == "OWNER") "Kaydol ve İlan Ekle" else "Kaydol ve Başla", fontWeight = FontWeight.Bold, maxLines = 1)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !busy) { Text("Vazgeç", color = TextMuted) }
        }
    )
}

/** Misafir kullanıcı üyelik gerektiren bir eyleme dokunduğunda gösterilir. */
@Composable
fun LoginRequiredDialog(
    reason: String,
    onDismiss: () -> Unit,
    onLogin: () -> Unit,
    onRegister: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NavyLight,
        title = { Text("Üyelik Gerekli", color = Color.White, fontWeight = FontWeight.Bold) },
        text = { Text("$reason için giriş yapmanız veya ücretsiz üye olmanız gerekir.", color = TextSecondary) },
        confirmButton = {
            Button(onClick = onLogin, colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)) {
                Text("Giriş Yap", maxLines = 1)
            }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onRegister) { Text("Üye Ol", color = AmberCta, maxLines = 1) }
                TextButton(onClick = onDismiss) { Text("Vazgeç", color = TextMuted, maxLines = 1) }
            }
        }
    )
}
