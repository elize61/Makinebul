package com.example.data.repository

import android.util.Log
import com.example.data.firebase.FirebaseManager
import com.google.android.gms.tasks.Tasks
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Karşılıklı puanlama deposu.
 * Belge kimliği: "{istekId}_{puanlayanId}" -> her taraf bir işte yalnızca bir kez puan verebilir.
 * Acil çağrılarda istekId = talep kimliği, kiralamada istekId = teklif kimliği.
 */
object RatingRepository {
    private const val TAG = "RatingRepo"
    private const val COLLECTION = "ratings"

    data class Rating(
        val id: String = "",
        val requestId: String = "",
        val kind: String = "",
        val fromId: String = "",
        val fromName: String = "",
        val toId: String = "",
        val toRole: String = "",
        val rating: Int = 0,
        val comment: String = "",
        val createdAt: Long = 0L
    )

    fun docId(requestId: String, fromId: String): String = "${requestId}_${fromId}"

    /** Bu taraf bu iş için zaten puan verdi mi? */
    suspend fun alreadyRated(requestId: String, fromId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val db = FirebaseManager.getFirestore() ?: return@withContext false
            Tasks.await(db.collection(COLLECTION).document(docId(requestId, fromId)).get()).exists()
        } catch (e: Exception) {
            Log.w(TAG, "alreadyRated: ${e.message}")
            false
        }
    }

    suspend fun submit(
        kind: String,
        requestId: String,
        fromId: String,
        fromName: String,
        toId: String,
        toRole: String,
        rating: Int,
        comment: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (rating !in 1..5) return@withContext Result.failure(Exception("Lütfen 1-5 arasında puan verin."))
        if (toId.isBlank() || toId == fromId) return@withContext Result.failure(Exception("Bu kullanıcıya puan verilemez."))
        val db = FirebaseManager.getFirestore()
            ?: return@withContext Result.failure(Exception("Veritabanına ulaşılamadı."))
        val data = hashMapOf<String, Any>(
            "kind" to kind,
            "requestId" to requestId,
            "fromId" to fromId,
            "fromName" to fromName.ifBlank { "Kullanıcı" },
            "toId" to toId,
            "toRole" to toRole,
            "rating" to rating,
            "comment" to comment.trim().take(500),
            "createdAt" to System.currentTimeMillis()
        )
        try {
            Tasks.await(db.collection(COLLECTION).document(docId(requestId, fromId)).set(data))
            refreshSummaryBlocking(toId)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(Exception("Puan kaydedilemedi: ${e.localizedMessage ?: "bağlantınızı kontrol edin"}"))
        }
    }

    /** Bir kullanıcıya gelen tüm puanlar (yalnızca giriş yapmış kullanıcılar okuyabilir). */
    suspend fun receivedBy(userId: String): List<Rating> = withContext(Dispatchers.IO) {
        try {
            val db = FirebaseManager.getFirestore() ?: return@withContext emptyList()
            val snap = Tasks.await(db.collection(COLLECTION).whereEqualTo("toId", userId).get())
            snap.documents.map { d ->
                Rating(
                    id = d.id,
                    requestId = d.getString("requestId") ?: "",
                    kind = d.getString("kind") ?: "",
                    fromId = d.getString("fromId") ?: "",
                    fromName = d.getString("fromName") ?: "",
                    toId = d.getString("toId") ?: "",
                    toRole = d.getString("toRole") ?: "",
                    rating = (d.getLong("rating") ?: 0L).toInt(),
                    comment = d.getString("comment") ?: "",
                    createdAt = d.getLong("createdAt") ?: 0L
                )
            }.sortedByDescending { it.createdAt }
        } catch (e: Exception) {
            Log.w(TAG, "receivedBy: ${e.message}")
            emptyList()
        }
    }

    /**
     * Bir kullanıcının aldığı tüm puanlardan ortalamayı hesaplayıp kullanıcı belgesine yazar
     * (alan adları: rating, ratingCount). Kurallar bu iki alanın başkası tarafından güncellenmesine izin verir.
     */
    fun refreshSummaryBlocking(userId: String) {
        try {
            val db = FirebaseManager.getFirestore() ?: return
            val snap = Tasks.await(db.collection(COLLECTION).whereEqualTo("toId", userId).get())
            val values = snap.documents.mapNotNull { (it.getLong("rating") ?: return@mapNotNull null).toDouble() }
            val avg = if (values.isEmpty()) 0.0 else values.average()
            val fields = mapOf<String, Any>(
                "rating" to Math.round(avg * 10) / 10.0,
                "ratingCount" to values.size,
                "updatedAt" to System.currentTimeMillis()
            )
            for (col in listOf("kullanıcılar")) {
                try { Tasks.await(db.collection(col).document(userId).update(fields)) }
                catch (e: Exception) { Log.w(TAG, "özet '$col' yazılamadı: ${e.message}") }
            }
        } catch (e: Exception) {
            Log.w(TAG, "refreshSummary: ${e.message}")
        }
    }

    /** Fire-and-forget yazım (senkron akışlar için, örn. acil çağrı puanı). */
    fun submitAsync(
        kind: String, requestId: String, fromId: String, fromName: String,
        toId: String, toRole: String, rating: Int, comment: String
    ) {
        try {
            if (toId.isBlank() || toId == fromId) return
            val db = FirebaseManager.getFirestore() ?: return
            val data = hashMapOf<String, Any>(
                "kind" to kind,
                "requestId" to requestId,
                "fromId" to fromId,
                "fromName" to fromName.ifBlank { "Kullanıcı" },
                "toId" to toId,
                "toRole" to toRole,
                "rating" to rating,
                "comment" to comment.trim().take(500),
                "createdAt" to System.currentTimeMillis()
            )
            db.collection(COLLECTION).document(docId(requestId, fromId)).set(data).addOnSuccessListener {
                Thread { refreshSummaryBlocking(toId) }.start()
            }
        } catch (t: Throwable) {
            Log.w(TAG, "submitAsync failed: ${t.message}")
        }
    }
}
