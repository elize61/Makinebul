package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.User
import com.example.data.repository.RatingRepository
import kotlinx.coroutines.launch

private val StarGold = Color(0xFFF59E0B)

/** 1-5 yıldız. onChange null ise salt okunur gösterim. */
@Composable
fun StarRow(value: Int, onChange: ((Int) -> Unit)? = null, size: Int = 28) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        for (i in 1..5) {
            val filled = i <= value
            Icon(
                imageVector = Icons.Filled.Star,
                contentDescription = "$i yıldız",
                tint = if (filled) StarGold else Color(0xFF6B7280),
                modifier = Modifier
                    .size(size.dp)
                    .then(if (onChange != null) Modifier.clickable { onChange(i) } else Modifier)
            )
        }
    }
}

/**
 * İş bittikten sonra karşı tarafı puanlama kartı.
 * - kind: "EMERGENCY" (acil çağrı) veya "OFFER" (kiralama)
 * - requestId: talep veya teklif kimliği
 * - targetRole: "CUSTOMER", "OWNER" veya "PROVIDER"
 * Puan daha önce verildiyse kart "verildi" durumuna geçer.
 */
@Composable
fun RatePartnerCard(
    kind: String,
    requestId: String,
    currentUser: User,
    targetId: String,
    targetName: String,
    targetRole: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var alreadyRated by remember(requestId, currentUser.id) { mutableStateOf<Boolean?>(null) }
    var stars by remember(requestId) { mutableStateOf(0) }
    var comment by remember(requestId) { mutableStateOf("") }
    var busy by remember(requestId) { mutableStateOf(false) }

    LaunchedEffect(requestId, currentUser.id) {
        alreadyRated = RatingRepository.alreadyRated(requestId, currentUser.id)
    }

    if (targetId.isBlank()) return

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "⭐ $targetName için puan verin",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            when (alreadyRated) {
                null -> CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                true -> Text("Bu iş için puanınızı verdiniz. Teşekkürler! ✅", fontSize = 13.sp)
                false -> {
                    StarRow(value = stars, onChange = { stars = it })
                    OutlinedTextField(
                        value = comment,
                        onValueChange = { if (it.length <= 500) comment = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Yorum (isteğe bağlı)") },
                        minLines = 2,
                        maxLines = 4
                    )
                    Button(
                        onClick = {
                            if (stars !in 1..5) {
                                Toast.makeText(context, "Lütfen yıldız seçin.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            busy = true
                            scope.launch {
                                val r = RatingRepository.submit(
                                    kind = kind,
                                    requestId = requestId,
                                    fromId = currentUser.id,
                                    fromName = currentUser.fullName,
                                    toId = targetId,
                                    toRole = targetRole,
                                    rating = stars,
                                    comment = comment
                                )
                                busy = false
                                r.fold(
                                    onSuccess = {
                                        alreadyRated = true
                                        Toast.makeText(context, "Puanınız kaydedildi.", Toast.LENGTH_SHORT).show()
                                    },
                                    onFailure = {
                                        Toast.makeText(context, it.message ?: "Puan kaydedilemedi.", Toast.LENGTH_LONG).show()
                                    }
                                )
                            }
                        },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = StarGold, contentColor = Color(0xFF111827))
                    ) {
                        Text(if (busy) "Gönderiliyor..." else "Puanı Gönder", fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(0.dp))
        }
    }
}
