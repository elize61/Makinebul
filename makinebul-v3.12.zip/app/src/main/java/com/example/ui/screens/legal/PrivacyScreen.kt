package com.example.ui.screens.legal

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.NavyDark
import com.example.ui.theme.TextSecondary

/** KVKK aydınlatma metni: uygulama içinde gösterilir. Aynı metin gizlilik-politikasi.md dosyasındadır. */
@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().background(NavyDark)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri", tint = Color.White)
            }
            Text("Aydınlatma Metni ve Gizlilik Politikası", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        }
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            PRIVACY_SECTIONS.forEach { (title, paragraphs) ->
                Text(
                    title,
                    color = BlueAccent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(top = 14.dp, bottom = 4.dp)
                )
                paragraphs.forEach { p ->
                    Text(p, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

val PRIVACY_SECTIONS: List<Pair<String, List<String>>> = listOf(
    "1. Veri sorumlusu" to listOf(
        "Bu aydınlatma metni, MakineBul uygulamasını işleten kişi (“MakineBul”, “biz”) tarafından, 6698 sayılı Kişisel Verilerin Korunması Kanunu (“KVKK”) kapsamında hazırlanmıştır.",
        "İletişim: 61bycmurat@gmail.com",
    ),
    "2. Hangi verileri topluyoruz" to listOf(
        "Kimlik ve iletişim: ad soyad, cep telefonu numarası, e-posta adresi.",
        "Hesap bilgileri: giriş şifresi (Firebase Authentication tarafından şifrelenmiş olarak tutulur, düz metin olarak saklanmaz), hesap türü (makine sahibi, çekici, lastikçi, müşteri).",
        "İlan bilgileri: makine adı, kategori, fiyat, adres, fotoğraflar, müsaitlik ve rezervasyon tarihleri.",
        "İşlem kayıtları: teklifler, mesajlar, acil çağrı talepleri, değerlendirme ve yorumlar.",
        "Konum: acil çağrı oluştururken ve çekici/lastikçi yola çıktığında cihazın GPS konumu. Konum yalnızca bu talep için kullanılır.",
        "Teknik kayıtlar: uygulama sürümü, cihaz modeli ve hata kayıtları (Firebase Crashlytics kullanılmıyor; yalnızca gerekli sistem kayıtları tutulur).",
    ),
    "3. Verileri neden işliyoruz" to listOf(
        "Hesap oluşturma, giriş yapma ve hesabınızı yönetme.",
        "Makine ilanlarını yayınlama, kiralama teklifi alıp verme ve takvim yönetimi.",
        "Acil çağrılarda size en yakın çekici veya lastikçiyi bulma, fiyat tekliflerini iletme ve çekici yoldayken canlı takip.",
        "Kullanıcılar arasındaki mesajlaşma ve değerlendirme sistemi.",
        "Güvenlik, dolandırıcılık ve kötüye kullanımın önlenmesi; yönetici incelemesi (ilan onayı, şikayet).",
        "Yasal yükümlülüklerin yerine getirilmesi.",
    ),
    "4. Hukuki sebepler" to listOf(
        "Sözleşmenin kurulması ve ifası (hesap, ilan, teklif ve talep işlemleri).",
        "Hukuki yükümlülük (vergi ve ticaret mevzuatı kayıtları).",
        "Meşru menfaat (güvenlik, kötüye kullanımın önlenmesi).",
        "Açık rıza (konum): Konum yalnızca cihaz izniniz verildiğinde ve yalnızca acil talep sırasında alınır. İzni cihaz ayarlarından istediğiniz zaman kaldırabilirsiniz; bu durumda konumunuzu elle girebilirsiniz.",
    ),
    "5. Verileri kimlerle paylaşıyoruz" to listOf(
        "Hizmet sağlayıcılar: Google Firebase (kimlik doğrulama, veritabanı, fotoğraf depolama) ve OpenStreetMap / Nominatim (adres ve konum bulma).",
        "Karşı taraf: Bir teklif veya acil talep kabul edildiğinde adınız, telefon numaranız ve (acil talepte) konumunuz ilgili makine sahibi, çekici veya lastikçi ile paylaşılır.",
        "WhatsApp ve telefon aramaları: Bunları siz başlatırsınız; ilgili uygulama açılır, MakineBul bu iletişimin içeriğini tutmaz.",
        "Yasal merciler: yasal bir talep halinde yetkili kurum ve mahkemelerle.",
        "Verileriniz satılmaz ve reklam amacıyla üçüncü kişilere aktarılmaz.",
    ),
    "6. Yurt dışına aktarım" to listOf(
        "Firebase veritabanı ve dosya depolama hizmetleri Google’ın Amerika Birleşik Devletleri’ndeki veri merkezlerinde barındırılmaktadır. Bu aktarım KVKK madde 9 kapsamında, hizmet sağlayıcının sunduğu güvenlik önlemleriyle yapılır.",
    ),
    "7. Saklama süreleri" to listOf(
        "Hesabınız açık olduğu sürece verileriniz saklanır.",
        "Hesabınızı silmeniz halinde profil bilgileriniz ve ilanlarınız silinir. Teklif, talep ve ödeme ile ilgili işlem kayıtları, vergi ve ticaret mevzuatının öngördüğü süre (en fazla 10 yıl) boyunca saklanabilir.",
    ),
    "8. Haklarınız (KVKK madde 11)" to listOf(
        "Kişisel verilerinizin işlenip işlenmediğini öğrenme, işlenmişse bilgi talep etme.",
        "İşlenme amacını ve amacına uygun kullanılıp kullanılmadığını öğrenme.",
        "Verilerinizin düzeltilmesini, silinmesini veya yok edilmesini isteme.",
        "İşlenmesine itiraz etme ve aktarıldığı üçüncü kişileri öğrenme.",
        "Kanuna aykırı işleme nedeniyle zarara uğramanız halinde zararın giderilmesini talep etme.",
        "Başvuru: 61bycmurat@gmail.com adresine yazabilirsiniz. Hesabınızı uygulama içinden Profil > Hesabımı Sil seçeneğiyle de silebilirsiniz.",
    ),
    "9. Çocuklar" to listOf(
        "MakineBul 18 yaşından küçüklere yönelik değildir. Uygulamayı kullanmak için 18 yaşını doldurmuş olmanız gerekir.",
    ),
    "10. Değişiklikler" to listOf(
        "Bu metin gerektiğinde güncellenebilir. Önemli değişiklikler uygulama içinde duyurulur.",
        "Son güncelleme: 24.11.2026",
    ),
)
