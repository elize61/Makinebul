package com.example.ui.screens.profile

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.firebase.FirebaseManager
import com.example.data.model.User
import com.example.ui.components.MachinePhoto
import kotlinx.coroutines.launch

/**
 * Profil düzenleme: fotoğraf, kişisel bilgiler, dükkan adresi, şifre ve e-posta.
 * E-posta değişikliği yeni adrese doğrulama bağlantısı gönderir; onaylanana kadar değişmez.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileEditScreen(
    currentUser: User,
    onBack: () -> Unit,
    onSaveInfo: suspend (fullName: String, phone: String, city: String, district: String) -> Result<Unit>,
    onSaveAddress: suspend (address: String) -> Result<Unit>,
    onSavePhoto: suspend (dataUri: String) -> Result<Unit>,
    onChangePassword: suspend (currentPass: String, newPass: String) -> Result<Unit>,
    onChangeEmail: suspend (newEmail: String, currentPass: String) -> Result<Unit>,
    compressPhoto: suspend (android.net.Uri) -> String?
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val scroll = rememberScrollState()

    var busy by remember { mutableStateOf(false) }
    var fullName by remember { mutableStateOf(currentUser.fullName) }
    var phone by remember { mutableStateOf(currentUser.phone) }
    var city by remember { mutableStateOf(currentUser.city) }
    var district by remember { mutableStateOf(currentUser.district) }
    var address by remember { mutableStateOf(currentUser.address) }

    var currentPass by remember { mutableStateOf("") }
    var newPass by remember { mutableStateOf("") }
    var newPassRepeat by remember { mutableStateOf("") }

    var newEmail by remember { mutableStateOf("") }
    var emailPass by remember { mutableStateOf("") }
    var emailSent by remember { mutableStateOf(false) }

    // Şifre ve e-posta yalnızca e-posta/şifre ile açılmış hesaplarda değiştirilebilir
    val canUsePassword = remember {
        FirebaseManager.getAuth()?.currentUser?.providerData?.any { it.providerId == "password" } == true
    }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null && !busy) {
            busy = true
            scope.launch {
                val dataUri = compressPhoto(uri)
                if (dataUri == null) {
                    Toast.makeText(context, "Fotoğraf okunamadı.", Toast.LENGTH_LONG).show()
                } else {
                    onSavePhoto(dataUri).fold(
                        onSuccess = { Toast.makeText(context, "Profil fotoğrafı güncellendi.", Toast.LENGTH_SHORT).show() },
                        onFailure = { Toast.makeText(context, it.message ?: "Fotoğraf kaydedilemedi.", Toast.LENGTH_LONG).show() }
                    )
                }
                busy = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Profili Düzenle", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Geri")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(padding)
                .verticalScroll(scroll)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Profil fotoğrafı
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF3B82F6), CircleShape)
                    .clickable(enabled = !busy) {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                contentAlignment = Alignment.Center
            ) {
                if (currentUser.profileImageUrl.isNotBlank()) {
                    MachinePhoto(
                        model = currentUser.profileImageUrl,
                        contentDescription = "Profil fotoğrafı",
                        modifier = Modifier.size(96.dp),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(Icons.Filled.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(48.dp))
                }
            }
            OutlinedButton(
                onClick = { photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                enabled = !busy
            ) { Text("Fotoğraf Seç") }

            if (busy) CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)

            // Kişisel bilgiler
            SectionTitle("Hesap Bilgileri")
            OutlinedTextField(
                value = fullName, onValueChange = { fullName = it },
                label = { Text("Ad Soyad") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = phone, onValueChange = { phone = it },
                label = { Text("Telefon (5xx xxx xx xx)") }, singleLine = true,
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = city, onValueChange = { city = it },
                    label = { Text("İl") }, singleLine = true, modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = district, onValueChange = { district = it },
                    label = { Text("İlçe") }, singleLine = true, modifier = Modifier.weight(1f)
                )
            }
            Button(
                onClick = {
                    busy = true
                    scope.launch {
                        val r = onSaveInfo(fullName, phone, city, district)
                        r.fold(
                            onSuccess = { Toast.makeText(context, "Bilgiler kaydedildi.", Toast.LENGTH_SHORT).show() },
                            onFailure = { Toast.makeText(context, it.message ?: "Kaydedilemedi.", Toast.LENGTH_LONG).show() }
                        )
                        busy = false
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            ) { Text("Bilgileri Kaydet", fontWeight = FontWeight.Bold) }

            // Dükkan / işletme adresi (haritada doğrulanır)
            SectionTitle("Dükkan / İşletme Adresi")
            OutlinedTextField(
                value = address, onValueChange = { address = it },
                label = { Text("Mahalle, cadde, ilçe, il") }, modifier = Modifier.fillMaxWidth(), minLines = 2
            )
            OutlinedButton(
                onClick = {
                    busy = true
                    scope.launch {
                        onSaveAddress(address).fold(
                            onSuccess = { Toast.makeText(context, "Adres kaydedildi.", Toast.LENGTH_SHORT).show() },
                            onFailure = { Toast.makeText(context, it.message ?: "Adres kaydedilemedi.", Toast.LENGTH_LONG).show() }
                        )
                        busy = false
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Adresi Kaydet") }

            // Şifre
            if (canUsePassword) {
                SectionTitle("Şifre Değiştir")
                OutlinedTextField(
                    value = currentPass, onValueChange = { currentPass = it },
                    label = { Text("Mevcut şifre") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = newPass, onValueChange = { newPass = it },
                    label = { Text("Yeni şifre (en az 6 karakter)") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = newPassRepeat, onValueChange = { newPassRepeat = it },
                    label = { Text("Yeni şifre (tekrar)") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(
                    onClick = {
                        when {
                            currentPass.isBlank() -> Toast.makeText(context, "Mevcut şifrenizi girin.", Toast.LENGTH_SHORT).show()
                            newPass != newPassRepeat -> Toast.makeText(context, "Yeni şifreler eşleşmiyor.", Toast.LENGTH_SHORT).show()
                            else -> {
                                busy = true
                                scope.launch {
                                    onChangePassword(currentPass, newPass).fold(
                                        onSuccess = {
                                            currentPass = ""; newPass = ""; newPassRepeat = ""
                                            Toast.makeText(context, "Şifreniz güncellendi.", Toast.LENGTH_SHORT).show()
                                        },
                                        onFailure = { Toast.makeText(context, it.message ?: "Şifre değiştirilemedi.", Toast.LENGTH_LONG).show() }
                                    )
                                    busy = false
                                }
                            }
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Şifreyi Güncelle") }

                // E-posta
                SectionTitle("E-posta Değiştir")
                Text(
                    "Mevcut e-posta: ${currentUser.email}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = newEmail, onValueChange = { newEmail = it },
                    label = { Text("Yeni e-posta") }, singleLine = true,
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = emailPass, onValueChange = { emailPass = it },
                    label = { Text("Onay için mevcut şifre") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        busy = true
                        scope.launch {
                            onChangeEmail(newEmail, emailPass).fold(
                                onSuccess = {
                                    emailSent = true
                                    emailPass = ""
                                    Toast.makeText(context, "Doğrulama bağlantısı yeni adresinize gönderildi.", Toast.LENGTH_LONG).show()
                                },
                                onFailure = { Toast.makeText(context, it.message ?: "E-posta değiştirilemedi.", Toast.LENGTH_LONG).show() }
                            )
                            busy = false
                        }
                    },
                    enabled = !busy && newEmail.isNotBlank() && emailPass.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) { Text("Doğrulama Bağlantısı Gönder") }
                if (emailSent) {
                    Text(
                        "Yeni adresinizdeki bağlantıya tıklayıp onaylayın. Onaylanana kadar e-posta adresiniz değişmez.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Text(
                    "Bu hesap Google ile açıldığı için şifre ve e-posta bilgisi Google hesabınızdan yönetilir.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Spacer(Modifier.height(8.dp))
    Text(text, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.fillMaxWidth())
}
