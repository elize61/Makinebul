package com.example.data.repository

import android.util.Log
import com.example.data.firebase.FirebaseManager
import com.example.data.model.Machine
import com.example.data.model.Report
import com.example.data.model.ServiceProviderApplication
import com.example.data.model.User
import com.example.data.model.UserType
import com.google.android.gms.tasks.Tasks
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

class AdminRepository {

    companion object {
        private const val TAG = "AdminRepository"
    }

    private val _allUsers = MutableStateFlow<List<User>>(emptyList())
    val allUsers: StateFlow<List<User>> = _allUsers.asStateFlow()

    private val _applications = MutableStateFlow<List<ServiceProviderApplication>>(emptyList())
    val applications: StateFlow<List<ServiceProviderApplication>> = _applications.asStateFlow()

    private val _reports = MutableStateFlow<List<Report>>(emptyList())
    val reports: StateFlow<List<Report>> = _reports.asStateFlow()

    private val _pendingApplicationsCount = MutableStateFlow(0)
    val pendingApplicationsCount: StateFlow<Int> = _pendingApplicationsCount.asStateFlow()

    init {
        FirebaseManager.runWhenAuthenticated {
            listenToAllUsers()
            listenToApplications()
            listenToReports()
        }
    }

    private fun listenToAllUsers() {
        try {
            val db = FirebaseManager.getFirestore() ?: return
            db.collection("kullanıcılar").addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) {
                    // Try fallback collection "users"
                    db.collection("users").addSnapshotListener { oldSnap, oldErr ->
                        if (oldErr == null && oldSnap != null && !oldSnap.isEmpty) {
                            _allUsers.value = parseUsers(oldSnap.documents)
                        }
                    }
                    return@addSnapshotListener
                }

                if (!snapshot.isEmpty) {
                    _allUsers.value = parseUsers(snapshot.documents)
                } else {
                    // Try fallback
                    db.collection("users").get().addOnSuccessListener { oldSnap ->
                        if (oldSnap != null && !oldSnap.isEmpty) {
                            _allUsers.value = parseUsers(oldSnap.documents)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error listening to all users: ${e.localizedMessage}")
        }
    }

    private fun parseUsers(documents: List<DocumentSnapshot>): List<User> {
        return documents.mapNotNull { doc ->
            try {
                val uid = doc.getString("uid") ?: doc.getString("id") ?: doc.id
                val fullName = doc.getString("isim") ?: doc.getString("adSoyad") ?: doc.getString("fullName") ?: "Kullanıcı"
                val phone = doc.getString("telefon") ?: doc.getString("phone") ?: ""
                val email = doc.getString("email") ?: ""
                val roleStr = doc.getString("rol") ?: doc.getString("userType")
                val userType = parseRole(roleStr)
                val city = doc.getString("il") ?: doc.getString("city") ?: "İstanbul"
                val district = doc.getString("ilce") ?: doc.getString("district") ?: ""
                val rating = doc.getDouble("rating") ?: 5.0
                // Çevrimdışı sürücüler de isActive=false yazar; askı yalnızca isSuspended/status ile belirlenir
                val isActive = !(doc.getBoolean("isSuspended") == true || doc.getString("status").equals("SUSPENDED", ignoreCase = true))

                User(
                    id = uid,
                    fullName = fullName,
                    phone = phone,
                    email = email,
                    userType = userType,
                    city = city,
                    district = district,
                    rating = rating,
                    isActive = isActive
                )
            } catch (ex: Exception) {
                null
            }
        }
    }

    private fun parseRole(roleStr: String?): UserType {
        if (roleStr == null) return UserType.CUSTOMER
        val upper = roleStr.uppercase()
        return when {
            upper == "ADMIN" || upper.contains("YÖNETİCİ") || upper.contains("YONETICI") -> UserType.ADMIN
            upper == "OWNER" || upper.contains("SAHİP") || upper.contains("SAHIP") -> UserType.OWNER
            upper == "DUTY_TOW" || upper.contains("ÇEKİCİ") || upper.contains("CEKICI") || upper.contains("TOW") -> UserType.DUTY_TOW
            upper == "DUTY_TIRE" || upper.contains("LASTİK") || upper.contains("LASTIK") || upper.contains("TIRE") -> UserType.DUTY_TIRE
            else -> UserType.CUSTOMER
        }
    }

    private fun listenToApplications() {
        try {
            val db = FirebaseManager.getFirestore() ?: return
            db.collection("applications").addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                val list = snapshot.documents.mapNotNull { doc ->
                    try {
                        ServiceProviderApplication(
                            id = doc.getString("id") ?: doc.id,
                            userId = doc.getString("userId") ?: "",
                            userName = doc.getString("userName") ?: "",
                            userPhone = doc.getString("userPhone") ?: "",
                            userEmail = doc.getString("userEmail") ?: "",
                            requestedRole = doc.getString("requestedRole") ?: "OWNER",
                            companyName = doc.getString("companyName") ?: "",
                            taxNumber = doc.getString("taxNumber") ?: "",
                            city = doc.getString("city") ?: "İstanbul",
                            district = doc.getString("district") ?: "Ümraniye",
                            note = doc.getString("note") ?: "",
                            status = doc.getString("status") ?: "PENDING",
                            createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
                        )
                    } catch (ex: Exception) {
                        null
                    }
                }.sortedByDescending { it.createdAt }

                _applications.value = list
                _pendingApplicationsCount.value = list.count { it.status == "PENDING" }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error listening to applications: ${e.localizedMessage}")
        }
    }

    private fun listenToReports() {
        try {
            val db = FirebaseManager.getFirestore() ?: return
            db.collection("reports").addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                val list = snapshot.documents.mapNotNull { doc ->
                    try {
                        Report(
                            reportId = doc.getString("reportId") ?: doc.id,
                            reportedBy = doc.getString("reportedBy") ?: "",
                            reportedByName = doc.getString("reportedByName") ?: "Kullanıcı",
                            targetId = doc.getString("targetId") ?: "",
                            targetType = doc.getString("targetType") ?: "MACHINE",
                            reason = doc.getString("reason") ?: "",
                            description = doc.getString("description") ?: "",
                            createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis(),
                            status = doc.getString("status") ?: "PENDING"
                        )
                    } catch (ex: Exception) {
                        null
                    }
                }.sortedByDescending { it.createdAt }

                _reports.value = list
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error listening to reports: ${e.localizedMessage}")
        }
    }

    suspend fun submitApplication(app: ServiceProviderApplication): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val db = FirebaseManager.getFirestore()
                ?: return@withContext Result.failure(Exception("Veritabanı bağlantısı yok"))

            val map = hashMapOf<String, Any>(
                "id" to app.id,
                "userId" to app.userId,
                "userName" to app.userName,
                "userPhone" to app.userPhone,
                "userEmail" to app.userEmail,
                "requestedRole" to app.requestedRole,
                "companyName" to app.companyName,
                "taxNumber" to app.taxNumber,
                "city" to app.city,
                "district" to app.district,
                "note" to app.note,
                "status" to app.status,
                "createdAt" to app.createdAt
            )

            val task = db.collection("applications").document(app.id).set(map)
            Tasks.await(task)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun processApplication(
        appId: String,
        approve: Boolean,
        userId: String,
        requestedRole: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val db = FirebaseManager.getFirestore()
                ?: return@withContext Result.failure(Exception("Veritabanı bağlantısı yok"))

            val newStatus = if (approve) "APPROVED" else "REJECTED"
            
            // 1. Update application doc
            val updateAppTask = db.collection("applications").document(appId)
                .update("status", newStatus, "reviewedAt", System.currentTimeMillis())
            Tasks.await(updateAppTask)

            // 2. If approved, upgrade the user's role in Firestore
            if (approve && userId.isNotBlank()) {
                val newRole = when (requestedRole.uppercase()) {
                    "DUTY_TOW", "ÇEKİCİ", "CEKICI", "TOW_TRUCK" -> "DUTY_TOW"
                    "DUTY_TIRE", "LASTİKÇİ", "LASTIKCI", "TIRE_SERVICE" -> "DUTY_TIRE"
                    else -> "OWNER"
                }

                val roleUpdateMap = mapOf(
                    "rol" to newRole,
                    "userType" to newRole,
                    "updatedAt" to System.currentTimeMillis()
                )

                try {
                    val userUpdateTask1 = db.collection("kullanıcılar").document(userId).update(roleUpdateMap)
                    Tasks.await(userUpdateTask1)
                } catch (_: Exception) {}

                try {
                    val userUpdateTask2 = db.collection("users").document(userId).update(roleUpdateMap)
                    Tasks.await(userUpdateTask2)
                } catch (_: Exception) {}
            }

            // Local state update for instant UI feedback
            _applications.value = _applications.value.map {
                if (it.id == appId) it.copy(status = newStatus) else it
            }
            _pendingApplicationsCount.value = _applications.value.count { it.status == "PENDING" }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Yönetici: kullanıcının rolünü değiştirir (CUSTOMER, OWNER, DUTY_TOW, DUTY_TIRE). */
    suspend fun setUserRole(userId: String, role: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val db = FirebaseManager.getFirestore()
                ?: return@withContext Result.failure(Exception("Veritabanı bağlantısı yok"))
            val map = mapOf("rol" to role, "userType" to role, "updatedAt" to System.currentTimeMillis())
            try { Tasks.await(db.collection("kullanıcılar").document(userId).update(map)) } catch (_: Exception) {}
            try { Tasks.await(db.collection("users").document(userId).update(map)) } catch (_: Exception) {}
            _allUsers.value = _allUsers.value.map { if (it.id == userId) it.copy(userType = parseRole(role)) else it }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Yönetici: kullanıcı kaydını siler (giriş hesabı Firebase Authentication'dan ayrıca silinmelidir). */
    suspend fun deleteUser(userId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val db = FirebaseManager.getFirestore()
                ?: return@withContext Result.failure(Exception("Veritabanı bağlantısı yok"))
            try { Tasks.await(db.collection("kullanıcılar").document(userId).delete()) } catch (_: Exception) {}
            try { Tasks.await(db.collection("users").document(userId).delete()) } catch (_: Exception) {}
            _allUsers.value = _allUsers.value.filter { it.id != userId }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun toggleUserActiveStatus(userId: String, active: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val db = FirebaseManager.getFirestore()
                ?: return@withContext Result.failure(Exception("Veritabanı bağlantısı yok"))

            val updateMap = mapOf(
                "isActive" to active,
                "isSuspended" to !active,
                "status" to (if (active) "ACTIVE" else "SUSPENDED"),
                "updatedAt" to System.currentTimeMillis()
            )

            try {
                val task1 = db.collection("kullanıcılar").document(userId).update(updateMap)
                Tasks.await(task1)
            } catch (_: Exception) {}

            try {
                val task2 = db.collection("users").document(userId).update(updateMap)
                Tasks.await(task2)
            } catch (_: Exception) {}

            _allUsers.value = _allUsers.value.map {
                if (it.id == userId) it.copy(isActive = active) else it
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Eski demo/test kayıtlarını siler: belge kimliği ya da herhangi bir metin alanı "demo" ile başlayanlar
     * (ör. demo_owner_1, demo_customer_1). Sadece yönetici çağırabilir (Firestore kuralları da bunu zorlar).
     */
    suspend fun purgeTestData(): Result<String> = withContext(Dispatchers.IO) {
        try {
            val db = FirebaseManager.getFirestore()
                ?: return@withContext Result.failure(Exception("Veritabanı bağlantısı yok"))
            val collections = listOf(
                "machines", "makineler", "offers", "messages", "emergencyRequests",
                "jobDemands", "jobBids", "reviews", "handoverProtocols"
            )
            var deleted = 0
            for (name in collections) {
                val snap = try { Tasks.await(db.collection(name).get()) } catch (e: Exception) {
                    Log.w(TAG, "purge: $name okunamadı: ${e.localizedMessage}"); continue
                }
                for (doc in snap.documents) {
                    val isTest = doc.id.startsWith("demo") ||
                        (doc.data ?: emptyMap()).values.any { it is String && it.startsWith("demo_") }
                    if (isTest) {
                        try { Tasks.await(doc.reference.delete()); deleted++ } catch (e: Exception) {
                            Log.w(TAG, "purge: silinemedi ${doc.reference.path}: ${e.localizedMessage}")
                        }
                    }
                }
            }
            Result.success("$deleted test kaydı silindi")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Tamamlanmamış tüm acil çağrıları "İPTAL" durumuna alarak kapatır. */
    suspend fun closeAllOpenEmergencyRequests(): Result<String> = withContext(Dispatchers.IO) {
        try {
            val db = FirebaseManager.getFirestore()
                ?: return@withContext Result.failure(Exception("Veritabanı bağlantısı yok"))
            val snap = Tasks.await(db.collection("emergencyRequests").get())
            var closed = 0
            for (doc in snap.documents) {
                val st = doc.getString("status") ?: doc.getString("durum") ?: ""
                if (st != "COMPLETED" && st != "CANCELLED") {
                    try {
                        Tasks.await(doc.reference.update("status", "CANCELLED", "updatedAt", System.currentTimeMillis()))
                        closed++
                    } catch (e: Exception) {
                        Log.w(TAG, "close: ${doc.id}: ${e.localizedMessage}")
                    }
                }
            }
            Result.success("$closed açık acil çağrı kapatıldı")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun resolveReport(reportId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val db = FirebaseManager.getFirestore()
                ?: return@withContext Result.failure(Exception("Veritabanı bağlantısı yok"))

            val task = db.collection("reports").document(reportId)
                .update("status", "RESOLVED", "resolvedAt", System.currentTimeMillis())
            Tasks.await(task)

            _reports.value = _reports.value.map {
                if (it.reportId == reportId) it.copy(status = "RESOLVED") else it
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun submitReport(report: Report): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val db = FirebaseManager.getFirestore()
                ?: return@withContext Result.failure(Exception("Veritabanı bağlantısı yok"))

            val map = hashMapOf<String, Any>(
                "reportId" to report.reportId,
                "reportedBy" to report.reportedBy,
                "reportedByName" to report.reportedByName,
                "targetId" to report.targetId,
                "targetType" to report.targetType,
                "reason" to report.reason,
                "description" to report.description,
                "status" to report.status,
                "createdAt" to report.createdAt
            )

            val task = db.collection("reports").document(report.reportId).set(map)
            Tasks.await(task)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
