package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Calendar
import java.util.Locale

@Composable
fun AvailabilityCalendar(
    blockedDates: List<String>,
    dailyPrice: Double,
    hourlyPrice: Double,
    isOwnerMode: Boolean = false,
    /** Sahip modunda günleri açıp kapatmayı devre dışı bırakır (sadece görüntüleme). */
    ownerReadOnly: Boolean = false,
    /** Onaylanan tekliflerle otomatik dolan günler (kırmızı, seçilemez). */
    reservedDates: List<String> = emptyList(),
    /** false ise (pasif ilan) takvimden tarih seçilemez. */
    selectionEnabled: Boolean = true,
    onDateRangeSelected: (startDate: String, endDate: String, daysCount: Int, calculatedPrice: Double) -> Unit = { _, _, _, _ -> },
    onToggleBlockDate: (String) -> Unit = {},
    /** Sahip modunda rezerve (kırmızı, teklifle dolu) bir güne dokununca çağrılır; ISO tarih verir. */
    onReservedDateClick: (String) -> Unit = {}
) {
    // Current month offset: 0 = current month (Ağustos 2026), 1 = next month (Eylül 2026)
    var monthOffset by remember { mutableIntStateOf(0) }
    
    val baseCal = remember { Calendar.getInstance() }
    val displayCal = remember(monthOffset) {
        val c = Calendar.getInstance()
        c.add(Calendar.MONTH, monthOffset)
        c
    }

    val year = displayCal.get(Calendar.YEAR)
    val month = displayCal.get(Calendar.MONTH)
    val monthName = displayCal.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale("tr", "TR")) ?: "Ay"

    val daysInMonth = displayCal.getActualMaximum(Calendar.DAY_OF_MONTH)
    
    // First day of week (1 = Sunday in Java Calendar, convert to Monday = 0)
    val firstDayCal = Calendar.getInstance().apply {
        set(Calendar.YEAR, year)
        set(Calendar.MONTH, month)
        set(Calendar.DAY_OF_MONTH, 1)
    }
    val javaFirstDay = firstDayCal.get(Calendar.DAY_OF_WEEK) // 1=Sun, 2=Mon...
    val leadingEmptyDays = (javaFirstDay + 5) % 7 // Monday = 0

    val todayKey = remember {
        val t = Calendar.getInstance()
        String.format(Locale.ROOT, "%04d-%02d-%02d", t.get(Calendar.YEAR), t.get(Calendar.MONTH) + 1, t.get(Calendar.DAY_OF_MONTH))
    }
    // Seçim tam ISO tarih (yyyy-MM-dd) olarak tutulur; böylece ay değiştirince de aralık korunur.
    var selectedStartKey by remember { mutableStateOf<String?>(null) }
    var selectedEndKey by remember { mutableStateOf<String?>(null) }

    val daysCount = remember(selectedStartKey, selectedEndKey) {
        val st = selectedStartKey
        if (st == null) 0
        else com.example.util.DateUtils.expandRange(st, selectedEndKey ?: st).size.coerceAtLeast(1)
    }

    val estimatedPrice = remember(daysCount, dailyPrice) {
        if (daysCount > 0) daysCount * (if (dailyPrice > 0) dailyPrice else hourlyPrice * 8) else 0.0
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("availability_calendar_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header: Title & Month navigation
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        tint = BluePrimary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isOwnerMode) "Müsaitlik & Doluluk" else "Rezervasyon & Müsaitlik",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { if (monthOffset > 0) monthOffset-- },
                        enabled = monthOffset > 0,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Önceki Ay",
                            tint = if (monthOffset > 0) NavyDark else TextMuted
                        )
                    }

                    Text(
                        text = "$monthName $year",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        color = TextPrimary,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.padding(horizontal = 2.dp)
                    )

                    IconButton(
                        onClick = { if (monthOffset < 3) monthOffset++ },
                        enabled = monthOffset < 3,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Sonraki Ay",
                            tint = if (monthOffset < 3) NavyDark else TextMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Legend / Açıklama & Counts
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(NavyElevated, RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val blockedInMonth = (1..daysInMonth).count { d ->
                    val k = String.format(Locale.ROOT, "%04d-%02d-%02d", year, month + 1, d)
                    blockedDates.contains(k) || reservedDates.contains(k)
                }
                val availableInMonth = daysInMonth - blockedInMonth

                Row(verticalAlignment = Alignment.CenterVertically) {
                    LegendBadge(color = Color(0xFF16A34A), label = if (isOwnerMode) "Müsait ($availableInMonth gün)" else "Müsait")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LegendBadge(color = Color(0xFFDC2626), label = if (isOwnerMode) "Dolu/Kapalı ($blockedInMonth gün)" else "Rezerve / Dolu")
                }
                if (!isOwnerMode) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LegendBadge(color = BluePrimary, label = "Seçili")
                    }
                }
            }

            if (isOwnerMode && !ownerReadOnly) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFDCFCE7),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF22C55E)),
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                // Clear blocked dates for this month
                                for (d in 1..daysInMonth) {
                                    val key = String.format(Locale.ROOT, "%04d-%02d-%02d", year, month + 1, d)
                                    if (blockedDates.contains(key)) {
                                        onToggleBlockDate(key)
                                    }
                                }
                            }
                    ) {
                        Text(
                            text = "🟢 Tüm Ayı Müsait Yap",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF15803D),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFFEE2E2),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444)),
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                // Block weekends for this month
                                for (d in 1..daysInMonth) {
                                    val dayCal = Calendar.getInstance().apply {
                                        set(Calendar.YEAR, year)
                                        set(Calendar.MONTH, month)
                                        set(Calendar.DAY_OF_MONTH, d)
                                    }
                                    val dayOfWeek = dayCal.get(Calendar.DAY_OF_WEEK)
                                    if (dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY) {
                                        val key = String.format(Locale.ROOT, "%04d-%02d-%02d", year, month + 1, d)
                                        if (!blockedDates.contains(key)) {
                                            onToggleBlockDate(key)
                                        }
                                    }
                                }
                            }
                    ) {
                        Text(
                            text = "🔴 Hafta Sonlarını Kapat",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB91C1C),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Weekday Headers (Pzt, Sal, Çar, Per, Cum, Cmt, Paz)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("Pt", "Sa", "Ça", "Pe", "Cu", "Ct", "Pz").forEach { dayLabel ->
                    Text(
                        text = dayLabel,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = TextMuted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.width(36.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Days Grid
            val totalSlots = leadingEmptyDays + daysInMonth
            val totalRows = (totalSlots + 6) / 7

            for (row in 0 until totalRows) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    for (col in 0 until 7) {
                        val slotIndex = row * 7 + col
                        val dayNumber = slotIndex - leadingEmptyDays + 1

                        if (dayNumber in 1..daysInMonth) {
                            val dateKey = String.format(Locale.ROOT, "%04d-%02d-%02d", year, month + 1, dayNumber)
                            val isReserved = reservedDates.contains(dateKey)
                            val isPast = !isOwnerMode && dateKey < todayKey
                            val isBlocked = blockedDates.contains(dateKey) || isReserved || isPast
                            val isSelectedStart = selectedStartKey == dateKey
                            val isSelectedEnd = selectedEndKey == dateKey
                            val isInRange = selectedStartKey != null && selectedEndKey != null &&
                                    dateKey > selectedStartKey!! && dateKey < selectedEndKey!!

                            val isSelected = isSelectedStart || isSelectedEnd || isInRange

                            val cellBgColor = when {
                                isSelectedStart || isSelectedEnd -> BluePrimary
                                isInRange -> Color(0xFFDBEAFE)
                                isBlocked -> Color(0xFFFEE2E2) // RED when blocked/closed
                                else -> Color(0xFFDCFCE7) // GREEN when available (MÜSAİT)!
                            }

                            val cellBorderColor = when {
                                isSelectedStart || isSelectedEnd -> BluePrimary
                                isInRange -> BlueAccent
                                isBlocked -> Color(0xFFEF4444) // Crisp red border
                                else -> Color(0xFF22C55E) // Crisp green border!
                            }

                            val cellTextColor = when {
                                isSelectedStart || isSelectedEnd -> Color.White
                                isInRange -> BluePrimary
                                isBlocked -> Color(0xFFB91C1C) // Deep dark red
                                else -> Color(0xFF15803D) // Deep rich green!
                            }

                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(cellBgColor)
                                    .border(
                                        width = if (isSelectedStart || isSelectedEnd) 2.dp else 1.5.dp,
                                        color = cellBorderColor,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        if (isOwnerMode) {
                                            if (isReserved) onReservedDateClick(dateKey) else if (!ownerReadOnly) onToggleBlockDate(dateKey)
                                        } else {
                                            if (!isBlocked && selectionEnabled) {
                                                val st = selectedStartKey
                                                if (st == null || selectedEndKey != null) {
                                                    selectedStartKey = dateKey
                                                    selectedEndKey = null
                                                } else if (dateKey >= st) {
                                                    // Aralıkta dolu/rezerve/geçmiş gün varsa yeni başlangıç seç
                                                    val hasBlockedInside = com.example.util.DateUtils.expandRange(st, dateKey).any { kk ->
                                                        blockedDates.contains(kk) || reservedDates.contains(kk) || kk < todayKey
                                                    }
                                                    if (hasBlockedInside) {
                                                        selectedStartKey = dateKey
                                                    } else {
                                                        selectedEndKey = dateKey
                                                    }
                                                } else {
                                                    selectedStartKey = dateKey
                                                }
                                            }
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "$dayNumber",
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected || isBlocked || !isBlocked) FontWeight.Bold else FontWeight.Medium,
                                    color = cellTextColor
                                )
                            }
                        } else {
                            Spacer(modifier = Modifier.size(36.dp))
                        }
                    }
                }
            }

            // Calculation & Action Banner
            if (!isOwnerMode && daysCount > 0) {
                Spacer(modifier = Modifier.height(14.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFEFF6FF),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Seçilen Süre: $daysCount Gün",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )
                                val startStr = com.example.util.DateUtils.formatTr(selectedStartKey ?: "")
                                val endStr = if (selectedEndKey != null) com.example.util.DateUtils.formatTr(selectedEndKey!!) else startStr
                                Text(
                                    text = "$startStr - $endStr",
                                    fontSize = 12.sp,
                                    color = Color(0xFF475569)
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Tahmini Tutar",
                                    fontSize = 11.sp,
                                    color = Color(0xFF64748B)
                                )
                                Text(
                                    text = "₺${"%,.0f".format(Locale("tr", "TR"), estimatedPrice)}",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = BluePrimary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = {
                                val startStr = com.example.util.DateUtils.formatTr(selectedStartKey ?: "")
                                val endStr = if (selectedEndKey != null) com.example.util.DateUtils.formatTr(selectedEndKey!!) else startStr
                                onDateRangeSelected(startStr, endStr, daysCount, estimatedPrice)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("book_selected_dates_button"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                        ) {
                            Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Bu Tarihler İçin Teklif Ver",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            } else if (isOwnerMode) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = if (ownerReadOnly) "💡 Kırmızı (dolu) bir güne dokunarak o günü rezerve eden müşteriyi görebilirsiniz." else "💡 Tarihlere dokunarak dilediğiniz günleri kiralamaya kapatabilir veya açabilirsiniz.",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
private fun LegendBadge(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            color = TextSecondary,
            fontWeight = FontWeight.Medium
        )
    }
}
