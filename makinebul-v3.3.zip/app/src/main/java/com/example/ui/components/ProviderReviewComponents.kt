package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProviderJob
import com.example.data.model.ProviderStats
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusWarning
import java.util.Locale

/** "★ 4.7 (12 puan) • 15 görev" ya da hiç görevi yoksa "Yeni usta". */
fun ProviderStatsText(stats: ProviderStats): String =
    when {
        stats.completedJobs == 0 && stats.ratedCount == 0 -> "Yeni usta • henüz görev yok"
        stats.ratedCount == 0 -> "Henüz puan yok • ${stats.completedJobs} görev"
        else -> String.format(Locale.ROOT, "%.1f", stats.average) + " (${stats.ratedCount} puan) • ${stats.completedJobs} görev"
    }

/** Sağlayıcıya yapılan tüm yorumlar. */
@Composable
fun ProviderReviewsDialog(
    driverName: String,
    stats: ProviderStats,
    comments: List<ProviderJob>,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NavyDark,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Kapat", color = Color.White) } },
        title = {
            Column {
                Text(driverName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Star, contentDescription = null, tint = StatusWarning, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(ProviderStatsText(stats), color = Color.LightGray, fontSize = 12.sp)
                }
            }
        },
        text = {
            if (comments.isEmpty()) {
                Text("Bu usta için henüz yazılı yorum yok.", color = Color.LightGray, fontSize = 13.sp)
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 360.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(comments) { c ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(NavyLight.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                                .padding(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    c.customerName.ifBlank { "Müşteri" },
                                    color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                val r = (c.rating ?: 0.0).toInt()
                                Text("★".repeat(r) + "☆".repeat((5 - r).coerceAtLeast(0)), color = StatusWarning, fontSize = 12.sp)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(c.comment, color = Color.LightGray, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    )
}

/** Hizmet bitince müşteriye gösterilen yıldız + isteğe bağlı yorum kartı. */
@Composable
fun ProviderRatingCard(
    driverName: String,
    onSubmit: (rating: Int, comment: String) -> Unit
) {
    var stars by remember { mutableIntStateOf(0) }
    var comment by remember { mutableStateOf("") }
    var sent by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NavyDark),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, StatusAvailable.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (sent) {
                Text("Teşekkürler! Değerlendirmeniz kaydedildi. ✅", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            } else {
                Text("Hizmeti değerlendir", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(
                    "$driverName ile işiniz tamamlandı. Puanınız sonraki müşterilerin usta seçmesine yardımcı olur.",
                    color = Color.LightGray, fontSize = 12.sp, lineHeight = 16.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (i in 1..5) {
                        Icon(
                            imageVector = if (i <= stars) Icons.Filled.Star else Icons.Filled.StarBorder,
                            contentDescription = "$i yıldız",
                            tint = StatusWarning,
                            modifier = Modifier
                                .size(40.dp)
                                .clickable { stars = i }
                        )
                    }
                }
                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("Yorum (isteğe bağlı)") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        onSubmit(stars, comment.trim())
                        sent = true
                    },
                    enabled = stars > 0,
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                ) {
                    Text("Değerlendirmeyi Gönder", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
