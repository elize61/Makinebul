package com.example.ui.screens.machine

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RequestQuote
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.MachinePhoto
import com.example.util.MapLauncher
import com.example.util.WhatsAppLauncher
import com.example.data.model.Machine
import com.example.data.model.Review
import com.example.ui.components.AddReviewDialog
import com.example.ui.components.AvailabilityCalendar
import com.example.ui.components.ReviewSection
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusBusy
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun MachineDetailScreen(
    machine: Machine,
    isFavorite: Boolean,
    reviews: List<Review> = emptyList(),
    isOwnerView: Boolean = false,
    reservations: List<com.example.data.model.Offer> = emptyList(),
    onNavigateBack: () -> Unit,
    onRequestOfferClick: () -> Unit,
    onSendMessageClick: () -> Unit,
    onFavoriteToggle: () -> Unit,
    onShowOnMapClick: () -> Unit,
    onAddReview: (rating: Double, comment: String, tags: List<String>) -> Unit = { _, _, _ -> },
    onDateRangeSelectedForOffer: (startDate: String, endDate: String, daysCount: Int, calculatedPrice: Double) -> Unit = { _, _, _, _ -> },
    requireMember: (String, () -> Unit) -> Unit = { _, action -> action() }
) {
    val context = LocalContext.current
    var showReviewDialog by remember { mutableStateOf(false) }
    var reservationDateKey by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Makine Detayı", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Geri", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = onFavoriteToggle) {
                        Icon(
                            imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = "Favori",
                            tint = if (isFavorite) Color.Red else Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
            )
        },
        bottomBar = {
            if (!isOwnerView) Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            requireMember("İletişim") { WhatsAppLauncher.open(context, machine.ownerPhone,
                                "Merhaba, MakineBul'daki \"${machine.title}\" ilanınız hakkında bilgi almak istiyorum."
                            ) }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Filled.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("WhatsApp", fontSize = 13.sp)
                    }

                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            // Photo Gallery
            if (machine.photos.isNotEmpty()) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(machine.photos) { url ->
                        MachinePhoto(
                            model = url,
                            contentDescription = machine.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .width(300.dp)
                                .height(200.dp)
                                .clip(RoundedCornerShape(14.dp))
                        )
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .background(NavyDark),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Construction, contentDescription = null, tint = BlueAccent, modifier = Modifier.size(64.dp))
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header Details Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = BluePrimary.copy(alpha = 0.1f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = machine.category,
                                    color = BluePrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }

                            val statusColor = if (machine.isAvailable) StatusAvailable else StatusBusy
                            val statusText = if (machine.isAvailable) "Müsait" else "Dolu"
                            Surface(
                                color = statusColor,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = statusText,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = machine.title,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "${machine.brand} • ${machine.model} • ${machine.year} Model",
                            fontSize = 14.sp,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Features Badges Row
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (machine.hasOperator) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = StatusSuccess.copy(alpha = 0.12f)
                                ) {
                                    Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Person, contentDescription = null, tint = StatusSuccess, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Operatör Dahil", fontSize = 11.sp, color = StatusSuccess, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (machine.fuelIncluded) BluePrimary.copy(alpha = 0.12f) else NavyElevated
                            ) {
                                Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.LocalGasStation, contentDescription = null, tint = if (machine.fuelIncluded) BluePrimary else TextMuted, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        if (machine.fuelIncluded) "Yakıt Dahil" else "Yakıt Hariç",
                                        fontSize = 11.sp,
                                        color = if (machine.fuelIncluded) BluePrimary else TextSecondary,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            if (machine.isLowbedTransport || machine.category.contains("Lowbed", ignoreCase = true)) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFF7C3AED).copy(alpha = 0.12f)
                                ) {
                                    Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.LocalShipping, contentDescription = null, tint = Color(0xFF7C3AED), modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Ağır Nakliye / Lowbed", fontSize = 11.sp, color = Color(0xFF7C3AED), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Filled.LocationOn, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(18.dp))
                            Text(
                                text = listOf(machine.address, machine.district, machine.city).filter { it.isNotBlank() }.joinToString(", "),
                                fontSize = 13.sp,
                                color = TextPrimary,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                            if (machine.latitude != 0.0 && machine.longitude != 0.0) {
                                MapLauncher.openLocation(context, machine.latitude, machine.longitude, machine.title)
                            } else {
                                MapLauncher.openAddress(context, listOf(machine.address, machine.district, machine.city).filter { it.isNotBlank() }.joinToString(", "))
                            }
                        },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Filled.Map, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Haritada Gör", fontSize = 13.sp)
                        }

                        if (!machine.isAvailable) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Bu ilan şu anda pasif. Teklif verilemez ve kiralanamaz.",
                                color = StatusBusy,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }

                // Pricing Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Saatlik Ücret", fontSize = 12.sp, color = TextMuted)
                            Text(
                                text = "₺${machine.hourlyPrice.toInt()}",
                                fontSize = 19.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = BluePrimary
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Günlük Ücret", fontSize = 12.sp, color = TextMuted)
                            Text(
                                text = "₺${machine.dailyPrice.toInt()}",
                                fontSize = 19.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = BluePrimary
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Min. Çalışma", fontSize = 12.sp, color = TextMuted)
                            Text(
                                text = "${machine.minWorkingHours} Saat",
                                fontSize = 19.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                    }
                }

                // Interactive Availability Calendar Card
                AvailabilityCalendar(
                    blockedDates = machine.blockedDates,
                    dailyPrice = machine.dailyPrice,
                    hourlyPrice = machine.hourlyPrice,
                    isOwnerMode = isOwnerView,
                    ownerReadOnly = isOwnerView,
                    reservedDates = machine.reservedDates,
                    selectionEnabled = machine.isAvailable,
                    onReservedDateClick = { reservationDateKey = it },
                    onDateRangeSelected = { startDate, endDate, daysCount, calculatedPrice ->
                        onDateRangeSelectedForOffer(startDate, endDate, daysCount, calculatedPrice)
                    }
                )

                // Description Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Açıklama & Ekipman Özellikleri", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = machine.description,
                            fontSize = 14.sp,
                            color = TextSecondary,
                            lineHeight = 20.sp
                        )
                    }
                }

                // Reviews Section
                ReviewSection(
                    reviews = reviews,
                    averageRating = machine.rating,
                    showAddButton = !isOwnerView,
                    onAddReviewClick = { showReviewDialog = true }
                )

                // Owner & Contact Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Makine Sahibi / Tedarikçi", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(machine.ownerName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Star, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(16.dp))
                                    Text(if (reviews.isNotEmpty()) " ${String.format(java.util.Locale.ROOT, "%.1f", reviews.map { it.rating }.average())} (${reviews.size} Değerlendirme)" else if (machine.reviewCount > 0) " ${machine.rating} (${machine.reviewCount} Değerlendirme)" else " Henüz değerlendirme yok", fontSize = 13.sp, color = TextMuted)
                                }
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                IconButton(
                                    onClick = {
                                        requireMember("İletişim numarası") { val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${machine.ownerPhone}")); context.startActivity(intent) }
                                    },
                                    modifier = Modifier
                                        .size(42.dp)
                                        .background(BluePrimary, CircleShape)
                                ) {
                                    Icon(Icons.Filled.Call, contentDescription = "Ara", tint = Color.White)
                                }

                                IconButton(
                                    onClick = {
                            if (machine.latitude != 0.0 && machine.longitude != 0.0) {
                                MapLauncher.openLocation(context, machine.latitude, machine.longitude, machine.title)
                            } else {
                                MapLauncher.openAddress(context, listOf(machine.address, machine.district, machine.city).filter { it.isNotBlank() }.joinToString(", "))
                            }
                        },
                                    modifier = Modifier
                                        .size(42.dp)
                                        .background(NavyDark, CircleShape)
                                ) {
                                    Icon(Icons.Filled.Map, contentDescription = "Konum", tint = Color.White)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }

    // Add Review Dialog
    if (showReviewDialog) {
        AddReviewDialog(
            targetTitle = machine.title,
            onDismiss = { showReviewDialog = false },
            onSubmit = { rating, comment, tags ->
                onAddReview(rating, comment, tags)
                showReviewDialog = false
            }
        )
    }

    // Sahip görünümü: rezerve güne dokununca rezerve eden müşteri bilgisi
    reservationDateKey?.let { key ->
        val matches = reservations.filter { o ->
            com.example.util.DateUtils.expandRange(o.startDate, o.endDate).contains(key)
        }
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { reservationDateKey = null },
            confirmButton = {
                androidx.compose.material3.TextButton(onClick = { reservationDateKey = null }) { Text("Kapat") }
            },
            title = { Text(com.example.util.DateUtils.formatTr(key) + " - Rezervasyon", fontWeight = FontWeight.Bold, fontSize = 17.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (matches.isEmpty()) {
                        Text("Bu gün için kayıtlı bir müşteri teklifi bulunamadı. Gün, teklif dışında doluya alınmış olabilir.", fontSize = 13.sp, color = TextSecondary)
                    }
                    matches.forEach { o ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(NavyDark.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(o.customerName.ifBlank { "Müşteri" }, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Tarih: ${com.example.util.DateUtils.formatTr(o.startDate)} - ${com.example.util.DateUtils.formatTr(o.endDate)}", fontSize = 13.sp)
                            if (o.location.isNotBlank()) Text("Yer: ${o.location}", fontSize = 13.sp)
                            Text("Anlaşılan bedel: ₺${o.offeredPrice.toInt()}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = BluePrimary)
                            if (o.customerPhone.isNotBlank()) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                                    Button(
                                        onClick = { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${o.customerPhone}"))) },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                    ) {
                                        Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Ara", fontSize = 13.sp, maxLines = 1, softWrap = false)
                                    }
                                    OutlinedButton(
                                        onClick = { WhatsAppLauncher.open(context, o.customerPhone, "Merhaba, MakineBul'daki \"${machine.title}\" rezervasyonunuzla ilgili yazıyorum.") },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp)
                                    ) {
                                        Icon(Icons.Filled.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("WhatsApp", fontSize = 13.sp, maxLines = 1, softWrap = false)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        )
    }
}
