# v3.9 - Karşılıklı puanlama, profil düzenleme, Google hesap türü

- Karşılıklı puanlama: İş tamamlandığında iki taraf da birbirini 1-5 yıldız ve isteğe bağlı yorumla puanlar.
  - Acil çağrı: müşteri sağlayıcıyı, sağlayıcı (nöbetçi çekici/lastikçi) müşteriyi puanlar.
  - Kiralama: tamamlanan teklifte makine sahibi müşteriyi, müşteri makine sahibini puanlar.
  - Puanlar yeni "ratings" koleksiyonunda tutulur; her iş için her taraf bir kez puan verebilir.
- Puanlar yalnızca giriş yapmış kullanıcılar tarafından görülebilir (Firestore kuralı ile de korunur).
  - Makine detayında ilan sahibinin "Puanları gör" bağlantısı.
  - Profilde "Aldığım Puanlar ve Yorumlar" ekranı.
- Google ile giriş: ana butona basınca hesap türü seçilir (Müşteri / Makine Sahibi / Çekici / Lastikçi), sonra Google ile giriş yapılır.
- Profil düzenleme ekranı eklendi:
  - Profil fotoğrafı (küçültülerek kaydedilir).
  - Ad soyad, telefon, il, ilçe ve dükkan/işletme adresi.
  - Şifre değiştirme (mevcut şifre ile doğrulama gerekir; yalnızca e-posta/şifre hesaplarında).
  - E-posta değiştirme: yeni adrese doğrulama bağlantısı gönderilir, onaylanana kadar e-posta değişmez.
- Firestore kuralları: "ratings" koleksiyonu için kurallar eklendi. Kuralları yayınlamadan önce yeni sürümü dağıtmayın.
- Sürüm: 3.9

# v3.8 - Google girişi düzeltmesi

- Google ile giriş "yapılandırılmamış" hatası veriyordu. Kaynak paketi (namespace com.example) ile uygulama kimliği (com.reisgamestudio.makinebul) farklı olduğu için web client id bulunamıyordu. Artık her iki paket adıyla da aranıyor.

