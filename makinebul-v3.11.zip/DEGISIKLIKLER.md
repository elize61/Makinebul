# v3.11 - Google hesap türü, puan özeti, admin ilan düzenleme, tek kullanıcı koleksiyonu

- Google ile girişte yönlendirme artık hesabın gerçek türüne göre yapılır (seçilen role değil).
- Puanlar kullanıcının ortalama puanına (rating, ratingCount) yansır; her yeni puanda yeniden hesaplanır.
- Admin paneli: ilan satırlarında "Düzenle" düğmesi eklendi.
- Kullanıcılar artık tek koleksiyonda ('kullanıcılar') tutuluyor. Eski 'users' koleksiyonu silinmez.
  - Admin panelinde "Kullanıcı Koleksiyonunu Birleştir" düğmesi ile eski kayıtlar 'kullanıcılar'a kopyalanır (mevcut kayıtlar değişmez).
  - Bu düğmeyi bir kez çalıştırın; sonra yeni yazmalar yalnızca 'kullanıcılar'a gider.
- Sürüm: 3.11

