# v3.7 - Rol seçimi ve gizlilik metni güncellemesi

- Hızlı kayıtta rol doğrudan seçiliyor: Makine / Araç Sahibi, Çekici veya Lastikçi.
  - Çekici/Lastikçi seçilince başvuru formu açılmıyor; hesap doğrudan ilgili panele (çekici veya lastikçi) açılıyor.
  - Not: Bu rollerde yönetici onayı beklenmiyor. Onay istenirse hesap "beklemede" durumunda açılacak şekilde eklenebilir.
- Google ile devam de aynı rol seçimini kullanıyor.
- Aydınlatma metni: iletişim e-postası ve tarih (24.11.2026) güncellendi.

# v3.6 - KVKK ve hesap yönetimi

- Aydınlatma Metni ve Gizlilik Politikası uygulama içine eklendi (Profil ve karşılama ekranından açılır). Aynı metin `gizlilik-politikasi.md` dosyasında.
- Hızlı kayıtta aydınlatma metnini okuma onayı zorunlu.
- Profilde "Hesabımı Sil": kullanıcı profili ve ilanları silinir (teklif/mesaj kayıtları yasal süre için saklanabilir).
- Acil çağrı ekranında konumun kullanım amacı yazıyor.
- Firestore kuralı: kullanıcı kendi profil belgesini silebilir.
- Yayın öncesi: `[Şirket Ünvanı]`, `[E-posta adresi]`, `[Adres]` ve `[tarih]` yer tutucuları gerçek bilgilerle değiştirilmeli.

# v3.5 - Gizlilik, kayıt ve giriş düzeltmeleri

- **Telefon gizliliği:** İlan telefonu artık herkese açık `makineler` belgesinde tutulmuyor. `machineContacts/{ilanId}` belgesinde saklanıyor ve yalnızca gerçek giriş yapmış kullanıcılar okuyabiliyor (misafir/anonim okuyamaz).
  - Eski ilanlardaki telefon numaraları ilan tekrar kaydedilene kadar eski belgede kalır. Sahipler ilanı bir kez kaydederse temizlenir.
- **Hızlı kayıt:** Telefon Türkiye cep formatında kontrol ediliyor (5 ile başlayan 10 hane, 0 veya +90 kabul). Ad soyad tek isim de kabul ediliyor.
- **Profil yazımı:** Firestore profil yazılamazsa Firebase hesabı silinir ve kullanıcı tekrar denemeye yönlendirilir (yarım hesap kalmaz).
- **Kayıt sonrası:** E-posta doğrulama bağlantısı gönderiliyor (giriş engellenmiyor).
- **Google:** Aynı e-posta ile şifreli hesap varsa net bir uyarı çıkıyor.
- **Ilan verme:** Geçerli cep telefonu zorunlu.
- **Çıkış:** Karşılama ekranına dönülüyor.


# v3.4 - Karşılama ekranı, misafir modu, Google girişi

## Yeni ilk açılış (WelcomeScreen)
- Uygulama artık girişe zorlamıyor; oturum yoksa karşılama ekranı açılır.
- **MAKİNENİ VEYA ARACINI EKLE** (turuncu): Ad-Soyad + Telefon ile hızlı esnaf kaydı veya Google ile tek tıkla; sonra doğrudan ilan ekleme ekranına gider.
- **ÜYE OLMADAN İLANLARA GÖZ AT** (lacivert): üyesiz ana sayfa, arama ve harita.
- **YOLDA MI KALDINIZ?** (kırmızı): üyesiz acil çekici/lastikçi çağrısı.
- **Google ile Tek Tıkla Devam Et** (beyaz): Credential Manager ile Firebase Authentication; kullanıcı kaydı yoksa otomatik oluşturulur.
- **Zaten hesabın var mı? Giriş Yap**: mevcut giriş ekranı.

## Misafir modu
- Girişsiz ana sayfa, arama, harita ve ilan detayı açık.
- Giriş penceresi yalnızca şu eylemlerde açılır: İlan verme, Teklif verme, Mesaj gönderme, İletişim numarası / WhatsApp, Favori ekleme, Profil.

## Firestore kuralları
- machines / makineler, reviews ve categories koleksiyonları girişsiz okunabilir (yazma kuralları değişmedi).

## Firebase Console'da yapılması gerekenler
1. Authentication > Sign-in method: **Google** sağlayıcısını etkinleştir.
2. Proje ayarları > Uygulamanız: SHA-1 ve SHA-256 parmak izlerini ekle (Play'deki yükleme anahtarı ve uygulama imzası).
3. Google sağlayıcısı açılınca güncel google-services.json indirilip projeye konur (içinde web client id olmalı).
4. firestore.rules dosyasını Firestore > Rules bölümüne yayınla.


# Yapılan düzeltmeler

## Güvenlik
- firestore.rules / storage.rules: `if true` kaldırıldı. Giriş zorunlu; rol ADMIN'e istemciden yükseltilemez;
  makine/teklif/mesaj/yorum/başvuru yazma-silme sahiplik kontrollü; tanımsız koleksiyonlar kapalı;
  Storage'a yalnızca <5 MB görsel yazılabilir.
- Kuralları yayınlamak için: `firebase deploy --only firestore:rules,storage`
- İlk yönetici Firebase konsolundan elle atanmalı (users/{uid} -> rol: "ADMIN").
- Konsolda **Anonymous Authentication** açık olmalı (dinleyiciler oturum açılınca başlıyor).

## Yayın
- Release artık debug keystore ile imzalanmıyor (KEYSTORE_PATH, STORE_PASSWORD, KEY_ALIAS, KEY_PASSWORD gerekli).
- R8 + shrinkResources açıldı, proguard kuralları eklendi.
- allowBackup=false; kullanılmayan CAMERA, CALL_PHONE, READ_MEDIA_IMAGES, READ_EXTERNAL_STORAGE izinleri kaldırıldı.

## Demo / sahte veri (artık yalnızca debug build)
- Şifresiz demo giriş (example.com / demo*), hızlı test giriş butonları, loginAsDemo
- Sahte otomatik çekici teklifleri, "Simüle Et" kartı
- Açılışta istemci tarafı veri temizliği
- Varsayılan puan 4.8/4.9, 12 yorum, "telefon doğrulandı", İstanbul/Kadıköy varsayılanları sıfırlandı.

## Altyapı
- FirebaseManager.runWhenAuthenticated: tüm Firestore dinleyicileri oturum varken başlar, yoksa anonim giriş yapılır.

## Yapılmadı / sonraki adımlar
- Mesaj, teklif ve acil çağrı okuma izinleri "giriş yapmış herkes". Sorguları kullanıcıya göre daraltıp kuralı sıkılaştırın.
- FCM (arka plan bildirimi), App Check, API anahtarı kısıtlaması.
- users/kullanıcılar ve machines/makineler çift koleksiyonunun birleştirilmesi.
- Büyük dosyaların bölünmesi, ViewModel'e geçiş, Tasks.await -> await(), gerçek testler.
- public/index.html web panelindeki sahte Firebase ayarları gerçek değerlerle değiştirilmeli.

## Harita (ücretsiz / OpenStreetMap)
- Tüm haritalar osmdroid + OpenStreetMap (API anahtarı yok). Eski Canvas tabanlı `EmergencyLiveMap.kt` silindi.
- Google Maps bağımlılıkları (maps-compose, play-services-maps/location), MAPS_API_KEY ve Google Play Services kontrolü kaldırıldı.
- "Yol tarifi / haritada aç" artık `geo:` niyeti (telefondaki herhangi bir harita uygulaması) ya da openstreetmap.org bağlantısı kullanıyor.
- OSM lisansı gereği harita üstüne atıf (© OpenStreetMap) eklendi; tile önbelleği uygulama içinde, depolama izni gerekmiyor.
- Not: tile.openstreetmap.org yoğun kullanım için tasarlanmadı. Kullanıcı sayısı artarsa kendi tile sunucunuzu ya da MapTiler/Stadia gibi ücretsiz planlı bir sağlayıcıyı kullanın.
- Sahte "AdMob test banner" release'te gizlendi.

## v2 — Demo temizliği ve Google Haritalar
- Tüm demo/test kodu silindi: hızlı demo giriş butonları, şifresiz demo girişi, DemoDataProvider, "demo_" kullanıcı kimlikleri,
  sahte otomatik çekici teklifleri, "Simüle Et" kartı, AdMob test banner'ı, açılışta otomatik veri temizliği.
  (Yönetici panelindeki elle temizlik butonu duruyor.)
- Firebase bağlanamazsa artık sahte kullanıcıyla girilmiyor; hata mesajı gösteriliyor.
- "Haritada aç" / "Yol tarifi" / "Navigasyon" butonları telefonda kurulu Google Haritalar uygulamasını açar
  (util/MapLauncher.kt). Kurulu değilse başka bir harita uygulaması, o da yoksa tarayıcı. API anahtarı gerekmez.
- Uygulama içi harita hâlâ ücretsiz OpenStreetMap.

## v2.1 — Yönetici temizlik araçları
- Yönetici Paneli → "Veritabanı & Arşiv" sekmesine eklendi:
  - "Eski Demo/Test Kayıtlarını Sil": kimliği "demo" ile başlayan ilan, teklif, mesaj, acil çağrı, yorum vb. siler.
  - "Tüm Açık Acil Çağrıları Kapat": tamamlanmamış tüm acil çağrıları İPTAL yapar.

## v2.2 — Yönetici rolü düzeltmesi
- Giriş sırasında hem `kullanıcılar` hem `users` okunur; ikisinden biri ADMIN ise yönetici kalır.
- Mevcut bir profil girişte artık Firestore'a yeniden yazılmaz (rol "MÜŞTERİ"ye ezilmez).
- Yöneticiler "müşteri/mal sahibi" geçişiyle rolünü kaybedemez.
- Sahte 5.0 puan ve İstanbul/Kadıköy varsayılanları kaldırıldı.

## v2.3 — Çekici paneli, alt menü, mükerrer kart
- Çekici/lastikçi panelinde sabit "Ümraniye, İstanbul" yazısı kaldırıldı. Yerine düzenlenebilir "Dükkan Adresi" kartı geldi.
  Adres kaydedilirken OpenStreetMap (Nominatim) ile koordinata çevrilir ve kullanıcı belgesine `shopAddress`, `latitude`, `longitude` olarak yazılır.
  Çağrı eşleştirme ve haritadaki çekici başlangıç konumu bu koordinatı kullanır. Adres girilmeden hizmet açılamaz.
- Çekici/lastikçi profilinde "Hızlı Menü" kaldırıldı.
- Alt menü artık ana kapsayıcı dışındaki tüm sayfalarda da görünür (harita, acil çağrı, ilan detayı, mesaj, yönetim vb.) ve sekmeye geçişi çalıştırır.
- Müşteri acil çağrı ekranından üyeliksiz "Hızlı Acil Çağrı" kartı kaldırıldı (giriş ekranındaki üyeliksiz çağrı butonu duruyor).
- GeocodeUtils: ifade gövdeli fonksiyonlardaki return derleme hatası düzeltildi.

## v2.3
- Admin: Hızlı Yönetim kartı ve profildeki "Hızlı Menü" başlığı kaldırıldı; kullanıcıya "Mesaj Gönder"; "Şikayetler & Talepler" ve "Onay Bekleyen İlanlar" sekmeleri.
- Askıya alınan hesap (isSuspended / status=SUSPENDED) giriş yapamaz: "Hesabınız yönetici tarafından askıya alınmıştır".
- Müşteri/hizmet veren profilinde "Şikayet / Destek Bildir" formu (reports koleksiyonu).
- İlan: açılır kategori, en fazla 3 galeri fotoğrafı (Storage), adresten konum, yeni ilan status=pending; müşteriler yalnız approved + aktif ilanları görür.
- Haritada Gör ilanın kendi koordinatını Google Haritalar'da açar; Mesaj butonları WhatsApp'a yönlenir.
- Ana sayfa: sade yatay kategori çipleri.
- Çekici/lastikçi: teklifte plaka girilir (sabit plaka ve sahte sürücüler kaldırıldı); onaylanan teklifte talep diğer sürücülerden düşer.
- Pasif ilanda teklif kapalı; onaylanan teklifin tarihleri reservedDates'e yazılır, takvimde kırmızı/seçilemez.
- Grup bildirimleri yalnız çevrimiçi ve ≤50 km sağlayıcılara.
- firestore.rules güncellendi (YENİDEN YAYINLAYIN).

## v2.4
- Sahte varsayılanlar kaldırıldı (puan/yorum/mesafe, sahte isim-telefon-plaka, örnek tarih/konum, "Kaskolu" rozeti, demo kimlikleri); yeni kayıtlar "Yeni" olarak görünür.
- Mesajlar yalnızca gönderen/alıcıya açık (iki sorgu); kullanıcı listesi yalnızca yönetici veya çevrimiçi sürücü sorgusuna açık. firestore.rules güncellendi.
- Askıya alınan kullanıcı oturum açıkken anında çıkarılır.
- İlan reddinde sebep yazılır, ilan sahibine bildirim gider; onayda da bildirim.
- rezerve günler arrayUnion ile eklenir; okunamayan tarihli teklif engellenir.
- Galeri fotoğrafları EXIF yönüne göre düzeltilir. Çevrimdışı sürücü listeleri doğru boşalır.

## v2.5
- Acil çekici/lastikçi talebi artık **gerçek, anlık GPS konumu** olmadan gönderilemez. Sahte "İstanbul merkezi" varsayılan konumu tamamen kaldırıldı; konum alınamazsa net hata gösterilir.
- Çekici/lastikçi **yola çıkınca** uygulama, arka planda çalışan bir konum servisiyle (bildirimde "Konumunuz müşteriyle canlı paylaşılıyor" görünür) gerçek GPS'ini `emergencyRequests` kaydına yazar; müşteri haritada sürücüyü canlı görür, harita iki noktayı kapsayacak şekilde yakınlaşır, kalan km ve dk canlı hesaplanır. Sahte (simüle) hareket kaldırıldı.
- **Talep Havuzu** ve **Dijital Teslim Tutanağı** özellikleri tamamen kaldırıldı (ekranlar, kartlar, rotalar, modeller, depolar, harita pinleri). Firestore kurallarında eski koleksiyonlar sadece yöneticiye açık bırakıldı.
- Manifest: FOREGROUND_SERVICE + FOREGROUND_SERVICE_LOCATION izinleri ve `DriverLocationService` eklendi.
- Güncel `firestore.rules` dosyasını Firebase'de yeniden yayınlayın.

## v2.5.1
- "PAS GEÇ" artık talebi iptal etmiyor; talep yalnızca o sürücünün (çekici veya lastikçi) listesinden gizleniyor. Diğer sürücülerde ve müşteride talep aynen devam ediyor.

## v2.5.2
- GitHub iş akışı artık hem debug APK hem Play Console için imzalı AAB üretir. İlk çalıştırmada yükleme anahtarı otomatik üretilir ve "ANAHTAR-SAKLA-kaybetme" paketinde verilir; GitHub Secrets'a eklenirse sonraki sürümlerde aynı anahtar kullanılır.
- versionCode her çalıştırmada otomatik artar (GitHub çalıştırma numarası).
- Release derlemesinde küçültme (R8) kapatıldı (test edilemediği için çökme riskine karşı).

## v2.5.3
- Uygulama kimliği `com.reisgamestudio.makinebul` oldu. google-services.json'a geçici olarak bu paket adı için kayıt eklendi; Firebase'de bu paket adıyla Android uygulaması eklenip yeni google-services.json ile değiştirilmesi önerilir.

## v2.5.4
- Firebase'den alınan gerçek google-services.json (com.reisgamestudio.makinebul) yerleştirildi.

## v2.6
- 5 temalı görünüm sistemi: Koyu (varsayılan), Açık, Mavi, Yeşil, Mor. Hepsinde turuncu acil çağrı vurgusu. Profil → "🎨 Uygulama Teması" ile seçilir, seçim telefonda hatırlanır.
- Ana sayfadaki "7/24 acil yol yardım" bandı turuncu yapıldı.
- Not: Açık temada eski, koyu zemin için tasarlanmış bazı ekranlar kısmen koyu kalabilir.

## v2.7
- Çoklu tema sistemi kaldırıldı; uygulama önceki tek temasına döndü.
- Boyacı, Sıva, Elektrik, Tesisat, Fayans, Zemin, Çatı, İnşaat Ustası, Hafriyat ve "Acil Çekici & Lastikçi" ilan kategorileri kaldırıldı; ilan kategorileri yalnızca iş makineleri. Ana sayfa başlığı "İş Makinesi Kiralama".
- Not: Eski ilanlar kaldırılan kategorilerde kayıtlıysa veritabanında durur; Admin → Veri temizliği ile silinebilir.

## v2.8
- Kartsız fotoğraf yöntemi: makine fotoğrafları Firebase Storage yerine küçültülüp ilanın içine (Firestore) gömülür. Fotoğraf başına ~180 KB sınırı, en fazla 3 fotoğraf. Storage/Blaze gerekmez.
- Fotoğraflar `MachinePhoto` bileşeniyle gösterilir (gömülü ve https adresleri birlikte desteklenir).
- Firestore'a aynı fotoğraf listesini ikinci kez yazan "fotograflar" kopyası kaldırıldı (belge boyutu sınırı için).

## v3.0 - Yeniden tasarım
- Tek koyu lacivert tema; sistemin açık/koyu moduna bağlı değil. Yeni renk jetonları (NavyElevated, OrangeCta), daha okunur metin renkleri (koyu zeminde koyu yazı sorunu giderildi).
- Tüm ekranlara yansıyan yeni köşe yuvarlaklıkları (Shapes) ve tam tipografi seti.
- Yeni ilan kartı (büyük fotoğraf, fiyat ve müsaitlik rozetleri, çipler), yeni ana sayfa başlığı ve kategori çipleri, turuncu acil çağrı bandı, modern alt menü ve profil satırları.
- Hata düzeltmeleri: ilan/talep konumu bilinmediğinde sahte İstanbul koordinatı kullanılmıyor; "Haritada Gör" konum yoksa adresle arıyor.

## v3.1
- İlan kartı kompakt hale getirildi (solda küçük fotoğraf, sağda bilgiler ve "Teklif İste"); ana sayfa, arama ve favorilerde ekranda daha fazla ilan görünür. "Haritada Gör" kutusu ince şeride çevrildi.

## v3.2 - Toplu düzenleme (15 madde)
- **Acil yol yardım bandı** yenilendi: gradyanlı, kompakt kart; "Çekici Çağır" ve "Lastikçi Çağır" düğmeleri.
- **Mesajlar sekmesi** tüm alt menülerden kaldırıldı (iletişim WhatsApp / Ara).
- **Ortalama puan** makine detayında yorumlardan gerçek hesaplanıyor (0.0 hatası giderildi).
- **"Teklif İste"** kaldırıldı: detay ekranında sadece WhatsApp; teklif takvimden "Bu Tarihler İçin Teklif Ver" ile. İlan kartında "Teklif Ver".
- **Takvim**: seçim artık ISO tarihle tutuluyor; birden çok aya yayılan (2-3-5 ay) seçim çalışıyor. Özet kartı okunur renkte, ay başlığı tek satırda.
- **Teklif penceresi**: "Günlük Saat" alanı + "N gün × H saat = toplam saat" satırı; tarih alanları sığıyor; "31 Kasım" gibi yanlış ay adı düzeltildi.
- **Makine sahibi**: ilanına dokununca detay açılır; takvimde kırmızı (rezerve) güne dokununca rezerve eden müşteri, tarih, bedel, yer, Ara ve WhatsApp görünür.
- **Acil teklif kartı**: Ara/WhatsApp butonları düzeltildi (yazılar bölünmüyor), "Kabul Et" altta tam genişlik.
- **Gerçek puan ve görev sayısı**: sahte "184 görev" kaldırıldı. Her tamamlanan görev `providerJobs` kaydına yazılır (+1 görev). Müşteri hizmet bitince yıldız verir ve isterse yorum yazar; ortalama, görev sayısı ve yorumlar teklif kartında görünür ("Tüm yorumlar" ile açılır). Lastikçi için de aynı.
- **Çekici/lastikçi paneli**: durum etiketleri sağlayıcı diliyle ("Müşteriye gidiyorsunuz" vb.); kesilen başlık ve alta taşan navigasyon butonu düzeltildi.
- **Admin**: Profilim ekranında gereksiz menüler kaldırıldı. Yönetim Paneli'ne rol değiştirme, kullanıcı silme ve "Acil Çağrılar" sekmesi (iptal/sil) eklendi.

**Firestore kuralları güncellendi** (`firestore.rules`): yeni `providerJobs` koleksiyonu. Firebase Konsolu → Firestore → Kurallar bölümüne dosyanın tamamını yapıştırıp Yayınla demen gerekir; yoksa puan/görev sayısı kaydedilmez.
Not: Admin panelinden ilan düzenleme ve teklif/yorum silme henüz yok; kullanıcı silme sadece veritabanı kaydını siler (giriş hesabı Authentication'da kalır).
Kod bu ortamda derlenemedi; derleme hatası çıkarsa GitHub çıktısını gönder.

## v3.3 - Play Console önerileri
- **Kod küçültme/karartma (R8)** release derlemesinde açıldı (`isMinifyEnabled` + `isShrinkResources`). Play'deki "DEX kodu optimizasyonu eşiğin altında" uyarısı için. Modeller, Firebase, Retrofit/OkHttp ve osmdroid için koruma kuralları `proguard-rules.pro` içinde. AAB ile birlikte eşleme (mapping) dosyası Play'e otomatik yüklenir.
- **androidx.fragment** 1.1.0 yerine 1.8.5 (güncel olmayan SDK uyarısı).
- **Uçtan uca ekran (Android 15)**: sistem çubukları için boşluk uygulama köküne eklendi; kullanımdan kalkan `statusBarColor` / `navigationBarColor` çağrıları kaldırıldı, çubuklar saydam.
- Önemli: R8 açıldığı için yeni sürümde mutlaka release APK/AAB ile test et (giriş, ilan, harita, acil çağrı, fotoğraf). Bir şey çökerse GitHub çıktısını veya hata mesajını gönder; kural eklenir.
- Derleme düzeltmesi: Kodda Room ve Moshi kod üretimi hiç kullanılmıyordu; KSP eklentisi ("ApplicationManager.getApplication() is null" hatasını veriyordu) kaldırıldı.
