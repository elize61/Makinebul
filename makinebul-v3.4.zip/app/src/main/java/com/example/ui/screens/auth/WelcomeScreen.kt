package com.example.ui.screens.auth

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyElevated
import com.example.ui.theme.NavyLight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

private val AmberCta = Color(0xFFFBA81F)
private val EmergencyRed = Color(0xFF7F1D2D)
private val EmergencyBorder = Color(0xFFEF4444)

private fun Context.findActivity(): Context {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return this
}

/**
 * İlk açılış ekranı. Girişe zorlamaz: esnaf kaydı, misafir gezinti, acil çağrı, Google girişi ve giriş seçenekleri sunar.
 * [onGoogleSignIn] ikinci parametre "esnaf olarak mı" bilgisidir.
 */
@Composable
fun WelcomeScreen(
    onQuickRegister: suspend (fullName: String, phone: String) -> Result<Unit>,
    onGoogleSignIn: suspend (activityContext: Context, wantOwner: Boolean) -> Result<Unit>,
    onOwnerReady: () -> Unit,
    onSignedIn: () -> Unit,
    onBrowseAsGuest: () -> Unit,
    onEmergency: () -> Unit,
    onLogin: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showOwnerDialog by remember { mutableStateOf(false) }
    var googleBusy by remember { mutableStateOf(false) }

    fun startGoogle(wantOwner: Boolean) {
        if (googleBusy) return
        googleBusy = true
        scope.launch {
            val r = onGoogleSignIn(context.findActivity(), wantOwner)
            googleBusy = false
            r.fold(
                onSuccess = { if (wantOwner) onOwnerReady() else onSignedIn() },
                onFailure = { Toast.makeText(context, it.message ?: "Google girişi yapılamadı.", Toast.LENGTH_LONG).show() }
            )
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0E1D38), NavyDark)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Filled.Construction, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(56.dp))
            Text("MakineBul", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
            Text("İş Makinesi & Özel Araç Platformu", color = BlueAccent, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(10.dp))

            // Kahraman şeridi
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(96.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF1B3556), Color(0xFF3A2A12), Color(0xFF1B3556)))),
                contentAlignment = Alignment.Center
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(22.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Engineering, null, tint = AmberCta, modifier = Modifier.size(40.dp))
                    Icon(Icons.Filled.Construction, null, tint = AmberCta, modifier = Modifier.size(52.dp))
                    Icon(Icons.Filled.LocalShipping, null, tint = AmberCta, modifier = Modifier.size(48.dp))
                    Icon(Icons.Filled.DirectionsCar, null, tint = AmberCta, modifier = Modifier.size(40.dp))
                }
            }

            Spacer(Modifier.height(14.dp))
            Text("Makinen veya Hizmet Aracın mı Var?", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text(
                "Ücretsiz ilanını ekle, bölgedeki müşterilere anında ulaş, işini büyüt!",
                color = TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(14.dp))

            // 1) Turuncu: esnaf kaydı
            Button(
                onClick = { showOwnerDialog = true },
                modifier = Modifier.fillMaxWidth().height(62.dp).testTag("welcome_add_machine"),
                shape = RoundedCornerShape(32.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AmberCta, contentColor = Color(0xFF111827))
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("MAKİNENİ VEYA ARACINI EKLE", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    Text("Ücretsiz Esnaf / Sahip Kaydı", fontSize = 12.sp, maxLines = 1)
                }
            }
            Spacer(Modifier.height(10.dp))

            // 2) Lacivert: misafir
            Button(
                onClick = onBrowseAsGuest,
                modifier = Modifier.fillMaxWidth().height(62.dp).testTag("welcome_browse"),
                shape = RoundedCornerShape(32.dp),
                colors = ButtonDefaults.buttonColors(containerColor = NavyElevated, contentColor = Color.White)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("ÜYE OLMADAN İLANLARA GÖZ AT", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    Text("Makine ve Hizmet Ara", fontSize = 12.sp, maxLines = 1, color = TextSecondary)
                }
            }
            Spacer(Modifier.height(18.dp))

            // 3) Kırmızı kart: acil çağrı
            Surface(
                onClick = onEmergency,
                modifier = Modifier.fillMaxWidth().testTag("welcome_emergency"),
                shape = RoundedCornerShape(14.dp),
                color = EmergencyRed,
                border = BorderStroke(1.5.dp, EmergencyBorder)
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🚨", fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Text("YOLDA MI KALDINIZ?", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "ÜYE OLMADAN",
                            modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(AmberCta).padding(horizontal = 6.dp, vertical = 2.dp),
                            color = Color(0xFF111827), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Hemen Çekici veya Lastikçi çağırın  →", color = Color.White, fontSize = 15.sp)
                }
            }
            Spacer(Modifier.height(12.dp))

            // 4) Beyaz: Google
            Button(
                onClick = { startGoogle(false) },
                enabled = !googleBusy,
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("welcome_google"),
                shape = RoundedCornerShape(32.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF111827), disabledContainerColor = Color(0xFFE5E7EB))
            ) {
                if (googleBusy) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color(0xFF111827))
                } else {
                    GoogleG()
                    Spacer(Modifier.width(10.dp))
                    Text("Google ile Tek Tıkla Devam Et", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
            Spacer(Modifier.height(14.dp))

            // 5) Giriş
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Text("Zaten hesabın var mı? ", color = TextMuted, fontSize = 14.sp)
                Text(
                    "Giriş Yap",
                    color = Color.White,
                    fontSize = 14.sp,
                    textDecoration = TextDecoration.Underline,
                    modifier = Modifier.clickable(onClick = onLogin).padding(vertical = 8.dp).testTag("welcome_login")
                )
            }
        }
    }

    if (showOwnerDialog) {
        QuickOwnerDialog(
            googleBusy = googleBusy,
            onDismiss = { showOwnerDialog = false },
            onSubmit = onQuickRegister,
            onSuccess = { showOwnerDialog = false; onOwnerReady() },
            onGoogle = { startGoogle(true) }
        )
    }
}

@Composable
private fun GoogleG() {
    Box(
        modifier = Modifier.size(24.dp).clip(CircleShape).background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Text("G", color = Color(0xFF4285F4), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun QuickOwnerDialog(
    googleBusy: Boolean,
    onDismiss: () -> Unit,
    onSubmit: suspend (String, String) -> Result<Unit>,
    onSuccess: () -> Unit,
    onGoogle: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
        focusedBorderColor = AmberCta, unfocusedBorderColor = TextMuted,
        focusedLabelColor = AmberCta, unfocusedLabelColor = TextMuted, cursorColor = AmberCta
    )

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        containerColor = NavyLight,
        title = { Text("Hızlı Esnaf Kaydı", color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Sadece adını ve telefonunu yaz, hemen ilan eklemeye geç.", color = TextSecondary, fontSize = 13.sp)
                OutlinedTextField(
                    value = name, onValueChange = { name = it; error = null },
                    label = { Text("Ad Soyad") }, singleLine = true, colors = fieldColors,
                    modifier = Modifier.fillMaxWidth().testTag("quick_name")
                )
                OutlinedTextField(
                    value = phone, onValueChange = { phone = it; error = null },
                    label = { Text("Telefon (05xx xxx xx xx)") }, singleLine = true, colors = fieldColors,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth().testTag("quick_phone")
                )
                error?.let { Text(it, color = Color(0xFFFCA5A5), fontSize = 12.sp) }
                TextButton(onClick = onGoogle, enabled = !busy && !googleBusy, modifier = Modifier.fillMaxWidth()) {
                    Text("veya Google ile devam et", color = BlueAccent)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    busy = true
                    scope.launch {
                        onSubmit(name, phone).fold(
                            onSuccess = { busy = false; onSuccess() },
                            onFailure = { busy = false; error = it.message ?: "Kayıt yapılamadı." }
                        )
                    }
                },
                enabled = !busy,
                colors = ButtonDefaults.buttonColors(containerColor = AmberCta, contentColor = Color(0xFF111827)),
                modifier = Modifier.testTag("quick_submit")
            ) {
                if (busy) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color(0xFF111827))
                else Text("Kaydol ve İlan Ekle", fontWeight = FontWeight.Bold, maxLines = 1)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !busy) { Text("Vazgeç", color = TextMuted) }
        }
    )
}

/** Misafir kullanıcı üyelik gerektiren bir eyleme dokunduğunda gösterilir. */
@Composable
fun LoginRequiredDialog(
    reason: String,
    onDismiss: () -> Unit,
    onLogin: () -> Unit,
    onRegister: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NavyLight,
        title = { Text("Üyelik Gerekli", color = Color.White, fontWeight = FontWeight.Bold) },
        text = { Text("$reason için giriş yapmanız veya ücretsiz üye olmanız gerekir.", color = TextSecondary) },
        confirmButton = {
            Button(onClick = onLogin, colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)) {
                Text("Giriş Yap", maxLines = 1)
            }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onRegister) { Text("Üye Ol", color = AmberCta, maxLines = 1) }
                TextButton(onClick = onDismiss) { Text("Vazgeç", color = TextMuted, maxLines = 1) }
            }
        }
    )
}
