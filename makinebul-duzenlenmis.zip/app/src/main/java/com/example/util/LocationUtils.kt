package com.example.util

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat

object LocationUtils {
    private const val TAG = "LocationUtils"

    fun hasLocationPermission(context: Context): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    @SuppressLint("MissingPermission")
    fun getCurrentLocation(
        context: Context,
        onSuccess: (latitude: Double, longitude: Double) -> Unit,
        onError: (message: String) -> Unit
    ) {
        if (!hasLocationPermission(context)) {
            onError("Konum izni verilmedi.")
            return
        }

        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (locationManager == null) {
            onError("Konum servisi bulunamadı.")
            return
        }

        // 1. Try immediate last known location from all available providers
        val providers = listOf(
            LocationManager.GPS_PROVIDER,
            LocationManager.NETWORK_PROVIDER,
            LocationManager.PASSIVE_PROVIDER
        )

        var bestLocation: Location? = null
        for (provider in providers) {
            try {
                if (locationManager.isProviderEnabled(provider)) {
                    val loc = locationManager.getLastKnownLocation(provider)
                    if (loc != null) {
                        if (bestLocation == null || loc.accuracy < bestLocation.accuracy) {
                            bestLocation = loc
                        }
                    }
                }
            } catch (e: Throwable) {
                Log.d(TAG, "Could not get last location from $provider: ${e.message}")
            }
        }

        if (bestLocation != null) {
            Log.d(TAG, "Location obtained from native LocationManager: ${bestLocation.latitude}, ${bestLocation.longitude}")
            onSuccess(bestLocation.latitude, bestLocation.longitude)
            return
        }

        // 2. On Android 30+, use native getCurrentLocation
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val provider = if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    LocationManager.GPS_PROVIDER
                } else {
                    LocationManager.NETWORK_PROVIDER
                }
                val cancellationSignal = CancellationSignal()
                val executor = ContextCompat.getMainExecutor(context)
                
                locationManager.getCurrentLocation(
                    provider,
                    cancellationSignal,
                    executor
                ) { location: Location? ->
                    if (location != null) {
                        onSuccess(location.latitude, location.longitude)
                    } else {
                        // Default fallback location (Istanbul center)
                        onSuccess(41.0082, 28.9784)
                    }
                }
                return
            } catch (e: Throwable) {
                Log.d(TAG, "Native getCurrentLocation failed: ${e.message}")
            }
        }

        // 3. Request single update via LocationListener
        try {
            val mainLooper = Looper.getMainLooper()
            val handler = Handler(mainLooper)
            var isHandled = false

            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    if (!isHandled) {
                        isHandled = true
                        try { locationManager.removeUpdates(this) } catch (_: Throwable) {}
                        onSuccess(location.latitude, location.longitude)
                    }
                }
                @Deprecated("Deprecated in Java")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }

            // Timeout after 3 seconds, fallback to default coordinates
            handler.postDelayed({
                if (!isHandled) {
                    isHandled = true
                    try { locationManager.removeUpdates(listener) } catch (_: Throwable) {}
                    // Return Istanbul center coordinates as default fallback
                    onSuccess(41.0082, 28.9784)
                }
            }, 3000)

            for (provider in listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)) {
                if (locationManager.isProviderEnabled(provider)) {
                    locationManager.requestSingleUpdate(provider, listener, mainLooper)
                    return
                }
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Location requestSingleUpdate error: ${e.message}")
        }

        // Ultimate fallback
        onSuccess(41.0082, 28.9784)
    }
}

