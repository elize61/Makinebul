package com.example.ui.screens.machine

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Machine
import com.example.data.model.MachineCategories
import com.example.data.model.User
import com.example.ui.components.AvailabilityCalendar
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusError

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditMachineScreen(
    editingMachine: Machine? = null,
    currentUser: User?,
    onNavigateBack: () -> Unit,
    onSaveMachine: (Machine) -> Unit
) {
    var title by remember { mutableStateOf(editingMachine?.title ?: "") }
    var selectedCategory by remember { mutableStateOf(editingMachine?.category ?: "Mobil Vinç") }
    var brand by remember { mutableStateOf(editingMachine?.brand ?: "") }
    var model by remember { mutableStateOf(editingMachine?.model ?: "") }
    var year by remember { mutableStateOf(editingMachine?.year?.toString() ?: "2023") }
    var description by remember { mutableStateOf(editingMachine?.description ?: "") }
    var hourlyPrice by remember { mutableStateOf(editingMachine?.hourlyPrice?.toString() ?: "") }
    var dailyPrice by remember { mutableStateOf(editingMachine?.dailyPrice?.toString() ?: "") }
    var minWorkingHours by remember { mutableStateOf(editingMachine?.minWorkingHours?.toString() ?: "2") }
    var city by remember { mutableStateOf(editingMachine?.city ?: currentUser?.city ?: "İstanbul") }
    var district by remember { mutableStateOf(editingMachine?.district ?: currentUser?.district ?: "Ümraniye") }
    var address by remember { mutableStateOf(editingMachine?.address ?: "") }
    var phone by remember { mutableStateOf(editingMachine?.ownerPhone ?: currentUser?.phone ?: "") }
    var hasOperator by remember { mutableStateOf(editingMachine?.hasOperator ?: true) }
    var fuelIncluded by remember { mutableStateOf(editingMachine?.fuelIncluded ?: false) }
    var isLowbedTransport by remember { mutableStateOf(editingMachine?.isLowbedTransport ?: false) }
    val blockedDates = remember { mutableStateListOf<String>().apply { addAll(editingMachine?.blockedDates ?: emptyList()) } }

    var photos by remember { mutableStateOf(editingMachine?.photos ?: listOf(
        "https://images.unsplash.com/photo-1581094288338-2314dddb7ece?auto=format&fit=crop&w=800&q=80"
    )) }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (editingMachine != null) "İlanı Düzenle" else "Yeni Makine İlanı Ekle",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Geri", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (errorMessage != null) {
                Surface(
                    color = StatusError.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = errorMessage!!,
                        color = StatusError,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            // Photos Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Makine Fotoğrafları", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(10.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(photos) { url ->
                            AsyncImage(
                                model = url,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(90.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                        }

                        item {
                            Box(
                                modifier = Modifier
                                    .size(90.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(NavyLight)
                                    .clickable {
                                        photos = photos + "https://images.unsplash.com/photo-1541888946425-d0fbb186a5b7?auto=format&fit=crop&w=800&q=80"
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Filled.AddPhotoAlternate, contentDescription = null, tint = BlueAccent)
                                    Text("Foto Ekle", color = BlueAccent, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Category Selection Card with High Contrast & Crystal Clear Readability
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Kategori Seçimi *",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = BluePrimary.copy(alpha = 0.12f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BluePrimary.copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = "Seçili: $selectedCategory",
                                color = BluePrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "İlanınızın listeleneceği en uygun kategoriyi aşağıdan seçin:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    @OptIn(ExperimentalLayoutApi::class)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        MachineCategories.ALL.filter { it != "Tümü" }.forEach { cat ->
                            val isSelected = selectedCategory == cat
                            val emoji = when {
                                cat.contains("Boya", ignoreCase = true) -> "🎨"
                                cat.contains("Usta", ignoreCase = true) || cat.contains("İşçilik", ignoreCase = true) -> "👷"
                                cat.contains("Sıva", ignoreCase = true) || cat.contains("Alçı", ignoreCase = true) -> "🧱"
                                cat.contains("Elektrik", ignoreCase = true) -> "⚡"
                                cat.contains("Tesisat", ignoreCase = true) -> "🔧"
                                cat.contains("Çatı", ignoreCase = true) -> "🏠"
                                cat.contains("Fayans", ignoreCase = true) || cat.contains("Seramik", ignoreCase = true) -> "🔲"
                                cat.contains("Zemin", ignoreCase = true) || cat.contains("Şap", ignoreCase = true) -> "🛡️"
                                cat.contains("Hafriyat", ignoreCase = true) || cat.contains("Yıkım", ignoreCase = true) -> "💥"
                                cat.contains("Vinç", ignoreCase = true) -> "🏗️"
                                cat.contains("Ekskavatör", ignoreCase = true) -> "🚜"
                                cat.contains("JCB", ignoreCase = true) || cat.contains("Kazıcı", ignoreCase = true) -> "🚜"
                                cat.contains("Forklift", ignoreCase = true) -> "📦"
                                cat.contains("Platform", ignoreCase = true) -> "🪜"
                                cat.contains("Manitou", ignoreCase = true) -> "🏗️"
                                cat.contains("Loder", ignoreCase = true) -> "🚜"
                                cat.contains("Dozer", ignoreCase = true) -> "🚜"
                                cat.contains("Silindir", ignoreCase = true) -> "🚜"
                                cat.contains("Çekici", ignoreCase = true) -> "🚛"
                                cat.contains("Lowbed", ignoreCase = true) -> "🚚"
                                else -> "⚙️"
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) BluePrimary else MaterialTheme.colorScheme.surfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) BluePrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                                ),
                                shadowElevation = if (isSelected) 3.dp else 0.dp,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        selectedCategory = cat
                                        if (cat == "Lowbed Taşıma") isLowbedTransport = true
                                    }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    Text(
                                        text = "$emoji ",
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = cat,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.SemiBold,
                                        fontSize = 13.sp
                                    )
                                    if (isSelected) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Specs Form Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Makine Bilgileri", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Makine İlan Başlığı (Örn: Liebherr 100 Ton Vinç)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("add_title_input")
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = brand,
                            onValueChange = { brand = it },
                            label = { Text("Marka (Örn: Liebherr)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = model,
                            onValueChange = { model = it },
                            label = { Text("Model") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = year,
                        onValueChange = { year = it },
                        label = { Text("Model Yılı") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Açıklama & Özellikler") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Pricing & Features Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Fiyatlandırma & Hizmet Koşulları", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = hourlyPrice,
                            onValueChange = { hourlyPrice = it },
                            label = { Text("Saatlik Ücret (₺)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("add_hourly_input")
                        )

                        OutlinedTextField(
                            value = dailyPrice,
                            onValueChange = { dailyPrice = it },
                            label = { Text("Günlük Ücret (₺)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("add_daily_input")
                        )
                    }

                    OutlinedTextField(
                        value = minWorkingHours,
                        onValueChange = { minWorkingHours = it },
                        label = { Text("Minimum Çalışma Süresi (Saat)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Feature Toggles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = hasOperator, onCheckedChange = { hasOperator = it })
                        Text(text = "Operatörlü Hizmet Sağlanıyor", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = fuelIncluded, onCheckedChange = { fuelIncluded = it })
                        Text(text = "Yakıt Fiyata Dahil", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = isLowbedTransport, onCheckedChange = { isLowbedTransport = it })
                        Text(text = "Lowbed Ağır Nakliye Aracı / Hizmeti", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }

            // Availability Calendar Block Tool for Owner
            AvailabilityCalendar(
                blockedDates = blockedDates,
                dailyPrice = dailyPrice.toDoubleOrNull() ?: 0.0,
                hourlyPrice = hourlyPrice.toDoubleOrNull() ?: 0.0,
                isOwnerMode = true,
                onToggleBlockDate = { dateStr ->
                    if (blockedDates.contains(dateStr)) {
                        blockedDates.remove(dateStr)
                    } else {
                        blockedDates.add(dateStr)
                    }
                }
            )

            // Location Card
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Konum & İletişim Bilgileri", fontWeight = FontWeight.Bold, fontSize = 15.sp)

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = city,
                            onValueChange = { city = it },
                            label = { Text("İl") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = district,
                            onValueChange = { district = it },
                            label = { Text("İlçe") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("Açık Adres / Garaj Adresi") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("İletişim Telefonu") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Button(
                onClick = {
                    if (title.isBlank() || hourlyPrice.isBlank() || dailyPrice.isBlank() || city.isBlank()) {
                        errorMessage = "Lütfen başlık, fiyatlandırma ve konum bilgilerini eksiksiz giriniz."
                        return@Button
                    }

                    val machineObj = Machine(
                        id = editingMachine?.id ?: "mach_${System.currentTimeMillis()}",
                        ownerId = currentUser?.id ?: "demo_owner_1",
                        ownerName = currentUser?.fullName ?: "Demir Makine Kiralama",
                        ownerPhone = phone,
                        title = title,
                        category = selectedCategory,
                        brand = brand,
                        model = model,
                        year = year.toIntOrNull() ?: 2022,
                        description = description,
                        hourlyPrice = hourlyPrice.toDoubleOrNull() ?: 0.0,
                        dailyPrice = dailyPrice.toDoubleOrNull() ?: 0.0,
                        minWorkingHours = minWorkingHours.toIntOrNull() ?: 2,
                        city = city,
                        district = district,
                        address = address,
                        hasOperator = hasOperator,
                        fuelIncluded = fuelIncluded,
                        isLowbedTransport = isLowbedTransport,
                        blockedDates = blockedDates.toList(),
                        photos = photos
                    )

                    onSaveMachine(machineObj)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("save_machine_btn"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
            ) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text("İlanı Kaydet & Yayınla", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}
