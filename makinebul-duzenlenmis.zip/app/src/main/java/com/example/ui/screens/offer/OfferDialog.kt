package com.example.ui.screens.offer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Machine
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.StatusError

@Composable
fun OfferDialog(
    machine: Machine,
    initialStartDate: String? = null,
    initialEndDate: String? = null,
    initialPrice: Double? = null,
    onDismiss: () -> Unit,
    onSubmitOffer: (String, String, Int, String, String, Double) -> Unit
) {
    var startDate by remember(initialStartDate) { mutableStateOf(initialStartDate?.ifBlank { null } ?: "15 Ağustos 2026") }
    var endDate by remember(initialEndDate) { mutableStateOf(initialEndDate?.ifBlank { null } ?: "16 Ağustos 2026") }
    var workingHours by remember { mutableStateOf("8") }
    var location by remember { mutableStateOf("${machine.city} / ${machine.district} Şantiye Alanı") }
    var description by remember { mutableStateOf("Proje kapsamında kiralama teklifi.") }
    var offeredPrice by remember(initialPrice) {
        val p = if (initialPrice != null && initialPrice > 0) initialPrice.toInt().toString() else (machine.dailyPrice * 2).toInt().toString()
        mutableStateOf(p)
    }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Teklif Gönder",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = machine.title,
                    fontSize = 13.sp,
                    color = BluePrimary,
                    fontWeight = FontWeight.SemiBold
                )

                errorMessage?.let { error ->
                    Text(text = error, color = StatusError, fontSize = 13.sp)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = startDate,
                        onValueChange = { startDate = it },
                        label = { Text("Başlangıç") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = endDate,
                        onValueChange = { endDate = it },
                        label = { Text("Bitiş") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = workingHours,
                        onValueChange = { workingHours = it },
                        label = { Text("Toplam Saat") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = offeredPrice,
                        onValueChange = { offeredPrice = it },
                        label = { Text("Teklif Fiyatı (₺)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("offer_price_input")
                    )
                }

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("İşin Yapılacağı Yer / Şantiye") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Açıklama / Özel Notlar") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("İptal")
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Button(
                        onClick = {
                            val price = offeredPrice.toDoubleOrNull() ?: 0.0
                            val hours = workingHours.toIntOrNull() ?: 8
                            if (startDate.isBlank() || endDate.isBlank() || price <= 0) {
                                errorMessage = "Lütfen tüm alanları ve geçerli fiyatı giriniz."
                                return@Button
                            }

                            onSubmitOffer(startDate, endDate, hours, location, description, price)
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                        modifier = Modifier.testTag("submit_offer_btn")
                    ) {
                        Text("Teklifi Gönder", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
