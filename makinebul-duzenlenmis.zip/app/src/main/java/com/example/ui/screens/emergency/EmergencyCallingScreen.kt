package com.example.ui.screens.emergency

import android.Manifest
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EmergencyRequest
import com.example.data.model.EmergencyServiceType
import com.example.data.model.User
import com.example.ui.components.OsmMapView
import com.example.ui.components.OsmMarkerItem
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusWarning
import com.example.util.LocationUtils

/**
 * Emergency Calling Screen for Registered Users.
 * Completely harmonized with FastEmergencyCallScreen, including service switcher, OpenStreetMap, and cohesive styling.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun EmergencyCallingScreen(
    currentUser: User?,
    serviceType: EmergencyServiceType = EmergencyServiceType.TOW_TRUCK,
    onBackClick: () -> Unit,
    onSubmitRequest: (EmergencyRequest) -> Unit
) {
    val context = LocalContext.current
    var selectedServiceType by remember(serviceType) { mutableStateOf(serviceType) }
    val isTireMode = selectedServiceType == EmergencyServiceType.TIRE_SERVICE

    // Form inputs
    var phone by remember(currentUser) { mutableStateOf(currentUser?.phone ?: "") }
    var customerName by remember(currentUser) { mutableStateOf(currentUser?.fullName ?: "Müşteri") }
    var currentLocName by remember(currentUser) {
        mutableStateOf(
            if (currentUser?.city.isNullOrBlank()) "Ümraniye, İstanbul"
            else if (currentUser.district.isNullOrBlank()) currentUser.city!!
            else "${currentUser.district}, ${currentUser.city}"
        )
    }
    var destinationLocName by remember { mutableStateOf("En Yakın Oto Sanayi Sitesi") }
    var selectedVehicleType by remember { mutableStateOf("Otomobil") }
    var plate by remember { mutableStateOf("34 ABC 123") }
    var tireDimension by remember { mutableStateOf("") }
    var hasSpareTire by remember { mutableStateOf(true) }
    var description by remember { mutableStateOf("") }

    // GPS State
    var customerLat by remember { mutableDoubleStateOf(41.0250) }
    var customerLng by remember { mutableDoubleStateOf(29.1120) }
    var isGpsActive by remember { mutableStateOf(false) }
    var isGpsLoading by remember { mutableStateOf(false) }
    var gpsStatusText by remember { mutableStateOf("GPS Konumu Otomatik Alınıyor...") }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }

    val vehicleTypes = listOf(
        "Otomobil", "SUV", "Hafif Ticari", "Kamyonet",
        "Kamyon", "Otobüs", "Motosiklet", "Diğer"
    )

    val towProblemTypes = listOf(
        "Aracım çalışmıyor", "Kaza yaptım", "Akü bitti",
        "Motor arızası", "Şanzıman / Mekanik", "Yakıt bitti", "Diğer"
    )

    val tireProblemTypes = listOf(
        "Lastik patladı", "Lastik yarıldı", "Stepne değişimi",
        "Lastik indi (Hava)", "Jant hasarlı", "Çift lastik indi", "Diğer"
    )

    val problemTypes = if (isTireMode) tireProblemTypes else towProblemTypes
    var selectedProblem by remember { mutableStateOf(problemTypes.first()) }

    LaunchedEffect(isTireMode) {
        if (!problemTypes.contains(selectedProblem)) {
            selectedProblem = problemTypes.first()
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false

        if (fineGranted || coarseGranted) {
            isGpsLoading = true
            LocationUtils.getCurrentLocation(
                context = context,
                onSuccess = { lat, lng ->
                    isGpsLoading = false
                    customerLat = lat
                    customerLng = lng
                    isGpsActive = true
                    gpsStatusText = "📍 GPS Konumunuz Alındı: %.4f, %.4f".format(lat, lng)
                    currentLocName = "GPS Konumu (%.4f, %.4f)".format(lat, lng)
                },
                onError = { msg ->
                    isGpsLoading = false
                    isGpsActive = false
                    gpsStatusText = "⚠️ $msg"
                }
            )
        } else {
            isGpsActive = false
            gpsStatusText = "⚠️ Konum izni verilmedi (Konumu elle giriniz)"
        }
    }

    LaunchedEffect(Unit) {
        if (LocationUtils.hasLocationPermission(context)) {
            isGpsLoading = true
            LocationUtils.getCurrentLocation(
                context = context,
                onSuccess = { lat, lng ->
                    isGpsLoading = false
                    customerLat = lat
                    customerLng = lng
                    isGpsActive = true
                    gpsStatusText = "📍 GPS Konumunuz Alındı: %.4f, %.4f".format(lat, lng)
                },
                onError = { msg ->
                    isGpsLoading = false
                    isGpsActive = false
                    gpsStatusText = "⚠️ $msg"
                }
            )
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (isTireMode) "🛞 ACİL LASTİKÇİ ÇAĞIR" else "🚛 ACİL ÇEKİCİ ÇAĞIR",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = StatusAvailable.copy(alpha = 0.25f)
                            ) {
                                Text(
                                    text = "7/24 NÖBETÇİ",
                                    color = StatusAvailable,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = if (isTireMode) "Mobil Lastik Tamiri & Stepne Değişimi" else "7/24 En Yakın Çekici & Kurtarıcı",
                            color = BlueAccent,
                            fontSize = 11.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(
                            imageVector = Icons.Filled.ArrowBack,
                            contentDescription = "Geri",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = NavyDark)
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(NavyDark)
                .padding(padding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Service Mode Switcher (Harmonized)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedServiceType = EmergencyServiceType.TOW_TRUCK }
                            .testTag("select_service_tow_auth"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (!isTireMode) StatusError.copy(alpha = 0.2f) else NavyLight
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            2.dp,
                            if (!isTireMode) StatusError else Color.Transparent
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("🚛", fontSize = 30.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Acil Çekici",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Oto Kurtarma",
                                color = if (!isTireMode) StatusError else Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedServiceType = EmergencyServiceType.TIRE_SERVICE }
                            .testTag("select_service_tire_auth"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isTireMode) BluePrimary.copy(alpha = 0.2f) else NavyLight
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            2.dp,
                            if (isTireMode) BluePrimary else Color.Transparent
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("🛞", fontSize = 30.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Mobil Lastikçi",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Yerinde Tamir",
                                color = if (isTireMode) BlueAccent else Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                // Contact & Phone Details Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyLight)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Phone, contentDescription = null, tint = StatusAvailable, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "İletişim Bilgileri",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("Telefon Numaranız *") },
                            placeholder = { Text("05XX XXX XX XX") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            leadingIcon = {
                                Icon(Icons.Filled.Phone, contentDescription = null, tint = BlueAccent)
                            },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = StatusAvailable,
                                unfocusedBorderColor = Color.Gray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        OutlinedTextField(
                            value = customerName,
                            onValueChange = { customerName = it },
                            label = { Text("Adınız Soyadınız") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BluePrimary,
                                unfocusedBorderColor = Color.Gray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                    }
                }

                // Location & OpenStreetMap Section
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyLight)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.LocationOn, contentDescription = null, tint = StatusError, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Konumunuz & Canlı Harita",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                            if (isGpsActive) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = StatusAvailable.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "GPS AKTİF",
                                        color = StatusAvailable,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        // OpenStreetMap Preview (Real interactive OSM Map)
                        val previewMarkers = listOf(
                            OsmMarkerItem(
                                id = "calling_customer_loc",
                                title = "Konumunuz",
                                snippet = currentLocName,
                                latitude = customerLat,
                                longitude = customerLng,
                                isDemand = true
                            )
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp)
                                .clip(RoundedCornerShape(12.dp))
                        ) {
                            OsmMapView(
                                modifier = Modifier.fillMaxSize(),
                                markers = previewMarkers,
                                centerLatitude = customerLat,
                                centerLongitude = customerLng,
                                zoomLevel = 13.0,
                                userLatitude = customerLat,
                                userLongitude = customerLng,
                                showZoomControls = false
                            )
                        }

                        // GPS refresh button
                        OutlinedButton(
                            onClick = {
                                if (LocationUtils.hasLocationPermission(context)) {
                                    isGpsLoading = true
                                    LocationUtils.getCurrentLocation(
                                        context = context,
                                        onSuccess = { lat, lng ->
                                            isGpsLoading = false
                                            customerLat = lat
                                            customerLng = lng
                                            isGpsActive = true
                                            gpsStatusText = "📍 GPS Bağlandı: %.4f, %.4f".format(lat, lng)
                                            currentLocName = "GPS Konumu (%.4f, %.4f)".format(lat, lng)
                                            Toast.makeText(context, "GPS koordinatlarınız güncellendi", Toast.LENGTH_SHORT).show()
                                        },
                                        onError = { err ->
                                            isGpsLoading = false
                                            Toast.makeText(context, "Hata: $err", Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                } else {
                                    permissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(46.dp),
                            shape = RoundedCornerShape(10.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, BlueAccent)
                        ) {
                            if (isGpsLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Konum Alınıyor...", color = Color.White, fontSize = 12.sp)
                            } else {
                                Icon(Icons.Filled.GpsFixed, contentDescription = null, tint = BlueAccent, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isGpsActive) "GPS Konumunu Yenile (Alındı)" else "GPS Konumumu Otomatik Al",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Text(
                            text = gpsStatusText,
                            color = if (isGpsActive) StatusAvailable else Color.LightGray,
                            fontSize = 11.sp
                        )

                        OutlinedTextField(
                            value = currentLocName,
                            onValueChange = { currentLocName = it },
                            label = { Text("Bulunduğunuz Yer / Açık Yol Tarifi *") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BluePrimary,
                                unfocusedBorderColor = Color.Gray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        if (!isTireMode) {
                            OutlinedTextField(
                                value = destinationLocName,
                                onValueChange = { destinationLocName = it },
                                label = { Text("Aracın Çekileceği Yer / Sanayi Sitesi") },
                                leadingIcon = {
                                    Icon(Icons.Filled.Flag, contentDescription = null, tint = StatusWarning)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BluePrimary,
                                    unfocusedBorderColor = Color.Gray,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )
                        }
                    }
                }

                // Vehicle & Arıza Detayları
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NavyLight)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.DirectionsCar, contentDescription = null, tint = BlueAccent, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Araç ve Arıza Detayları",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        // Vehicle type chips
                        Text("Araç Tipi:", color = Color.LightGray, fontSize = 12.sp)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            vehicleTypes.forEach { vType ->
                                val isSelected = selectedVehicleType == vType
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { selectedVehicleType = vType },
                                    label = { Text(vType, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = BluePrimary,
                                        selectedLabelColor = Color.White,
                                        containerColor = NavyDark,
                                        labelColor = Color.LightGray
                                    )
                                )
                            }
                        }

                        OutlinedTextField(
                            value = plate,
                            onValueChange = { plate = it.uppercase() },
                            label = { Text("Plaka") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BluePrimary,
                                unfocusedBorderColor = Color.Gray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        // Problem Type chips
                        Text("Karşılaştığınız Sorun:", color = Color.LightGray, fontSize = 12.sp)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            problemTypes.forEach { prob ->
                                val isSelected = selectedProblem == prob
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { selectedProblem = prob },
                                    label = { Text(prob, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = if (isTireMode) BluePrimary else StatusError,
                                        selectedLabelColor = Color.White,
                                        containerColor = NavyDark,
                                        labelColor = Color.LightGray
                                    )
                                )
                            }
                        }

                        if (isTireMode) {
                            OutlinedTextField(
                                value = tireDimension,
                                onValueChange = { tireDimension = it },
                                label = { Text("Lastik Ebadı (Biliyorsanız)") },
                                placeholder = { Text("Örn: 205/55 R16") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = BluePrimary,
                                    unfocusedBorderColor = Color.Gray,
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Stepneniz (Yedek Lastik) Var mı?", color = Color.White, fontSize = 13.sp)
                                    Text(
                                        text = if (hasSpareTire) "Evet, stepne araçta mevcut" else "Hayır, usta lastik getirmeli",
                                        color = if (hasSpareTire) StatusAvailable else StatusWarning,
                                        fontSize = 11.sp
                                    )
                                }
                                Switch(
                                    checked = hasSpareTire,
                                    onCheckedChange = { hasSpareTire = it },
                                    colors = SwitchDefaults.colors(checkedThumbColor = StatusAvailable)
                                )
                            }
                        }

                        OutlinedTextField(
                            value = description,
                            onValueChange = { description = it },
                            label = { Text("Açıklama / Ekstra Notlar") },
                            minLines = 2,
                            maxLines = 4,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BluePrimary,
                                unfocusedBorderColor = Color.Gray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                    }
                }

                // Error Message if any
                if (errorMessage != null) {
                    Surface(
                        color = StatusError.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Warning, contentDescription = null, tint = StatusError, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(errorMessage!!, color = Color.White, fontSize = 12.sp)
                        }
                    }
                }

                // Action Call Button
                Button(
                    onClick = {
                        val trimmedPhone = phone.trim()
                        if (trimmedPhone.isBlank() || trimmedPhone.length < 10) {
                            errorMessage = "Lütfen geçerli bir telefon numarası giriniz."
                            return@Button
                        }
                        if (currentLocName.isBlank()) {
                            errorMessage = "Lütfen bulunduğunuz konumu giriniz."
                            return@Button
                        }

                        errorMessage = null
                        val request = EmergencyRequest(
                            serviceType = selectedServiceType,
                            customerId = currentUser?.id ?: "cust_${System.currentTimeMillis()}",
                            customerName = customerName.ifBlank { currentUser?.fullName ?: "Müşteri" },
                            customerPhone = trimmedPhone,
                            customerLocationName = currentLocName,
                            customerLat = customerLat,
                            customerLng = customerLng,
                            destinationLocationName = if (isTireMode) "Olay Yerinde Mobil Servis" else destinationLocName,
                            vehicleType = selectedVehicleType,
                            plate = plate,
                            problemType = selectedProblem,
                            tireDimension = tireDimension,
                            hasSpareTire = hasSpareTire,
                            description = description
                        )
                        onSubmitRequest(request)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("btn_submit_emergency_request"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isTireMode) BluePrimary else StatusError
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = if (isTireMode) "🛞 ACİL LASTİKÇİ ÇAĞIR & TEKLİFLERİ GÖR" else "🚛 ACİL ÇEKİCİ ÇAĞIR & TEKLİFLERİ GÖR",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
