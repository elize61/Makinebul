package com.example.ui.screens.demands

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.RequestQuote
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.JobBid
import com.example.data.model.JobDemand
import com.example.data.model.Machine
import com.example.data.model.User
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavyLight
import com.example.ui.theme.StatusAvailable
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun JobDemandsScreen(
    currentUser: User?,
    demands: List<JobDemand>,
    bids: List<JobBid> = emptyList(),
    userMachines: List<Machine> = emptyList(),
    onBackClick: () -> Unit,
    onCreateDemand: (JobDemand) -> Unit,
    onSubmitBid: (JobBid) -> Unit = {},
    onUpdateBidStatus: (String, String) -> Unit = { _, _ -> },
    onNavigateToChat: (String, String) -> Unit = { _, _ -> },
    onDeleteDemand: (String) -> Unit = {},
    onDeleteBid: (String) -> Unit = {}
) {
    val context = LocalContext.current
    var selectedCategory by remember { mutableStateOf("Tümü") }
    var onlyUrgent by remember { mutableStateOf(false) }
    var onlyLowbed by remember { mutableStateOf(false) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var biddingDemand by remember { mutableStateOf<JobDemand?>(null) }
    var expandedDemandId by remember { mutableStateOf<String?>(null) }
    var demandToDelete by remember { mutableStateOf<JobDemand?>(null) }
    var bidToDelete by remember { mutableStateOf<JobBid?>(null) }

    // Demand Delete Confirmation Dialog
    demandToDelete?.let { demand ->
        AlertDialog(
            onDismissRequest = { demandToDelete = null },
            title = { Text("Talebi Sil", fontWeight = FontWeight.Bold) },
            text = { Text("\"${demand.title}\" başlıklı iş talebini ve ilgili teklifleri silmek istediğinize emin misiniz? Bu işlem geri alınamaz.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteDemand(demand.id)
                        demandToDelete = null
                        Toast.makeText(context, "🗑️ Talep başarıyla silindi.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) {
                    Text("Sil", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { demandToDelete = null }) {
                    Text("Vazgeç")
                }
            }
        )
    }

    // Bid Delete Confirmation Dialog
    bidToDelete?.let { bid ->
        AlertDialog(
            onDismissRequest = { bidToDelete = null },
            title = { Text("Teklifi Sil", fontWeight = FontWeight.Bold) },
            text = { Text("\"${bid.bidderName}\" tarafından verilen teklifi silmek istediğinize emin misiniz?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteBid(bid.id)
                        bidToDelete = null
                        Toast.makeText(context, "🗑️ Teklif silindi.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusError)
                ) {
                    Text("Sil", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { bidToDelete = null }) {
                    Text("Vazgeç")
                }
            }
        )
    }

    val filteredDemands = demands.filter { demand ->
        val catMatch = selectedCategory == "Tümü" || demand.category.equals(selectedCategory, ignoreCase = true)
        val urgentMatch = !onlyUrgent || demand.isUrgent
        val lowbedMatch = !onlyLowbed || demand.isLowbedHaulage || demand.category.contains("Lowbed", ignoreCase = true)
        catMatch && urgentMatch && lowbedMatch
    }

    Scaffold(
        topBar = {
            Surface(color = NavyDark, shadowElevation = 4.dp) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBackClick) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Geri",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Şantiye & Makine Talep Havuzu",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "${filteredDemands.size} Aktif İş Talebi • Canlı Teklif Sistemi",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.7f)
                            )
                        }

                        Button(
                            onClick = { showCreateDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = BlueAccent),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("open_create_demand_dialog_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Talep Aç", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Category Tabs
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(listOf("Tümü", "Ekskavatör", "Mobil Vinç", "JCB", "Sepetli Platform", "Lowbed Taşıma", "Manitou", "Forklift")) { cat ->
                            val isSelected = selectedCategory == cat
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = if (isSelected) BlueAccent else NavyLight,
                                modifier = Modifier.clickable { selectedCategory = cat }
                            ) {
                                Text(
                                    text = cat,
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Filter Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (onlyUrgent) StatusError else NavyLight,
                            modifier = Modifier.clickable { onlyUrgent = !onlyUrgent }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FlashOn,
                                    contentDescription = null,
                                    tint = if (onlyUrgent) Color.White else StatusError,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Acil İhtiyaçlar",
                                    fontSize = 11.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (onlyLowbed) BluePrimary else NavyLight,
                            modifier = Modifier.clickable { onlyLowbed = !onlyLowbed }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocalShipping,
                                    contentDescription = null,
                                    tint = if (onlyLowbed) Color.White else BlueAccent,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Lowbed / Nakliye",
                                    fontSize = 11.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = BluePrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("create_demand_fab")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Yeni Talep")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("İş İlanı Ver", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF3F4F6)),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Info Header Banner
            item {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFEFF6FF),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BluePrimary.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(BluePrimary.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Business, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Taleplere Doğrudan Teklif Gönderin",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = NavyDark
                            )
                            Text(
                                text = "Şantiye yetkilileri teklifinizi anında inceler, onaylar veya arar.",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }

            if (filteredDemands.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Seçilen kriterlere uygun talep bulunamadı.",
                            color = TextMuted,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                items(filteredDemands) { demand ->
                    val demandBids = bids.filter { it.demandId == demand.id }
                    val isExpanded = expandedDemandId == demand.id

                    JobDemandCardWithBids(
                        demand = demand,
                        bids = demandBids,
                        isExpanded = isExpanded,
                        currentUser = currentUser,
                        onToggleExpand = {
                            expandedDemandId = if (isExpanded) null else demand.id
                        },
                        onOpenBidDialog = { biddingDemand = demand },
                        onAcceptBid = { bid ->
                            onUpdateBidStatus(bid.id, "ACCEPTED")
                            Toast.makeText(context, "✅ ${bid.bidderName} teklifi kabul edildi!", Toast.LENGTH_SHORT).show()
                        },
                        onRejectBid = { bid ->
                            onUpdateBidStatus(bid.id, "REJECTED")
                            Toast.makeText(context, "Teklif reddedildi.", Toast.LENGTH_SHORT).show()
                        },
                        onContactBidder = { bid ->
                            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${bid.bidderPhone}"))
                            try {
                                context.startActivity(dialIntent)
                            } catch (e: Exception) {
                                onNavigateToChat(bid.bidderId, bid.bidderName)
                            }
                        },
                        onDeleteDemand = { demandToDelete = demand },
                        onDeleteBid = { bid -> bidToDelete = bid }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(60.dp))
            }
        }
    }

    // Submit Bid Dialog
    biddingDemand?.let { demand ->
        SubmitBidDialog(
            demand = demand,
            currentUser = currentUser,
            userMachines = userMachines,
            onDismiss = { biddingDemand = null },
            onSubmit = { bid ->
                onSubmitBid(bid)
                biddingDemand = null
                expandedDemandId = demand.id
                Toast.makeText(context, "🎉 Teklifiniz başarıyla iletildi!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Create Demand Dialog
    if (showCreateDialog) {
        CreateDemandDialog(
            currentUser = currentUser,
            onDismiss = { showCreateDialog = false },
            onSubmit = { newDemand ->
                onCreateDemand(newDemand)
                showCreateDialog = false
                Toast.makeText(context, "📢 İş talebiniz yayınlandı!", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun JobDemandCardWithBids(
    demand: JobDemand,
    bids: List<JobBid>,
    isExpanded: Boolean,
    currentUser: User?,
    onToggleExpand: () -> Unit,
    onOpenBidDialog: () -> Unit,
    onAcceptBid: (JobBid) -> Unit,
    onRejectBid: (JobBid) -> Unit,
    onContactBidder: (JobBid) -> Unit,
    onDeleteDemand: () -> Unit = {},
    onDeleteBid: (JobBid) -> Unit = {}
) {
    val isDemandOwner = currentUser == null ||
            currentUser.userType == com.example.data.model.UserType.ADMIN ||
            currentUser.id == demand.customerId ||
            demand.customerId == "demo_customer_1" ||
            demand.customerId == "demo_cust_1" ||
            (currentUser.phone.isNotBlank() && currentUser.phone == demand.customerPhone)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("demand_card_${demand.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header: Category, Badges, Date & Delete (if owner)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = BluePrimary.copy(alpha = 0.1f)
                    ) {
                        Text(
                            text = demand.category,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BluePrimary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    if (demand.isUrgent) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = StatusError.copy(alpha = 0.15f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.FlashOn, contentDescription = null, tint = StatusError, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(
                                    text = "Acil",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = StatusError
                                )
                            }
                        }
                    }

                    if (demand.isLowbedHaulage) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF7C3AED).copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "Lowbed Taşıma",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF7C3AED),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }

                val dateStr = SimpleDateFormat("dd MMM", Locale("tr", "TR")).format(Date(demand.createdAt))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = dateStr,
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                    if (isDemandOwner) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = StatusError.copy(alpha = 0.1f),
                            modifier = Modifier.clickable { onDeleteDemand() }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Talebi Sil",
                                    tint = StatusError,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Text("Talebi Sil", color = StatusError, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = demand.title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = NavyDark
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = demand.description,
                fontSize = 12.sp,
                color = Color(0xFF4B5563),
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Details info chips
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = BluePrimary, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = "${demand.city} / ${demand.district}", fontSize = 11.sp, color = TextSecondary)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = BlueAccent, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = demand.durationText, fontSize = 11.sp, color = TextSecondary)
                }

                if (demand.needsOperator) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = StatusSuccess, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(text = "Operatörlü", fontSize = 11.sp, color = StatusSuccess, fontWeight = FontWeight.SemiBold)
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Business, contentDescription = null, tint = NavyDark, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = demand.customerName, fontSize = 11.sp, color = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Footer: Budget, Expand Bids, and Place Bid CTA
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Tahmini Bütçe", fontSize = 10.sp, color = TextMuted)
                    Text(
                        text = if (demand.estimatedBudget > 0) "₺${"%,.0f".format(Locale("tr", "TR"), demand.estimatedBudget)}" else "Teklife Açık",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = NavyDark
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    // Toggle Bids View Button
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (bids.isNotEmpty()) Color(0xFFEFF6FF) else Color(0xFFF3F4F6),
                        modifier = Modifier.clickable { onToggleExpand() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.RequestQuote,
                                contentDescription = null,
                                tint = if (bids.isNotEmpty()) BluePrimary else TextMuted,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${bids.size} Teklif",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (bids.isNotEmpty()) BluePrimary else TextMuted
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Icon(
                                imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = if (bids.isNotEmpty()) BluePrimary else TextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // Place Direct Bid Button
                    Button(
                        onClick = onOpenBidDialog,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("bid_button_${demand.id}")
                    ) {
                        Icon(imageVector = Icons.Default.RequestQuote, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Teklif Ver", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // EXPANDABLE INCOMING BIDS SECTION
            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 14.dp)
                ) {
                    HorizontalDivider(color = Color(0xFFE5E7EB), thickness = 1.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Gelen Teklifler (${bids.size})",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = NavyDark
                        )
                        if (bids.isEmpty()) {
                            Text(
                                text = "Henüz teklif verilmedi",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (bids.isEmpty()) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFF9FAFB),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "Bu talebe ilk teklifi veren siz olun!",
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Button(
                                    onClick = onOpenBidDialog,
                                    colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                ) {
                                    Text("Hemen Teklif Gönder", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            bids.forEach { bid ->
                                BidItemCard(
                                    bid = bid,
                                    isDemandOwner = isDemandOwner,
                                    onAccept = { onAcceptBid(bid) },
                                    onReject = { onRejectBid(bid) },
                                    onContact = { onContactBidder(bid) },
                                    onDeleteBid = { onDeleteBid(bid) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BidItemCard(
    bid: JobBid,
    isDemandOwner: Boolean,
    onAccept: () -> Unit,
    onReject: () -> Unit,
    onContact: () -> Unit,
    onDeleteBid: () -> Unit = {}
) {
    val statusColor = when (bid.status) {
        "ACCEPTED" -> StatusSuccess
        "REJECTED" -> StatusError
        else -> StatusWarning
    }
    val statusLabel = when (bid.status) {
        "ACCEPTED" -> "Kabul Edildi"
        "REJECTED" -> "Reddedildi"
        else -> "Beklemede"
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFF8FAFC),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (bid.status == "ACCEPTED") StatusSuccess.copy(alpha = 0.5f) else Color(0xFFE2E8F0)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Bidder Header & Offered Price & Delete (if owner)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = bid.bidderName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = NavyDark
                    )
                    if (bid.bidderCompany.isNotBlank()) {
                        Text(
                            text = bid.bidderCompany,
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "₺${"%,.0f".format(Locale("tr", "TR"), bid.offeredPrice)} / ${bid.priceUnit}",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp,
                            color = BluePrimary
                        )
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = statusColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = statusLabel,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = statusColor,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    if (isDemandOwner) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = StatusError.copy(alpha = 0.12f),
                            modifier = Modifier
                                .clickable { onDeleteBid() }
                                .testTag("delete_bid_${bid.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Teklifi Sil",
                                    tint = StatusError,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "Sil",
                                    color = StatusError,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            if (bid.machineTitle.isNotBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Construction, contentDescription = null, tint = NavyDark, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Önerilen Makine: ${bid.machineTitle}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = NavyDark
                    )
                }
            }

            // Flags (Operator, Fuel, Transport)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (bid.hasOperator) {
                    Text(text = "✓ Operatörlü", fontSize = 10.sp, color = StatusSuccess, fontWeight = FontWeight.Bold)
                }
                if (bid.fuelIncluded) {
                    Text(text = "✓ Yakıt Dahil", fontSize = 10.sp, color = BluePrimary, fontWeight = FontWeight.Bold)
                }
                if (bid.transportIncluded) {
                    Text(text = "✓ Nakliye Dahil", fontSize = 10.sp, color = Color(0xFF7C3AED), fontWeight = FontWeight.Bold)
                }
            }

            if (bid.notes.isNotBlank()) {
                Text(
                    text = "“${bid.notes}”",
                    fontSize = 11.sp,
                    color = Color(0xFF475569),
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }

            Text(
                text = "Müsaitlik: ${bid.availableFromDate}",
                fontSize = 10.sp,
                color = TextMuted,
                fontWeight = FontWeight.Medium
            )

            // Action Buttons for demand owner
            if (isDemandOwner && bid.status == "PENDING") {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onReject,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusError),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("Reddet", fontSize = 11.sp)
                    }

                    Button(
                        onClick = onAccept,
                        colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("Kabul Et", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onContact,
                        colors = ButtonDefaults.buttonColors(containerColor = BluePrimary),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1.2f)
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("Ara/Mesaj", fontSize = 11.sp, color = Color.White)
                    }
                }
            } else if (isDemandOwner && bid.status == "ACCEPTED") {
                Spacer(modifier = Modifier.height(6.dp))
                Button(
                    onClick = onContact,
                    colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Tedarikçi ile İletişime Geç (${bid.bidderPhone})", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SubmitBidDialog(
    demand: JobDemand,
    currentUser: User?,
    userMachines: List<Machine>,
    onDismiss: () -> Unit,
    onSubmit: (JobBid) -> Unit
) {
    var priceStr by remember { mutableStateOf("") }
    var priceUnit by remember { mutableStateOf("Günlük") }
    var selectedMachineTitle by remember { mutableStateOf(userMachines.firstOrNull()?.title ?: "${demand.category} (Filomuzdan)") }
    var hasOperator by remember { mutableStateOf(true) }
    var fuelIncluded by remember { mutableStateOf(false) }
    var transportIncluded by remember { mutableStateOf(true) }
    var availableDate by remember { mutableStateOf("Hemen Müsait") }
    var notes by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("submit_bid_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        text = "Talebe Teklif Ver",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyDark
                    )
                    Text(
                        text = "Talep: ${demand.title}",
                        fontSize = 12.sp,
                        color = BluePrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }

                item {
                    Text(text = "Önerilecek Makine / Araç", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = NavyDark)
                    OutlinedTextField(
                        value = selectedMachineTitle,
                        onValueChange = { selectedMachineTitle = it },
                        placeholder = { Text("Örn: Komatsu PC210 22 Ton Paletli") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = priceStr,
                            onValueChange = { priceStr = it },
                            label = { Text("Teklif Fiyatı (₺) *") },
                            placeholder = { Text("Örn: 15000") },
                            modifier = Modifier.weight(1.2f),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            Text("Birim", fontSize = 11.sp, color = TextMuted)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("Günlük", "Saatlik", "Toplam").forEach { unit ->
                                    val isSel = priceUnit == unit
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (isSel) BluePrimary else Color(0xFFF3F4F6),
                                        modifier = Modifier.clickable { priceUnit = unit }
                                    ) {
                                        Text(
                                            text = unit,
                                            fontSize = 10.sp,
                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSel) Color.White else NavyDark,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = availableDate,
                        onValueChange = { availableDate = it },
                        label = { Text("Müsaitlik Başlangıç Tarihi") },
                        placeholder = { Text("Örn: Hemen / Pazartesi 08:00") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                // Checkboxes
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = hasOperator, onCheckedChange = { hasOperator = it })
                        Text(text = "Operatörlü Fiyat", fontSize = 13.sp, color = NavyDark)
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = fuelIncluded, onCheckedChange = { fuelIncluded = it })
                        Text(text = "Yakıt Dahil Fiyat", fontSize = 13.sp, color = NavyDark)
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = transportIncluded, onCheckedChange = { transportIncluded = it })
                        Text(text = "Lowbed / Nakliye Dahil", fontSize = 13.sp, color = NavyDark)
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Açıklama & Özel Şartlar") },
                        placeholder = { Text("Sertifikalar, vardiya durumu, ataşmanlar...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(80.dp),
                        shape = RoundedCornerShape(10.dp),
                        maxLines = 3
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("İptal")
                        }

                        Button(
                            onClick = {
                                val price = priceStr.toDoubleOrNull() ?: 0.0
                                if (price > 0) {
                                    val newBid = JobBid(
                                        id = "bid_${System.currentTimeMillis()}",
                                        demandId = demand.id,
                                        bidderId = currentUser?.id ?: "demo_owner_1",
                                        bidderName = currentUser?.fullName ?: "Mehmet Demir",
                                        bidderPhone = currentUser?.phone ?: "+90 533 444 55 66",
                                        bidderCompany = if (currentUser?.userType?.name == "OWNER") "Demir Makine Sanayi" else "Müteahhitlik Hizmetleri",
                                        machineTitle = selectedMachineTitle,
                                        offeredPrice = price,
                                        priceUnit = priceUnit,
                                        hasOperator = hasOperator,
                                        fuelIncluded = fuelIncluded,
                                        transportIncluded = transportIncluded,
                                        availableFromDate = availableDate,
                                        notes = notes,
                                        status = "PENDING"
                                    )
                                    onSubmit(newBid)
                                }
                            },
                            enabled = priceStr.isNotBlank() && (priceStr.toDoubleOrNull() ?: 0.0) > 0,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("submit_bid_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                        ) {
                            Text("Teklifi Gönder", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CreateDemandDialog(
    currentUser: User?,
    onDismiss: () -> Unit,
    onSubmit: (JobDemand) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Ekskavatör") }
    var city by remember { mutableStateOf(currentUser?.city?.ifBlank { "İstanbul" } ?: "İstanbul") }
    var district by remember { mutableStateOf(currentUser?.district?.ifBlank { "Başakşehir" } ?: "Başakşehir") }
    var durationText by remember { mutableStateOf("7 Gün") }
    var budgetStr by remember { mutableStateOf("") }
    var needsOperator by remember { mutableStateOf(true) }
    var needsFuel by remember { mutableStateOf(false) }
    var isUrgent by remember { mutableStateOf(false) }
    var isLowbedHaulage by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("create_demand_dialog"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text(
                        text = "Yeni Şantiye / Makine Talebi Aç",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyDark
                    )
                    Text(
                        text = "İhtiyacınızı detaylandırın, makine sahipleri teklif göndersin.",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                }

                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Talep Başlığı *") },
                        placeholder = { Text("Örn: 2 Hafta Süreli 30 Ton Ekskavatör") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                item {
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("İş Tanımı & Şantiye Detayları *") },
                        placeholder = { Text("Zemin tipi, vardiya durumu, özel aparat gereksinimleri...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(90.dp),
                        shape = RoundedCornerShape(10.dp),
                        maxLines = 3
                    )
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = category,
                            onValueChange = { category = it },
                            label = { Text("Kategori") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = durationText,
                            onValueChange = { durationText = it },
                            label = { Text("Süre") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = city,
                            onValueChange = { city = it },
                            label = { Text("İl") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = district,
                            onValueChange = { district = it },
                            label = { Text("İlçe") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = budgetStr,
                        onValueChange = { budgetStr = it },
                        label = { Text("Tahmini Bütçe (₺) (Opsiyonel)") },
                        placeholder = { Text("Örn: 50000") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                // Checkboxes
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = needsOperator, onCheckedChange = { needsOperator = it })
                        Text(text = "Operatörlü İstiyorum", fontSize = 13.sp, color = NavyDark)
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = isUrgent, onCheckedChange = { isUrgent = it })
                        Text(text = "Acil İhtiyaç (Hemen Gerekli)", fontSize = 13.sp, color = StatusError, fontWeight = FontWeight.SemiBold)
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = isLowbedHaulage, onCheckedChange = { isLowbedHaulage = it })
                        Text(text = "Lowbed Ağır Taşıma İhtiyacı", fontSize = 13.sp, color = NavyDark)
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("İptal")
                        }

                        Button(
                            onClick = {
                                if (title.isNotBlank()) {
                                    val newDemand = JobDemand(
                                        id = "dem_${System.currentTimeMillis()}",
                                        customerId = currentUser?.id ?: "demo_cust_1",
                                        customerName = currentUser?.fullName ?: "Ahmet Yılmaz",
                                        customerPhone = currentUser?.phone ?: "+90 532 111 22 33",
                                        title = title,
                                        description = description,
                                        category = category,
                                        city = city,
                                        district = district,
                                        durationText = durationText,
                                        estimatedBudget = budgetStr.toDoubleOrNull() ?: 0.0,
                                        needsOperator = needsOperator,
                                        needsFuel = needsFuel,
                                        isUrgent = isUrgent,
                                        isLowbedHaulage = isLowbedHaulage,
                                        status = "OPEN"
                                    )
                                    onSubmit(newDemand)
                                }
                            },
                            enabled = title.isNotBlank(),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("submit_create_demand_button"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = BluePrimary)
                        ) {
                            Text("Talebi Aç", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
