package com.example.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.model.Machine
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.CopyrightOverlay

/**
 * Data model for pin markers displayed on OpenStreetMap
 */
data class OsmMarkerItem(
    val id: String,
    val title: String,
    val snippet: String,
    val latitude: Double,
    val longitude: Double,
    val isDemand: Boolean = false,
    val priceText: String = "",
    val category: String = "",
    val originalMachine: Machine? = null
)

/**
 * Production-ready OpenStreetMap (osmdroid) MapView component for Jetpack Compose.
 *
 * Features:
 * - 100% Free & Open-Source (No API Key Required)
 * - Mapnik high-res OSM tile rendering
 * - Multi-touch zoom & pan gestures
 * - Custom pins with anchors and click handlers
 * - Smooth camera navigation with animateTo
 * - User GPS location pin
 * - In-compose zoom controls & re-center button
 * - Proper Android lifecycle handling (onResume, onPause, onDetach)
 */
@Composable
fun OsmMapView(
    modifier: Modifier = Modifier,
    markers: List<OsmMarkerItem> = emptyList(),
    centerLatitude: Double = 41.0082,
    centerLongitude: Double = 28.9784,
    zoomLevel: Double = 12.0,
    userLatitude: Double? = null,
    userLongitude: Double? = null,
    selectedMarkerId: String? = null,
    onMarkerClick: (OsmMarkerItem) -> Unit = {},
    showZoomControls: Boolean = true
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // 1. Initialize osmdroid configuration once per context
    remember {
        try {
            val sharedPrefs = context.getSharedPreferences("osmdroid_prefs", Context.MODE_PRIVATE)
            Configuration.getInstance().load(context, sharedPrefs)
            Configuration.getInstance().userAgentValue = context.packageName
            // Depolama izni gerektirmemesi için harita önbelleği uygulama dizininde tutulur
            Configuration.getInstance().osmdroidBasePath = java.io.File(context.cacheDir, "osmdroid")
            Configuration.getInstance().osmdroidTileCache = java.io.File(context.cacheDir, "osmdroid/tiles")
        } catch (e: Exception) {
            // Fallback user-agent
            Configuration.getInstance().userAgentValue = "MakineBul-Android-App/1.0"
        }
    }

    // 2. Remember MapView instance
    val mapView = remember {
        MapView(context).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            controller.setZoom(zoomLevel)
            controller.setCenter(GeoPoint(centerLatitude, centerLongitude))
        }
    }

    // 3. Lifecycle observer to prevent memory leaks and tile fetch stalls
    DisposableEffect(lifecycleOwner, mapView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            mapView.onDetach()
        }
    }

    // 4. Update camera center when center coordinates change
    LaunchedEffect(centerLatitude, centerLongitude) {
        if (centerLatitude != 0.0 && centerLongitude != 0.0) {
            mapView.controller.animateTo(GeoPoint(centerLatitude, centerLongitude))
        }
    }

    // 5. Pre-create cached drawables for marker performance
    val defaultMachineDrawable = remember(context) {
        createCustomPinDrawable(
            context = context,
            pinColor = android.graphics.Color.parseColor("#1E40AF"), // BluePrimary
            innerCircleColor = android.graphics.Color.WHITE,
            symbol = "🚜"
        )
    }

    val selectedMachineDrawable = remember(context) {
        createCustomPinDrawable(
            context = context,
            pinColor = android.graphics.Color.parseColor("#059669"), // StatusSuccess Green
            innerCircleColor = android.graphics.Color.WHITE,
            symbol = "✓",
            isHighlighted = true
        )
    }

    val demandDrawable = remember(context) {
        createCustomPinDrawable(
            context = context,
            pinColor = android.graphics.Color.parseColor("#DC2626"), // StatusError Red
            innerCircleColor = android.graphics.Color.WHITE,
            symbol = "📢"
        )
    }

    val userLocationDrawable = remember(context) {
        createUserLocationDrawable(context)
    }

    Box(modifier = modifier) {
        // Native osmdroid MapView embedded in Jetpack Compose
        AndroidView(
            factory = { mapView },
            modifier = Modifier.fillMaxSize(),
            update = { view ->
                // Clear old overlays
                view.overlays.clear()

                // OpenStreetMap lisansı gereği zorunlu atıf
                view.overlays.add(CopyrightOverlay(view.context))

                // Add User GPS Location Marker if available
                if (userLatitude != null && userLongitude != null && userLatitude != 0.0 && userLongitude != 0.0) {
                    val userMarker = Marker(view).apply {
                        position = GeoPoint(userLatitude, userLongitude)
                        title = "📍 Sizin Konumunuz"
                        snippet = "GPS ile tespit edilen güncel konumunuz"
                        icon = userLocationDrawable
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                    }
                    view.overlays.add(userMarker)
                }

                // Add Machine & Demand Markers
                markers.forEach { item ->
                    if (item.latitude != 0.0 && item.longitude != 0.0) {
                        val isSelected = item.id == selectedMarkerId
                        val marker = Marker(view).apply {
                            position = GeoPoint(item.latitude, item.longitude)
                            title = item.title
                            snippet = if (item.priceText.isNotBlank()) "${item.snippet} • ${item.priceText}" else item.snippet
                            icon = when {
                                isSelected -> selectedMachineDrawable
                                item.isDemand -> demandDrawable
                                else -> defaultMachineDrawable
                            }
                            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                            setOnMarkerClickListener { clickedMarker, _ ->
                                clickedMarker.showInfoWindow()
                                view.controller.animateTo(clickedMarker.position)
                                onMarkerClick(item)
                                true
                            }
                        }
                        view.overlays.add(marker)

                        if (isSelected) {
                            marker.showInfoWindow()
                        }
                    }
                }

                view.invalidate()
            }
        )

        // Overlay Map Controls (Zoom In/Out, Recenter on GPS)
        if (showZoomControls) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.BottomEnd
            ) {
                androidx.compose.foundation.layout.Column(
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    // Recenter on user location or center
                    if (userLatitude != null && userLongitude != null) {
                        SmallFloatingActionButton(
                            onClick = {
                                mapView.controller.animateTo(GeoPoint(userLatitude, userLongitude))
                                mapView.controller.setZoom(14.0)
                            },
                            containerColor = MaterialTheme.colorScheme.surface,
                            contentColor = MaterialTheme.colorScheme.primary,
                            shape = CircleShape,
                            elevation = FloatingActionButtonDefaults.elevation(3.dp),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(Icons.Default.MyLocation, contentDescription = "Konumuma Git", modifier = Modifier.size(20.dp))
                        }
                    }

                    // Zoom In
                    SmallFloatingActionButton(
                        onClick = { mapView.controller.zoomIn() },
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.onSurface,
                        shape = CircleShape,
                        elevation = FloatingActionButtonDefaults.elevation(3.dp),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Yakınlaş", modifier = Modifier.size(20.dp))
                    }

                    // Zoom Out
                    SmallFloatingActionButton(
                        onClick = { mapView.controller.zoomOut() },
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = MaterialTheme.colorScheme.onSurface,
                        shape = CircleShape,
                        elevation = FloatingActionButtonDefaults.elevation(3.dp),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Uzaklaş", modifier = Modifier.size(20.dp))
                    }
                }
            }
        }
    }
}

/**
 * Dynamically draws an attractive teardrop pin marker with custom icon/color
 */
private fun createCustomPinDrawable(
    context: Context,
    pinColor: Int,
    innerCircleColor: Int,
    symbol: String,
    isHighlighted: Boolean = false
): Drawable {
    val density = context.resources.displayMetrics.density
    val width = ((if (isHighlighted) 48 else 40) * density).toInt()
    val height = ((if (isHighlighted) 60 else 50) * density).toInt()

    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = pinColor
    }

    val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = android.graphics.Color.parseColor("#40000000")
    }

    val cx = width / 2f
    val radius = width * 0.42f
    val tipY = height - (4 * density)

    // Subtle drop shadow under pin tip
    canvas.drawOval(cx - (8 * density), tipY - (2 * density), cx + (8 * density), tipY + (4 * density), shadowPaint)

    // Teardrop Pin Path
    val path = Path().apply {
        moveTo(cx, tipY)
        cubicTo(
            cx - radius * 0.9f, tipY - height * 0.45f,
            cx - radius, radius * 1.8f,
            cx - radius, radius
        )
        arcTo(
            cx - radius, 0f,
            cx + radius, radius * 2f,
            180f, 180f, false
        )
        cubicTo(
            cx + radius, radius * 1.8f,
            cx + radius * 0.9f, tipY - height * 0.45f,
            cx, tipY
        )
        close()
    }
    canvas.drawPath(path, paint)

    // White rim border
    val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2 * density
        color = android.graphics.Color.WHITE
    }
    canvas.drawPath(path, strokePaint)

    // Inner circle
    val innerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = innerCircleColor
    }
    canvas.drawCircle(cx, radius, radius * 0.65f, innerPaint)

    // Center symbol text (emoji or mark)
    val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = (if (isHighlighted) 15 else 12) * density
        textAlign = Paint.Align.CENTER
        color = pinColor
    }
    val textY = radius - ((textPaint.descent() + textPaint.ascent()) / 2)
    canvas.drawText(symbol, cx, textY, textPaint)

    return BitmapDrawable(context.resources, bitmap)
}

/**
 * Draws a pulsating blue dot for user's GPS position
 */
private fun createUserLocationDrawable(context: Context): Drawable {
    val density = context.resources.displayMetrics.density
    val size = (28 * density).toInt()

    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    val center = size / 2f

    // Outer halo
    val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.parseColor("#4D3B82F6")
        style = Paint.Style.FILL
    }
    canvas.drawCircle(center, center, center * 0.9f, haloPaint)

    // White border ring
    val whiteRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE
        style = Paint.Style.FILL
    }
    canvas.drawCircle(center, center, center * 0.55f, whiteRingPaint)

    // Core blue dot
    val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.parseColor("#2563EB")
        style = Paint.Style.FILL
    }
    canvas.drawCircle(center, center, center * 0.42f, corePaint)

    return BitmapDrawable(context.resources, bitmap)
}
