package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.JobDemand
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class JobDemandRepository {

    private val scope = CoroutineScope(Dispatchers.IO)
    private val _demands = MutableStateFlow<List<JobDemand>>(emptyList())
    val demands: StateFlow<List<JobDemand>> = _demands.asStateFlow()

    init {
        FirebaseManager.runWhenAuthenticated { listenToFirestoreDemands() }
    }

    private fun listenToFirestoreDemands() {
        if (!FirebaseManager.isAvailable) return

        scope.launch {
            try {
                FirebaseManager.db?.collection("jobDemands")
                    ?.addSnapshotListener { snapshot, error ->
                        if (error != null || snapshot == null) return@addSnapshotListener
                        val list = snapshot.documents.mapNotNull { docToDemand(it) }
                        _demands.value = list
                    }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun createDemand(demand: JobDemand): JobDemand {
        val (lat, lng) = getCoordinatesForCity(demand.city, demand.district)
        val newDemand = if (demand.id.isEmpty()) {
            demand.copy(id = "dem_${System.currentTimeMillis()}", latitude = if (demand.latitude != 0.0) demand.latitude else lat, longitude = if (demand.longitude != 0.0) demand.longitude else lng)
        } else {
            demand.copy(latitude = if (demand.latitude != 0.0) demand.latitude else lat, longitude = if (demand.longitude != 0.0) demand.longitude else lng)
        }
        _demands.value = listOf(newDemand) + _demands.value

        if (FirebaseManager.isAvailable) {
            scope.launch {
                try {
                    val map = hashMapOf<String, Any>(
                        "id" to newDemand.id,
                        "customerId" to newDemand.customerId,
                        "customerName" to newDemand.customerName,
                        "customerPhone" to newDemand.customerPhone,
                        "title" to newDemand.title,
                        "description" to newDemand.description,
                        "category" to newDemand.category,
                        "city" to newDemand.city,
                        "district" to newDemand.district,
                        "latitude" to newDemand.latitude,
                        "longitude" to newDemand.longitude,
                        "projectType" to newDemand.projectType,
                        "durationText" to newDemand.durationText,
                        "estimatedBudget" to newDemand.estimatedBudget,
                        "needsOperator" to newDemand.needsOperator,
                        "needsFuel" to newDemand.needsFuel,
                        "isUrgent" to newDemand.isUrgent,
                        "isLowbedHaulage" to newDemand.isLowbedHaulage,
                        "offersCount" to newDemand.offersCount,
                        "status" to newDemand.status,
                        "createdAt" to newDemand.createdAt
                    )
                    FirebaseManager.db?.collection("jobDemands")?.document(newDemand.id)?.set(map)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
        return newDemand
    }

    fun incrementOffersCount(demandId: String) {
        _demands.value = _demands.value.map {
            if (it.id == demandId) it.copy(offersCount = it.offersCount + 1) else it
        }
    }

    fun closeDemand(demandId: String) {
        _demands.value = _demands.value.map {
            if (it.id == demandId) it.copy(status = "CLOSED") else it
        }

        if (FirebaseManager.isAvailable) {
            scope.launch {
                try {
                    FirebaseManager.db?.collection("jobDemands")?.document(demandId)?.update("status", "CLOSED")
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    fun deleteDemand(demandId: String) {
        _demands.value = _demands.value.filter { it.id != demandId }

        if (FirebaseManager.isAvailable) {
            scope.launch {
                try {
                    FirebaseManager.db?.collection("jobDemands")?.document(demandId)?.delete()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    private fun getCoordinatesForCity(city: String, district: String): Pair<Double, Double> {
        return when (city.lowercase().trim()) {
            "istanbul", "istanbul" -> Pair(41.0082, 28.9784)
            "ankara" -> Pair(39.9334, 32.8597)
            "izmir", "izmir" -> Pair(38.4237, 27.1428)
            "bursa" -> Pair(40.1885, 29.0610)
            "kocaeli", "izmit", "gebze" -> Pair(40.8035, 29.4410)
            "antalya" -> Pair(36.8969, 30.7133)
            "adana" -> Pair(37.0000, 35.3213)
            "gaziantep" -> Pair(37.0662, 37.3833)
            "trabzon" -> Pair(41.0027, 39.7168)
            else -> Pair(41.0082, 28.9784)
        }
    }

    private fun docToDemand(doc: DocumentSnapshot): JobDemand? {
        return try {
            JobDemand(
                id = doc.getString("id") ?: doc.id,
                customerId = doc.getString("customerId") ?: "",
                customerName = doc.getString("customerName") ?: "Müşteri",
                customerPhone = doc.getString("customerPhone") ?: "",
                title = doc.getString("title") ?: "İş Talebi",
                description = doc.getString("description") ?: "",
                category = doc.getString("category") ?: "Ekskavatör",
                city = doc.getString("city") ?: "İstanbul",
                district = doc.getString("district") ?: "",
                latitude = (doc.getDouble("latitude") ?: 41.0924),
                longitude = (doc.getDouble("longitude") ?: 28.8021),
                projectType = doc.getString("projectType") ?: "Şantiye / Hafriyat",
                durationText = doc.getString("durationText") ?: "1 Gün",
                estimatedBudget = (doc.getDouble("estimatedBudget") ?: 0.0),
                needsOperator = (doc.getBoolean("needsOperator") ?: true),
                needsFuel = (doc.getBoolean("needsFuel") ?: false),
                isUrgent = (doc.getBoolean("isUrgent") ?: false),
                isLowbedHaulage = (doc.getBoolean("isLowbedHaulage") ?: false),
                offersCount = (doc.getLong("offersCount")?.toInt() ?: 0),
                status = doc.getString("status") ?: "OPEN",
                createdAt = (doc.getLong("createdAt") ?: System.currentTimeMillis())
            )
        } catch (e: Exception) {
            null
        }
    }
}
