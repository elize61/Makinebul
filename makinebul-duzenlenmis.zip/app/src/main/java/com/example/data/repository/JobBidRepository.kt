package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.JobBid
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class JobBidRepository {

    private val scope = CoroutineScope(Dispatchers.IO)
    private val _bids = MutableStateFlow<List<JobBid>>(emptyList())
    val bids: StateFlow<List<JobBid>> = _bids.asStateFlow()

    init {
        FirebaseManager.runWhenAuthenticated { listenToFirestoreBids() }
    }

    private fun listenToFirestoreBids() {
        if (!FirebaseManager.isAvailable) return

        scope.launch {
            try {
                FirebaseManager.db?.collection("jobBids")
                    ?.addSnapshotListener { snapshot, error ->
                        if (error != null || snapshot == null) return@addSnapshotListener
                        val list = snapshot.documents.mapNotNull { docToBid(it) }
                        _bids.value = list
                    }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun submitBid(bid: JobBid): JobBid {
        val newBid = if (bid.id.isEmpty()) bid.copy(id = "bid_${System.currentTimeMillis()}") else bid
        _bids.value = listOf(newBid) + _bids.value

        if (FirebaseManager.isAvailable) {
            scope.launch {
                try {
                    val map = hashMapOf<String, Any>(
                        "id" to newBid.id,
                        "demandId" to newBid.demandId,
                        "bidderId" to newBid.bidderId,
                        "bidderName" to newBid.bidderName,
                        "bidderPhone" to newBid.bidderPhone,
                        "bidderCompany" to newBid.bidderCompany,
                        "machineId" to newBid.machineId,
                        "machineTitle" to newBid.machineTitle,
                        "offeredPrice" to newBid.offeredPrice,
                        "priceUnit" to newBid.priceUnit,
                        "hasOperator" to newBid.hasOperator,
                        "fuelIncluded" to newBid.fuelIncluded,
                        "transportIncluded" to newBid.transportIncluded,
                        "availableFromDate" to newBid.availableFromDate,
                        "notes" to newBid.notes,
                        "status" to newBid.status,
                        "createdAt" to newBid.createdAt
                    )
                    FirebaseManager.db?.collection("jobBids")?.document(newBid.id)?.set(map)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
        return newBid
    }

    fun updateBidStatus(bidId: String, newStatus: String) {
        _bids.value = _bids.value.map {
            if (it.id == bidId) it.copy(status = newStatus) else it
        }

        if (FirebaseManager.isAvailable) {
            scope.launch {
                try {
                    FirebaseManager.db?.collection("jobBids")?.document(bidId)?.update("status", newStatus)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    fun deleteBid(bidId: String) {
        _bids.value = _bids.value.filter { it.id != bidId }

        if (FirebaseManager.isAvailable) {
            scope.launch {
                try {
                    FirebaseManager.db?.collection("jobBids")?.document(bidId)?.delete()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    fun getBidsForDemand(demandId: String): List<JobBid> {
        return _bids.value.filter { it.demandId == demandId }
    }

    private fun docToBid(doc: DocumentSnapshot): JobBid? {
        return try {
            JobBid(
                id = doc.getString("id") ?: doc.id,
                demandId = doc.getString("demandId") ?: "",
                bidderId = doc.getString("bidderId") ?: "",
                bidderName = doc.getString("bidderName") ?: "",
                bidderPhone = doc.getString("bidderPhone") ?: "",
                bidderCompany = doc.getString("bidderCompany") ?: "",
                machineId = doc.getString("machineId") ?: "",
                machineTitle = doc.getString("machineTitle") ?: "",
                offeredPrice = (doc.getDouble("offeredPrice") ?: 0.0),
                priceUnit = doc.getString("priceUnit") ?: "Günlük",
                hasOperator = (doc.getBoolean("hasOperator") ?: true),
                fuelIncluded = (doc.getBoolean("fuelIncluded") ?: false),
                transportIncluded = (doc.getBoolean("transportIncluded") ?: false),
                availableFromDate = doc.getString("availableFromDate") ?: "Hemen Müsait",
                notes = doc.getString("notes") ?: "",
                status = doc.getString("status") ?: "PENDING",
                createdAt = (doc.getLong("createdAt") ?: System.currentTimeMillis())
            )
        } catch (e: Exception) {
            null
        }
    }
}
