package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.Offer
import com.example.data.model.OfferStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class OfferRepository {

    private val _offers = MutableStateFlow<List<Offer>>(emptyList())
    val offers: StateFlow<List<Offer>> = _offers.asStateFlow()

    init {
        FirebaseManager.runWhenAuthenticated { fetchOffersFromFirestore() }
    }

    private fun fetchOffersFromFirestore() {
        try {
            val db = FirebaseManager.getFirestore() ?: return
            db.collection("offers").addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null) return@addSnapshotListener
                val remoteOffers = snapshot.documents.mapNotNull { doc ->
                    try {
                        Offer(
                            id = doc.getString("id") ?: doc.id,
                            customerId = doc.getString("customerId") ?: "",
                            customerName = doc.getString("customerName") ?: "",
                            customerPhone = doc.getString("customerPhone") ?: "",
                            customerCompany = doc.getString("customerCompany") ?: "Şantiye & Proje Sahibi",
                            customerRating = doc.getDouble("customerRating") ?: 0.0,
                            customerCompletedJobs = doc.getLong("customerCompletedJobs")?.toInt() ?: 0,
                            customerCity = doc.getString("customerCity") ?: "",
                            customerDistrict = doc.getString("customerDistrict") ?: "",
                            ownerId = doc.getString("ownerId") ?: "",
                            machineId = doc.getString("machineId") ?: "",
                            machineTitle = doc.getString("machineTitle") ?: "",
                            machineCategory = doc.getString("machineCategory") ?: "",
                            startDate = doc.getString("startDate") ?: "",
                            endDate = doc.getString("endDate") ?: "",
                            workingHours = doc.getLong("workingHours")?.toInt() ?: 8,
                            location = doc.getString("location") ?: "",
                            description = doc.getString("description") ?: "",
                            offeredPrice = doc.getDouble("offeredPrice") ?: 0.0,
                            status = try {
                                OfferStatus.valueOf(doc.getString("status") ?: "BEKLENIYOR")
                            } catch (ex: Exception) {
                                OfferStatus.BEKLENIYOR
                            },
                            createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
                        )
                    } catch (ex: Exception) {
                        null
                    }
                }
                val cutoffTime = System.currentTimeMillis() - com.example.data.util.DataCleanupManager.RETENTION_PERIOD_MS
                val activeOrRecentOffers = remoteOffers.filter { offer ->
                    val isTerminal = offer.status == OfferStatus.REDDEDILDI || offer.status == OfferStatus.IPTAL_EDILDI || offer.status == OfferStatus.TAMAMLANDI
                    !isTerminal || offer.createdAt >= cutoffTime
                }
                _offers.value = activeOrRecentOffers
            }
        } catch (e: Exception) {
            // Graceful fallback
        }
    }

    fun createOffer(
        customerId: String,
        customerName: String,
        customerPhone: String,
        ownerId: String,
        machineId: String,
        machineTitle: String,
        machineCategory: String,
        startDate: String,
        endDate: String,
        workingHours: Int,
        location: String,
        description: String,
        offeredPrice: Double,
        customerCompany: String = "Şantiye & Proje Sahibi",
        customerRating: Double = 0.0,
        customerCompletedJobs: Int = 0,
        customerCity: String = "",
        customerDistrict: String = ""
    ): Result<Offer> {
        if (startDate.isBlank() || endDate.isBlank() || location.isBlank() || offeredPrice <= 0) {
            return Result.failure(Exception("Lütfen başlangıç/bitiş tarihi, iş yeri ve geçerli teklif tutarı giriniz."))
        }

        val newOffer = Offer(
            id = "off_${System.currentTimeMillis()}",
            customerId = customerId,
            customerName = customerName,
            customerPhone = customerPhone,
            customerCompany = customerCompany,
            customerRating = customerRating,
            customerCompletedJobs = customerCompletedJobs,
            customerCity = customerCity,
            customerDistrict = customerDistrict,
            ownerId = ownerId,
            machineId = machineId,
            machineTitle = machineTitle,
            machineCategory = machineCategory,
            startDate = startDate,
            endDate = endDate,
            workingHours = workingHours,
            location = location,
            description = description,
            offeredPrice = offeredPrice,
            status = OfferStatus.BEKLENIYOR,
            createdAt = System.currentTimeMillis()
        )

        _offers.value = listOf(newOffer) + _offers.value
        saveOfferToFirestore(newOffer)

        // Trigger FCM Push Notification for new offer
        FirebaseManager.sendPushNotification(
            title = "💼 Yeni Fiyat Teklifi Sunuldu!",
            body = "${newOffer.customerName}, '${newOffer.machineTitle}' makineniz için ${newOffer.offeredPrice} ₺ teklif sundu.",
            type = "OFFER_CREATED",
            recipientUserId = ownerId,
            extraData = mapOf("offerId" to newOffer.id, "machineId" to machineId)
        )

        return Result.success(newOffer)
    }

    fun updateOfferStatus(offerId: String, newStatus: OfferStatus): Result<Offer> {
        var updatedOffer: Offer? = null
        _offers.value = _offers.value.map { offer ->
            if (offer.id == offerId) {
                val modified = offer.copy(status = newStatus)
                updatedOffer = modified
                modified
            } else offer
        }
        return if (updatedOffer != null) {
            val offer = updatedOffer!!
            saveOfferToFirestore(offer)

            // Trigger FCM Push Notification on offer status update
            val title = if (newStatus == OfferStatus.KABUL_EDILDI) "✅ Teklifiniz Kabul Edildi!" else "❌ Teklif Durumu Güncellendi: ${newStatus.labelTr}"
            val body = "'${offer.machineTitle}' ilanına verdiğiniz ${offer.offeredPrice} ₺ teklif durumu: ${newStatus.labelTr}."
            
            FirebaseManager.sendPushNotification(
                title = title,
                body = body,
                type = if (newStatus == OfferStatus.KABUL_EDILDI) "OFFER_ACCEPTED" else "OFFER_UPDATED",
                recipientUserId = offer.customerId,
                extraData = mapOf("offerId" to offer.id, "status" to newStatus.name)
            )

            Result.success(offer)
        } else Result.failure(Exception("Teklif bulunamadı."))
    }

    fun getCustomerOffers(customerId: String): List<Offer> {
        return _offers.value.filter { it.customerId == customerId || customerId == "demo_customer_1" }
    }

    fun getOwnerOffers(ownerId: String): List<Offer> {
        return _offers.value.filter { it.ownerId == ownerId || ownerId == "demo_owner_1" }
    }

    fun deleteOffer(offerId: String) {
        _offers.value = _offers.value.filter { it.id != offerId }
        try {
            FirebaseManager.getFirestore()?.collection("offers")?.document(offerId)?.delete()
        } catch (e: Exception) {
            // Graceful fallback
        }
    }

    fun deleteOffers(offerIds: Collection<String>) {
        val idsSet = offerIds.toSet()
        _offers.value = _offers.value.filter { it.id !in idsSet }
        try {
            val db = FirebaseManager.getFirestore() ?: return
            idsSet.forEach { id ->
                db.collection("offers").document(id).delete()
            }
        } catch (e: Exception) {
            // Graceful fallback
        }
    }

    fun deleteAllOffersForUser(userId: String, isOwner: Boolean) {
        val toDelete = _offers.value.filter {
            if (isOwner) it.ownerId == userId || userId == "demo_owner_1"
            else it.customerId == userId || userId == "demo_customer_1"
        }
        deleteOffers(toDelete.map { it.id })
    }

    private fun saveOfferToFirestore(offer: Offer) {
        try {
            val db = FirebaseManager.getFirestore() ?: return
            val offerMap = hashMapOf(
                "id" to offer.id,
                "customerId" to offer.customerId,
                "customerName" to offer.customerName,
                "customerPhone" to offer.customerPhone,
                "customerCompany" to offer.customerCompany,
                "customerRating" to offer.customerRating,
                "customerCompletedJobs" to offer.customerCompletedJobs,
                "customerCity" to offer.customerCity,
                "customerDistrict" to offer.customerDistrict,
                "ownerId" to offer.ownerId,
                "machineId" to offer.machineId,
                "machineTitle" to offer.machineTitle,
                "machineCategory" to offer.machineCategory,
                "startDate" to offer.startDate,
                "endDate" to offer.endDate,
                "workingHours" to offer.workingHours,
                "location" to offer.location,
                "description" to offer.description,
                "offeredPrice" to offer.offeredPrice,
                "status" to offer.status.name,
                "createdAt" to offer.createdAt
            )
            db.collection("offers").document(offer.id).set(offerMap)
        } catch (e: Exception) {
            // Graceful fallback
        }
    }
}
