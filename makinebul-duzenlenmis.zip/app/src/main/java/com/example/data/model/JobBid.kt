package com.example.data.model

data class JobBid(
    val id: String = "",
    val demandId: String = "",
    val bidderId: String = "",
    val bidderName: String = "",
    val bidderPhone: String = "",
    val bidderCompany: String = "",
    val machineId: String = "",
    val machineTitle: String = "",
    val offeredPrice: Double = 0.0,
    val priceUnit: String = "Günlük", // "Günlük", "Saatlik", "Toplam Proje", "Sefer Başı"
    val hasOperator: Boolean = true,
    val fuelIncluded: Boolean = false,
    val transportIncluded: Boolean = false,
    val availableFromDate: String = "Hemen Müsait",
    val notes: String = "",
    val status: String = "PENDING", // "PENDING", "ACCEPTED", "REJECTED"
    val createdAt: Long = System.currentTimeMillis()
)
