package com.example.data.model

data class JobDemand(
    val id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val title: String = "",
    val description: String = "",
    val category: String = "Ekskavatör",
    val city: String = "İstanbul",
    val district: String = "Başakşehir",
    val latitude: Double = 41.0924,
    val longitude: Double = 28.8021,
    val projectType: String = "Şantiye / Hafriyat", // "Şantiye / Hafriyat", "Yol / Altyapı", "Bina / Yıkım", "Nakliye / Lowbed", "Diğer"
    val durationText: String = "2 Hafta",
    val estimatedBudget: Double = 0.0,
    val needsOperator: Boolean = true,
    val needsFuel: Boolean = false,
    val isUrgent: Boolean = false,
    val isLowbedHaulage: Boolean = false,
    val offersCount: Int = 0,
    val status: String = "OPEN", // "OPEN", "IN_NEGOTIATION", "CLOSED"
    val createdAt: Long = System.currentTimeMillis()
)
