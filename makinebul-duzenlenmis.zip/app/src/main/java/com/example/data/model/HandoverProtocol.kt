package com.example.data.model

data class HandoverProtocol(
    val id: String = "",
    val machineId: String = "",
    val machineTitle: String = "",
    val offerId: String = "",
    val ownerId: String = "",
    val ownerName: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val initialHoursCounter: Double = 1250.0, // Başlangıç Çalışma Saati Sayacı
    val finalHoursCounter: Double = 0.0, // İade Çalışma Saati Sayacı
    val initialFuelPercent: Int = 100, // %100, %75 vb.
    val finalFuelPercent: Int = 100,
    val deliveryDate: String = "",
    val returnDate: String = "",
    val conditionNotes: String = "",
    val photosBefore: List<String> = emptyList(),
    val photosAfter: List<String> = emptyList(),
    val isCleanDelivered: Boolean = true,
    val hasOperatorLicenseChecked: Boolean = true,
    val hasInsuranceVerified: Boolean = true,
    val status: String = "ACTIVE", // "ACTIVE", "COMPLETED", "DISPUTED"
    val createdAt: Long = System.currentTimeMillis()
)
