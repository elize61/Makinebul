package com.example.data.firebase

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage

import com.example.data.model.UserType
import com.google.firebase.firestore.ListenerRegistration

object FirebaseManager {
    private const val TAG = "FirebaseManager"
    const val CHANNEL_NORMAL = "normal_notifications"
    const val CHANNEL_EMERGENCY = "emergency_alerts"
    
    var isFirebaseInitialized: Boolean = false
        private set

    var appContext: Context? = null
        private set

    var fcmToken: String? = null
        private set

    var activeUserId: String? = null
        private set

    var activeUserType: UserType? = null
        private set

    private var notificationListener: ListenerRegistration? = null
    private val appStartTime = System.currentTimeMillis()

    val isAvailable: Boolean
        get() = isFirebaseInitialized && getFirestore() != null

    val db: FirebaseFirestore?
        get() = getFirestore()

    fun setActiveUser(userId: String?, userType: UserType?) {
        activeUserId = userId
        activeUserType = userType
        Log.d(TAG, "Active user updated for notification routing: userId=$userId, type=$userType")
        if (userId != null && userType != null) {
            listenForUserNotifications(userId, userType)
        } else {
            notificationListener?.remove()
            notificationListener = null
        }
    }

    fun initialize(context: Context) {
        appContext = context.applicationContext
        try {
            if (FirebaseApp.getApps(context).isEmpty()) {
                FirebaseApp.initializeApp(context)
            }
            createNotificationChannels(context)

            isFirebaseInitialized = true

            // Setup device token for realtime Firestore notifications
            fcmToken = "device_${java.util.UUID.randomUUID().toString().take(12)}"

            Log.d(TAG, "Firebase initialized successfully with Auth, Firestore & Storage.")
        } catch (e: Exception) {
            isFirebaseInitialized = false
            Log.w(TAG, "Firebase initialization fallback to Demo Mode: ${e.localizedMessage}")
        }
    }

    /**
     * Firestore kuralları oturum (anonim dahil) istediği için dinleyiciler
     * ancak bir kullanıcı oturumu varken başlatılır. Oturum yoksa anonim giriş yapılır.
     */
    fun runWhenAuthenticated(block: () -> Unit) {
        val auth = getAuth()
        if (auth == null || auth.currentUser != null) {
            block()
            return
        }
        var done = false
        var listener: FirebaseAuth.AuthStateListener? = null
        listener = FirebaseAuth.AuthStateListener { a ->
            if (a.currentUser != null && !done) {
                done = true
                listener?.let { a.removeAuthStateListener(it) }
                block()
            }
        }
        auth.addAuthStateListener(listener)
        auth.signInAnonymously().addOnFailureListener {
            Log.w(TAG, "Anonymous sign-in failed: ${it.localizedMessage}")
        }
    }

    fun updateFcmToken(token: String) {
        fcmToken = token
    }

    private fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            
            val normalChannel = NotificationChannel(
                CHANNEL_NORMAL,
                "Genel Bildirimler",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "MakineBul teklif, mesaj ve genel uygulama bildirimleri"
            }

            val emergencyChannel = NotificationChannel(
                CHANNEL_EMERGENCY,
                "Acil Çekici / Lastikçi Uyarıları",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Yüksek öncelikli acil çekici ve lastikçi talepleri"
                enableVibration(true)
            }

            notificationManager.createNotificationChannel(normalChannel)
            notificationManager.createNotificationChannel(emergencyChannel)
        }
    }

    fun syncUserFcmToken(uid: String, token: String?) {
        if (token == null) return
        try {
            getFirestore()?.collection("kullanıcılar")?.document(uid)
                ?.update("fcmToken", token, "lastActive", System.currentTimeMillis())
        } catch (e: Exception) {
            Log.w(TAG, "Could not update FCM token in Firestore", e)
        }
    }

    /**
     * Check if notification is targeted for the current logged-in user or role
     */
    fun shouldShowNotificationLocally(type: String, recipientUserId: String?): Boolean {
        // If no user is logged in, do not display
        val currentUid = activeUserId
        val currentRole = activeUserType

        // STRICT SEPARATION: Tow truck operators MUST NEVER receive tire notifications!
        if (currentRole == UserType.DUTY_TOW) {
            if (type.contains("TIRE", ignoreCase = true) || recipientUserId == "DUTY_TIRE_PROVIDERS") {
                return false
            }
        }

        // Tire service operators MUST NEVER receive tow truck notifications!
        if (currentRole == UserType.DUTY_TIRE) {
            if (type.contains("TOW", ignoreCase = true) || recipientUserId == "DUTY_TOW_PROVIDERS") {
                return false
            }
        }

        if (recipientUserId.isNullOrBlank() || recipientUserId == "ALL") {
            return type == "ADMIN_NOTIFICATION" || type == "SYSTEM_BROADCAST"
        }

        if (currentUid != null && recipientUserId == currentUid) {
            return true
        }

        if (recipientUserId == "DUTY_TOW_PROVIDERS") {
            return currentRole == UserType.DUTY_TOW || currentRole == UserType.ADMIN
        }

        if (recipientUserId == "DUTY_TIRE_PROVIDERS") {
            return currentRole == UserType.DUTY_TIRE || currentRole == UserType.ADMIN
        }

        if (recipientUserId == "DUTY_PROVIDERS" || recipientUserId == "EMERGENCY_PROVIDERS") {
            return currentRole == UserType.DUTY_TOW || currentRole == UserType.DUTY_TIRE || currentRole == UserType.ADMIN
        }

        if (recipientUserId == "OWNERS") {
            return currentRole == UserType.OWNER || currentRole == UserType.ADMIN
        }

        return false
    }

    /**
     * Listen for incoming push notifications in Firestore intended for the active user
     */
    fun listenForUserNotifications(userId: String, userType: UserType) {
        try {
            notificationListener?.remove()
            val dbInstance = getFirestore() ?: return

            notificationListener = dbInstance.collection("notifications")
                .whereGreaterThan("timestamp", appStartTime)
                .addSnapshotListener { snapshot, e ->
                    if (e != null || snapshot == null) return@addSnapshotListener
                    val ctx = appContext ?: return@addSnapshotListener

                    snapshot.documentChanges.forEach { change ->
                        if (change.type == com.google.firebase.firestore.DocumentChange.Type.ADDED) {
                            val doc = change.document
                            val recipient = doc.getString("recipientUserId") ?: "ALL"
                            val type = doc.getString("type") ?: "GENERAL"
                            val title = doc.getString("title") ?: ""
                            val body = doc.getString("body") ?: ""
                            val senderToken = doc.getString("senderFcmToken") ?: ""

                            // Don't duplicate notification if it originated from this same device session
                            if (senderToken.isNotBlank() && senderToken == fcmToken) {
                                return@forEach
                            }

                            if (shouldShowNotificationLocally(type, recipient)) {
                                val notifId = (doc.id.hashCode() and 0x7FFFFFFF)
                                val isEmergency = type.startsWith("EMERGENCY")
                                val channelId = if (isEmergency) CHANNEL_EMERGENCY else CHANNEL_NORMAL

                                val extraDataMap = try {
                                    @Suppress("UNCHECKED_CAST")
                                    doc.get("extraData") as? Map<String, String> ?: emptyMap()
                                } catch (ex: Exception) {
                                    emptyMap()
                                }

                                showLocalSystemNotification(
                                    context = ctx,
                                    notificationId = notifId,
                                    channelId = channelId,
                                    title = title,
                                    body = body,
                                    type = type,
                                    extraData = extraDataMap
                                )
                            }
                        }
                    }
                }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to listen for user notifications: ${e.localizedMessage}")
        }
    }

    /**
     * Send high-priority FCM Push Notification & system notification
     */
    fun sendPushNotification(
        title: String,
        body: String,
        type: String = "GENERAL",
        recipientUserId: String? = null,
        extraData: Map<String, String> = emptyMap()
    ) {
        val ctx = appContext ?: return
        val isEmergency = type.startsWith("EMERGENCY")
        val channelId = if (isEmergency) CHANNEL_EMERGENCY else CHANNEL_NORMAL
        val notificationId = (System.currentTimeMillis() % 100000).toInt()

        Log.d(TAG, "🔔 Triggering FCM Push Notification: [$type] recipient=$recipientUserId - $title")

        // 1. Trigger local notification ONLY if the logged in user is the intended recipient
        if (shouldShowNotificationLocally(type, recipientUserId)) {
            showLocalSystemNotification(
                context = ctx,
                notificationId = notificationId,
                channelId = channelId,
                title = title,
                body = body,
                type = type,
                extraData = extraData
            )
        }

        // 2. Persist notification to Firestore collection for realtime device sync
        try {
            val dbInstance = getFirestore()
            if (dbInstance != null) {
                val notifDoc = hashMapOf(
                    "id" to "notif_$notificationId",
                    "title" to title,
                    "body" to body,
                    "type" to type,
                    "recipientUserId" to (recipientUserId ?: "ALL"),
                    "senderFcmToken" to (fcmToken ?: ""),
                    "extraData" to extraData,
                    "timestamp" to System.currentTimeMillis(),
                    "isRead" to false
                )
                dbInstance.collection("notifications").document("notif_$notificationId").set(notifDoc)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not persist push notification to Firestore: ${e.localizedMessage}")
        }
    }

    private fun showLocalSystemNotification(
        context: Context,
        notificationId: Int,
        channelId: String,
        title: String,
        body: String,
        type: String,
        extraData: Map<String, String>
    ) {
        try {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("notif_type", type)
                extraData.forEach { (k, v) -> putExtra(k, v) }
            }

            val pendingIntent = PendingIntent.getActivity(
                context,
                notificationId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val isEmergency = channelId == CHANNEL_EMERGENCY

            val builder = NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(if (isEmergency) NotificationCompat.PRIORITY_MAX else NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)

            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.notify(notificationId, builder.build())
        } catch (e: Exception) {
            Log.e(TAG, "Error showing system notification: ${e.localizedMessage}")
        }
    }

    fun uploadImage(
        storagePath: String,
        fileUri: Uri,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val storageInstance = getStorage()
        if (storageInstance == null) {
            onError("Firebase Storage aktif değil veya bağlantı kurulamadı. Lütfen Firebase Console'da Storage servisini etkinleştirin.")
            return
        }
        try {
            val storageRef = storageInstance.reference.child(storagePath)
            storageRef.putFile(fileUri)
                .addOnSuccessListener {
                    storageRef.downloadUrl.addOnSuccessListener { downloadUri ->
                        onSuccess(downloadUri.toString())
                    }.addOnFailureListener { ex ->
                        onError("İndirme bağlantısı alınamadı: ${ex.localizedMessage}")
                    }
                }
                .addOnFailureListener { ex ->
                    onError("Fotoğraf yükleme başarısız: ${ex.localizedMessage}. (Firebase Console Storage durumunu kontrol edin)")
                }
        } catch (e: Exception) {
            onError("Yükleme sırasında hata oluştu: ${e.localizedMessage}")
        }
    }

    fun getAuth(): FirebaseAuth? {
        return if (isFirebaseInitialized) {
            try { FirebaseAuth.getInstance() } catch (e: Exception) { null }
        } else null
    }

    fun getFirestore(): FirebaseFirestore? {
        return if (isFirebaseInitialized) {
            try { FirebaseFirestore.getInstance() } catch (e: Exception) { null }
        } else null
    }

    fun getStorage(): FirebaseStorage? {
        return if (isFirebaseInitialized) {
            try { FirebaseStorage.getInstance() } catch (e: Exception) { null }
        } else null
    }
}
