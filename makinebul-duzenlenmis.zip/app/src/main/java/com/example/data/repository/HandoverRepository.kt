package com.example.data.repository

import com.example.data.firebase.FirebaseManager
import com.example.data.model.HandoverProtocol
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class HandoverRepository {

    private val scope = CoroutineScope(Dispatchers.IO)
    private val _protocols = MutableStateFlow<List<HandoverProtocol>>(emptyList())
    val protocols: StateFlow<List<HandoverProtocol>> = _protocols.asStateFlow()

    init {
        FirebaseManager.runWhenAuthenticated { listenToFirestoreProtocols() }
    }

    private fun listenToFirestoreProtocols() {
        if (!FirebaseManager.isAvailable) return

        scope.launch {
            try {
                FirebaseManager.db?.collection("handoverProtocols")
                    ?.addSnapshotListener { snapshot, error ->
                        if (error != null || snapshot == null) return@addSnapshotListener
                        val list = snapshot.documents.mapNotNull { docToProtocol(it) }
                        _protocols.value = list
                    }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun createProtocol(protocol: HandoverProtocol): HandoverProtocol {
        val newProto = if (protocol.id.isEmpty()) protocol.copy(id = "proto_${System.currentTimeMillis()}") else protocol
        _protocols.value = listOf(newProto) + _protocols.value

        if (FirebaseManager.isAvailable) {
            scope.launch {
                try {
                    val map = hashMapOf<String, Any>(
                        "id" to newProto.id,
                        "machineId" to newProto.machineId,
                        "machineTitle" to newProto.machineTitle,
                        "offerId" to newProto.offerId,
                        "ownerId" to newProto.ownerId,
                        "ownerName" to newProto.ownerName,
                        "customerId" to newProto.customerId,
                        "customerName" to newProto.customerName,
                        "customerPhone" to newProto.customerPhone,
                        "initialHoursCounter" to newProto.initialHoursCounter,
                        "finalHoursCounter" to newProto.finalHoursCounter,
                        "initialFuelPercent" to newProto.initialFuelPercent,
                        "finalFuelPercent" to newProto.finalFuelPercent,
                        "deliveryDate" to newProto.deliveryDate,
                        "returnDate" to newProto.returnDate,
                        "conditionNotes" to newProto.conditionNotes,
                        "isCleanDelivered" to newProto.isCleanDelivered,
                        "hasOperatorLicenseChecked" to newProto.hasOperatorLicenseChecked,
                        "hasInsuranceVerified" to newProto.hasInsuranceVerified,
                        "status" to newProto.status,
                        "createdAt" to newProto.createdAt
                    )
                    FirebaseManager.db?.collection("handoverProtocols")?.document(newProto.id)?.set(map)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
        return newProto
    }

    fun completeProtocol(protocolId: String, finalHours: Double, finalFuel: Int, returnNotes: String) {
        _protocols.value = _protocols.value.map {
            if (it.id == protocolId) {
                it.copy(
                    finalHoursCounter = finalHours,
                    finalFuelPercent = finalFuel,
                    conditionNotes = if (returnNotes.isNotBlank()) "${it.conditionNotes}\nİade Notu: $returnNotes" else it.conditionNotes,
                    status = "COMPLETED"
                )
            } else it
        }

        if (FirebaseManager.isAvailable) {
            scope.launch {
                try {
                    val updates = hashMapOf<String, Any>(
                        "finalHoursCounter" to finalHours,
                        "finalFuelPercent" to finalFuel,
                        "status" to "COMPLETED"
                    )
                    FirebaseManager.db?.collection("handoverProtocols")?.document(protocolId)?.update(updates)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    private fun docToProtocol(doc: DocumentSnapshot): HandoverProtocol? {
        return try {
            HandoverProtocol(
                id = doc.getString("id") ?: doc.id,
                machineId = doc.getString("machineId") ?: "",
                machineTitle = doc.getString("machineTitle") ?: "",
                offerId = doc.getString("offerId") ?: "",
                ownerId = doc.getString("ownerId") ?: "",
                ownerName = doc.getString("ownerName") ?: "",
                customerId = doc.getString("customerId") ?: "",
                customerName = doc.getString("customerName") ?: "",
                customerPhone = doc.getString("customerPhone") ?: "",
                initialHoursCounter = (doc.getDouble("initialHoursCounter") ?: 0.0),
                finalHoursCounter = (doc.getDouble("finalHoursCounter") ?: 0.0),
                initialFuelPercent = (doc.getLong("initialFuelPercent")?.toInt() ?: 100),
                finalFuelPercent = (doc.getLong("finalFuelPercent")?.toInt() ?: 100),
                deliveryDate = doc.getString("deliveryDate") ?: "",
                returnDate = doc.getString("returnDate") ?: "",
                conditionNotes = doc.getString("conditionNotes") ?: "",
                photosBefore = (doc.get("photosBefore") as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList(),
                photosAfter = (doc.get("photosAfter") as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList(),
                isCleanDelivered = (doc.getBoolean("isCleanDelivered") ?: true),
                hasOperatorLicenseChecked = (doc.getBoolean("hasOperatorLicenseChecked") ?: true),
                hasInsuranceVerified = (doc.getBoolean("hasInsuranceVerified") ?: true),
                status = doc.getString("status") ?: "ACTIVE",
                createdAt = (doc.getLong("createdAt") ?: System.currentTimeMillis())
            )
        } catch (e: Exception) {
            null
        }
    }
}
